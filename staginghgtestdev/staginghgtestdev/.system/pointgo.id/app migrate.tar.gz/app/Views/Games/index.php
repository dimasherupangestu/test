<?php $this->extend('template'); ?>

<?php $this->section('css'); ?>

<style>
.back-to-top {
    bottom: 75px !important;
}
.fab-container {
    bottom: 125px !important;
}
.contentgame {
    color: #000;
    font-size: 12px;
    background: #d9d9d99c;
    padding: 1.5rem;
    border-radius: 9px;
}

.section {
    background: linear-gradient(to right, var(--warna_11), var(--warna_13)) !important;
}

.body-games {
    background: linear-gradient(to right, var(--warna_11), var(--warna_13)) !important;
}

.contentgame p {
    color: #000 !important;
}

h5.pb-2,
h5.mb-2 {
    color: ;
}

.h3,
h3 {
    font-size: 25px;
}

.cutoffbank {
    filter: grayscale(1);
    pointer-events: none;

}

@media (max-width: 900px) {
    .hanz-modal {
        margin-left: 30% !important;
    }
}

.cutoffbank p {
    font-size: 10px !important;
    line-height: 13px;
    margin-bottom: 0.5rem !important;
    margin-right: 1rem !important;
    margin-left: 1rem !important;
    font-weight: 600;
}

button.accordion-button {
    outline: none !important;
    border: 1px solid #0000;
    border-radius: 6px;
    padding: 7px 20px;
    font-weight: 600;
    background: #ffffffcf;
}

.single-payment .radio-nominal:checked + label {
    border: 2px solid var(--warna_4) !important;
    box-shadow: 0 0 200px rgb(182 187 43 / 47%) inset !important;
    transition: 0.3s ease;
}



.accordion-button[aria-expanded="true"] {
    border: 1px solid var(--warna_4);
    box-shadow: 0 0 200px rgb(182 187 43 / 47%) inset !important;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
}

/* .accordion-collapse.collapsing {
    border: 1px solid var(--warna_4);
    border-top: 0;
    border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
}

.accordion-collapse.collapse.show {
    border: 1px solid var(--warna_4);
    border-top: 0;
    border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
} */

.text-end {
    text-align: right !important;
}

.accordion {
    --bs-accordion-color: #000;
    --bs-accordion-bg: #fff;
    --bs-accordion-transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, border-radius 0.15s ease;
    --bs-accordion-border-color: var(--bs-border-color);
    --bs-accordion-border-width: 1px;
    --bs-accordion-border-radius: 0.375rem;
    --bs-accordion-inner-border-radius: calc(0.375rem - 1px);
    --bs-accordion-btn-padding-x: 1.25rem;
    --bs-accordion-btn-padding-y: 1rem;
    --bs-accordion-btn-color: var(--bs-body-color);
    --bs-accordion-btn-bg: var(--bs-accordion-bg);
    --bs-accordion-btn-icon: url(data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='var%28--bs-body-color%29'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e);
    --bs-accordion-btn-icon-width: 1.25rem;
    --bs-accordion-btn-icon-transform: rotate(-180deg);
    --bs-accordion-btn-icon-transition: transform 0.2s ease-in-out;
    --bs-accordion-btn-active-icon: url(data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%230c63e4'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e);
    --bs-accordion-btn-focus-border-color: #86b7fe;
    --bs-accordion-btn-focus-box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
    --bs-accordion-body-padding-x: 1.25rem;
    --bs-accordion-body-padding-y: 1rem;
    --bs-accordion-active-color: #0c63e4;
    --bs-accordion-active-bg: #e7f1ff;
}


.accordion-body {
    background: var(--warna_6);
    border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
    border: 1px solid var(--warna_4);
}

.accordion-button {
    position: relative;
    display: flex;
    align-items: center;
    width: 100%;
    padding: var(--bs-accordion-btn-padding-y) var(--bs-accordion-btn-padding-x);
    font-size: 1rem;
    color: var(--bs-accordion-btn-color);
    text-align: left;
    background-color: var(--bs-accordion-btn-bg);
    border: 0;
    border-radius: 0;
    overflow-anchor: none;
    transition: var(--bs-accordion-transition);
}


.boks {
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    border-radius: 6px;
}

.col-sm-4,
.col-6 {
    padding-right: 8px;
    padding-left: 8px;
}

.circle-primary {
    border: 4px solid #fff;
    background-color: #141414;
    height: 41px;
    width: 40px;
}


.mb-1,
.my-1 {
    margin-bottom: 0.75rem !important;
}

.border-top {
    border-top: 1px solid #ffffff00 !important;
}

.border-top:checked+label {
    border-top: 1px solid #141414 !important;
}


.discount-price {
    font-size: 10px;
    color: red !important;
    font-weight: 500;
    font-style: italic;
    text-decoration: line-through
}

.icon-diamondx {
    height: 2.5rem;
}

.accordion-button iconify-icon.pl-1 {
    transform: rotateX(177deg);
    transition: 0.2s ease;
}

.accordion-button.collapsed iconify-icon.pl-1 {
    transform: rotateX(0deg);
    transition: 0.2s ease;
}

.single-payment .radio-nominal+label[for="method-balance"], .single-payment .radio-nominal+label[for="method-2"] {
    padding-bottom: 20px;
    padding-top: 20px;
    border: 2px solid rgb(238 237 237);
    border-radius: 6px;
    box-shadow: 0 0px 7px 0 rgb(236 227 215 / 73%);
}

.method-accordion .accordion-button {
    padding: 0px 0px;
}

.radio-nominal+label .row .col-1 .rounded-radio svg circle {
    fill: #0000;
    transition: 0.3s ease;
}

.radio-nominal:checked+label .row .col-1 .rounded-radio svg circle {
    fill: var(--warna_4);
}

.bg-banner {
    width: 100%;
    height: 480px;
}

.container-min-banner {
    margin-top: -380px;
}

@media (max-width:480px) {
    .bg-banner {
        width: 100%;
        height: 425px;
    }

    .harga-price-method {
        font-weight: 600;
        font-size: 11px;
    }

    .text-method {
        font-size: 13px;
    }
}

@media (min-width:481px) {
    .bg-banner {
        width: 100%;
        height: 425px;
    }

    button.accordion-button {
        /* padding: 7px 20px; */
    }

    .harga-price-method {
        font-weight: 600;
        font-size: 14px;
    }
}

.form-row p {
    color: #fff !important;
}

.total-price-box {
    position: fixed;
    width: 100%;
    bottom: 0;
    background: var(--warna_3);
    z-index: 999;
    padding: 10px 10px;
}

.voucher-box {
    position: fixed;
    width: 100%;
    bottom: 62px;
    background: #c5a040;
    z-index: 999;
    border-radius: 10px 10px 0px 0px;
    box-shadow: 0px 17px 39px 9px rgb(0 0 0 / 40%);
    overflow: hidden !important;
}

.voucher-box .collapse {
    transition: height 0.5s ease !important;
}

#nominal-text {
    font-size: 16px;
}

.btn-beli {
    background: linear-gradient(180deg, #2D2D2D 0%, #2D2D2D 0.01%, #232323 100%);
    border-radius: 10px;
    font-size: 12px;
    padding: 9px 9px 9px 19px;
}

.flex-col {
    flex-direction: column;
}
.pl-10 {
    border-radius: 10px 0px 0px 10px !important;
}

.pl-9 {
    border-radius: 0px 10px 10px 0px !important;
}
.border-b {
    border-bottom: 1px solid #ffffff80;
}
@media (max-width:575px) {
    .resp {
        display:none !important;
    }
    .fab-container{
       display: none !important;
    }
}
@media (min-width: 575px){
    .voucher-box {
        display: none;
    }
}

@media (max-width: 575px) {
    .back-to-top {
        bottom: 115px !important;
    }
    .balancedisc {
    font-size: 10px !important;
    }
}

.icon-voucher {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%) !important;
    color: #6c757d;
}
.rotate {
    transition: transform 0.3s ease-in-out !important;
    }
.vc {
    padding: 10px !important;
}
.image-modal {
  position: absolute;
  display: inline-block;
}

.image-modal img {
  max-width: 100%;
  height: auto;
}
 .image-modal .modal-body img {
    max-width: none; 
  }
.image-tooltip {
  position: relative;
  display: inline-block;
}

.image-tooltip img {
  display: none;
  position: absolute;
  top: 125%;
  left: 310%;
  transform: translateX(-50%);
  z-index: 1;
  border-radius: 10px;
}

@media (min-width: 1000px) {
  .image-tooltip:hover img {
    display: block;
  }
}

.balancedisc {
    font-size: 13px;
    color: red !important;
    font-weight: 500;
    font-style: italic;
    text-decoration: line-through;
}
</style>

<?php $this->endSection(); ?>

<?php $this->section('content'); ?>
<?php if ($is_mobile == true): ?>
                          
                            
<div class="voucher-box">
         <a class=" nav-item nav-link d-flex justify-content-center align-items-center border-b rotate vc" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample" style="cursor:pointer; color:white !important;">
            Gunakan Kode Promo<iconify-icon class="pl-1" inline icon="subway:up-2"></iconify-icon>
        </a>
    <div class="collapse" id="collapseExample">
         <div class="form-group pt-3 pb-3 pl-1 pr-1 mb-0">
            <div class="input-group">
                <div class="icon-voucher pl-0"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true" class="icon-voucher2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z">
                        </path>
                    </svg></div>
                <input type="text" name="voucher" placeholder="Optional" class="form-control pl-10" style="background: #fff;">
                <button class="btn btn-primary pl-9" type="button" onclick="cek_voucher();">Cek</button>
            </div>
        </div>
    </div>
</div>
<?php endif ?>

<div class="total-price-box">
    <div class="container">
        <div class="row">
            <div class="col-5">
                <p class="text-white mb-0" style="font-weight: 600;">Total</p>
                <h4 class="text-white mb-0" id="nominal-text" style="font-family:sans-serif !important;"></h4>
            </div>
            <div class="col-7 d-flex justify-content-end">
                <div class="text-right d-flex align-items-center">
                    <button type=" button" class="btn btn-beli text-white" onclick="process_order();" id="buyButton">Beli
                    Sekarang <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                        fill="none">
                        <path
                            d="M8.45882 17.9999C8.93213 18.0005 9.3912 17.8381 9.75882 17.5399L14.8588 13.3299C15.0588 13.1707 15.2203 12.9685 15.3313 12.7382C15.4423 12.5079 15.5 12.2556 15.5 11.9999C15.5 11.7443 15.4423 11.492 15.3313 11.2617C15.2203 11.0314 15.0588 10.8292 14.8588 10.6699L9.75882 6.45995C9.45179 6.21394 9.08182 6.05913 8.69109 6.01316C8.30035 5.9672 7.90456 6.03191 7.54882 6.19995C7.23965 6.33623 6.97623 6.55862 6.79004 6.84057C6.60385 7.12251 6.50275 7.45209 6.49882 7.78995V16.2099C6.50275 16.5478 6.60385 16.8774 6.79004 17.1593C6.97623 17.4413 7.23965 17.6637 7.54882 17.7999C7.83469 17.9299 8.14479 17.9981 8.45882 17.9999Z"
                            fill="var(--warna_4)" />
                        <defs>
                            <linearGradient id="paint0_linear_74_267" x1="10.9994" y1="5.99878" x2="10.9994"
                                y2="17.9999" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#BDFB50" />
                                <stop offset="1" stop-color="#99D332" />
                            </linearGradient>
                        </defs>
                    </svg></button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="pb-1">
    <div style="background: linear-gradient(180deg, rgba(0,0,0,.00) 0%, #fff), url(<?= base_url(); ?>/assets/images/games/banner_img/<?= $games['banner_img']; ?>);background-size: cover;"
        alt="slide " class="bg-banner">
    </div>
</div>
<div class="container-min-banner pb-5">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="" style="margin-bottom:20px;">
                    <div class="">
                        <div class="pt-3 pb-2">
                            <img src="<?= base_url(); ?>/assets/images/games/<?= $games['image']; ?>" class="mb-3"
                                style="display: block;border-radius: 99px !important;border: 3px solid #fff;"
                                width="120px" height="120px">
                            <h5 style="color:var(--warna_hitam);"><?= $games['games']; ?></h5>
                        </div>
                        <div class="pb-3">
                            <?= $games['content']; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">

                <?= alert(); ?>

                <div class="pb-3 " id="">
                    <div class="section">
                        <div class="body-games shadow-form">
                        <h5 id="judulgame" style="margin-top: 5px;color:var(--warna_2) !important;">
                            <?php if ($games['target'] == 'custom'): ?>
                            <?= $games['st_title']; ?>
                            <?php else: ?>
                            Lengkapi Data
                            <?php endif ?>
                        </h5>
                        <?php if ($games['target'] == 'custom'): ?>


                        <div class="form-row pt-3">

                            <?php if ($games['st_col'] == 1): ?>
                            <div class="col">
                                <input type="<?= $games['st1_type']; ?>" name="user_id" class="form-control"
                                    placeholder="<?= $games['st1_text']; ?>" autocomplete="off">
                                <input type="hidden" name="zone_id" value="1">
                            </div>
                            <p class="col-12 mt-2" style="font-size: 10px;color:var(--warna_2) !important;">
                                <?= $games['st_desc']; ?>
                            </p>

                            <div class="row">
                            <div class="col-12" id="imageTooltipContainer" style="display: none;">
                                <button type="button" class="btn btn-primary btn-sm image-tooltip" id="imageModalButton">
                                    <i aria-hidden="true" class="fa fa-info-circle mr-1"></i>Petunjuk
                                    <img src="<?= base_url(); ?>/assets/images/games/infoimage/<?= $games['infoimage']; ?>" style="width: 650px; height: auto;" id="tooltipImage">
                                </button>
                            </div>
                            <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content" style="background:transparent;">
                                        <div class="modal-body">
                                            <img src="<?= base_url(); ?>/assets/images/games/infoimage/<?= $games['infoimage']; ?>" class="img-fluid">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                            <?php elseif ($games['st_col'] == 2): ?>

                            <?php if ($games['st2_type'] == 'dropdown'): ?>
                            <div class="col">
                                <input type="<?= $games['st1_type']; ?>" name="user_id" class="form-control"
                                    placeholder="<?= $games['st1_text']; ?>" autocomplete="off">
                            </div>

                            <div class="col">
                                <select name="zone_id" id="Server" class="form-control">
                                    <option value="<?= $games['st2_text']; ?>"><?= $games['st2_text']; ?></option>
                                    <?php
                                                $options = explode(',', $games['st2_data']);
                                                foreach ($options as $option) {
                                                    $parts = explode('///', $option);
                                                    $value = trim($parts[1]);
                                                    $label = trim($parts[0]);
                                                    echo "<option value=\"$value\">$label</option>";
                                                }
                                                ?>
                                </select>
                            </div>
                            
                            <div class="row">
                            <div class="col-12" id="imageTooltipContainer" style="display: none;">
                                <button type="button" class="btn btn-primary btn-sm image-tooltip" id="imageModalButton">
                                    <i aria-hidden="true" class="fa fa-info-circle mr-1"></i>Petunjuk
                                    <img src="<?= base_url(); ?>/assets/images/games/infoimage/<?= $games['infoimage']; ?>" style="width: 650px; height: auto;" id="tooltipImage">
                                </button>
                            </div>
                            <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content" style="background:transparent;">
                                        <div class="modal-body">
                                            <img src="<?= base_url(); ?>/assets/images/games/infoimage/<?= $games['infoimage']; ?>" class="img-fluid">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                            <?php else: ?>
                            <div class="col">
                                <input type="<?= $games['st1_type']; ?>" name="user_id" class="form-control"
                                    placeholder="<?= $games['st1_text']; ?>" autocomplete="off">
                            </div>

                            <div class="col">
                                <input type="<?= $games['st2_type']; ?>" name="zone_id" class="form-control"
                                    placeholder="<?= $games['st2_text']; ?>" autocomplete="off">
                            </div>
                            <?php endif ?>
                            <p class="col-12 mt-2" style="font-size: 10px;color:var(--warna_2) !important;">
                                <?= $games['st_desc']; ?>
                            </p>
                            
                            <div class="row">
                            <div class="col-12" id="imageTooltipContainer" style="display: none;">
                                <button type="button" class="btn btn-primary btn-sm image-tooltip" id="imageModalButton">
                                    <i aria-hidden="true" class="fa fa-info-circle mr-1"></i>Petunjuk
                                    <img src="<?= base_url(); ?>/assets/images/games/infoimage/<?= $games['infoimage']; ?>" style="width: 650px; height: auto;" id="tooltipImage">
                                </button>
                            </div>
                            <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content" style="background:transparent;">
                                        <div class="modal-body">
                                            <img src="<?= base_url(); ?>/assets/images/games/infoimage/<?= $games['infoimage']; ?>" class="img-fluid">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                            
                            <?php endif ?>
                        </div>
                        <?php else: ?>
                        <?= $this->include('Target/' . $games['target']); ?>
                        <div class="row">
                            <div class="col-12" id="imageTooltipContainer" style="display: none;">
                                <button type="button" class="btn btn-primary btn-sm image-tooltip" id="imageModalButton">
                                    <i aria-hidden="true" class="fa fa-info-circle mr-1"></i>Petunjuk
                                    <img src="<?= base_url(); ?>/assets/images/games/infoimage/<?= $games['infoimage']; ?>" style="width: 650px; height: auto;" id="tooltipImage">
                                </button>
                            </div>
                            <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content" style="background:transparent;">
                                        <div class="modal-body">
                                            <img src="<?= base_url(); ?>/assets/images/games/infoimage/<?= $games['infoimage']; ?>" class="img-fluid">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif ?>
                        <?php if ($games['target'] == 'joki'): ?>
                        <input type="text" name="wa" placeholder="Masukan No. Whatsapp" class="form-control mt-2" value="" required>
                        <?php endif ?>
                        </div>
                    </div>
                </div>
            

                <div class="pb-3">
                    <div class="section">
                        <div class="body-games shadow-form">
                            <h5 style="color:var(--warna_2) !important;">Pilih Nominal Layanan</h5>
                            <?php $no = 1;
                            foreach ($category as $cat): ?>
                            <div class="row px-2 mt-4 <?= count($category) == 0 ? 'd-none' : ''; ?>">
                                <div class="col-12">
                                </div>
                                <div class="col-md-12 col-12">
                                    <div>
                                        <h5><?= $cat['category']; ?></h5><br>
                                    </div>
                                </div>

                            </div>

                            <?php $no = 1;
                                foreach ($products as $key => $value): ?>
                            <div class="row pl-2 pr-2 row-category" id="product-category-<?= $key; ?>">
                                <?php foreach ($value as $loop): ?>
                                <?php if ($loop['category_id'] != $cat['id']) {
                                                continue;
                                            } ?>
                                <div class="col-6 col-lg-4" style="padding-right: 5px;padding-left: 5px;display:grid;">
                                    <input type="radio" for="product-<?= $loop['id']; ?>"
                                        id="product-<?= $loop['id']; ?>" class="radio-nominale"  name="product"
                                        value="<?= $loop['id']; ?>" onchange="get_price(this.value);get_price_and_scroll(this.value);">
                                    <label for="product-<?= $loop['id']; ?>">
                                        <div style="text-align: center;margin-bottom:10px;margin-top:10px;">
                                            <?php if (!empty($loop['image'])): ?>
                                                <img onerror="this.style.display='none'"
                                                    src="<?= base_url(); ?>/assets/images/product/<?= $loop['image']; ?>"
                                                    loading="lazy" class="icon-diamondx">
                                                    <br>
                                                <?php endif; ?>
                                            <a style="font-size: 14px;font-weight:600;text-align: center;"
                                                for="product-<?= $loop['id']; ?>"><?= $loop['product']; ?></a>
                                                <br>

                                            <?php
                                                $price = null;
                                                $discountPrice = null;
                                                
                                                if ($loop['discount_price'] != 0) {
                                                    if ($users !== false) {
                                                        switch ($users['level']) {
                                                            case 'Silver':
                                                                $price = !empty($loop['price_silver']) && $loop['price_silver'] !== 0 ? $loop['price_silver'] : $loop['price'];
                                                                break;
                                                            case 'Gold':
                                                                $price = !empty($loop['price_gold']) && $loop['price_gold'] !== 0 ? $loop['price_gold'] : $loop['price'];
                                                                break;
                                                            case 'Platinum':
                                                                $price = !empty($loop['price_platinum']) && $loop['price_platinum'] !== 0 ? $loop['price_platinum'] : $loop['price'];
                                                                break;
                                                            case 'Member':
                                                                $price = !empty($loop['price_bronze']) && $loop['price_bronze'] !== 0 ? $loop['price_bronze'] : $loop['price'];
                                                                break;
                                                            default:
                                                                $price = $loop['price'];
                                                                break;
                                                        }
                                                    } else if ($price == 0 OR empty($price)){
                                                        $price = $loop['price'];
                                                    } else {
                                                        $price = $loop['price'];
                                                    }
                                                    $discountPrice = $loop['discount_price'];
                                                } else {
                                                    if ($users !== false) {
                                                        switch ($users['level']) {
                                                            case 'Silver':
                                                                $price = $loop['price_silver'] ?? $loop['price'];
                                                                break;
                                                            case 'Gold':
                                                                $price = $loop['price_gold'] ?? $loop['price'];
                                                                break;
                                                            case 'Platinum':
                                                                $price = $loop['price_platinum'] ?? $loop['price'];
                                                                break;
                                                            case 'Platinum':
                                                                $price = $loop['price_platinum'] ?? $loop['price'];
                                                                break;
                                                            case 'Member':
                                                                $price = $loop['price_bronze'] ?? $loop['price'];
                                                                break;
                                                            default:
                                                                $price = $loop['price'];
                                                                break;
                                                        }
                                                    } else if ($price == 0 OR empty($price)){
                                                        $price = $loop['price'];
                                                    } else {
                                                        $price = $loop['price'];
                                                    }
                                                }
                                                
                                                ?>

                                            <a style="font-size: 12px; font-weight:500;" class="currency-idr">
                                                <?= $price; ?>
                                            </a>

                                            <?php if ($discountPrice != null): ?>
                                            <br>
                                            <p class="currency-idr-2 discount-price"><?= $discountPrice; ?></p>
                                            <?php endif; ?>
                                            <a style=" margin-bottom:10px;"></a>



                                        </div>



                                    </label>
                                </div>


                                <?php endforeach ?>
                            </div>
                            <?php $no++; endforeach ?>

                            <?php $no++; endforeach ?>

                            <div class="<?= count($category) >= 1 ? 'd-none' : ''; ?>">
                                <div class="row pt-3 pl-2 pr-2 mb-2">
                                    <?php if (count($product) == 0): ?>
                                    <div class="col-12">
                                        <div class="alert alert-warning alert-dismissible mt-2 mb-0" role="alert">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <div class="alert-icon">
                                                <i class="fa fa-exclamation-triangle"></i>
                                            </div>
                                            <div class="alert-message">
                                                <strong>Information!</strong> Produk sedang tidak tersedia.
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif ?>

                                    <?php foreach ($product as $loop): ?>
                                    <div class="col-6 col-lg-4"
                                        style="padding-right: 5px;padding-left: 5px;display:grid;">
                                        <input type="radio" for="product-<?= $loop['id']; ?>"
                                            id="product-<?= $loop['id']; ?>" class="radio-nominale" name="product"
                                            value="<?= $loop['id']; ?>" onchange="get_price(this.value);get_price_and_scroll(this.value)">
                                        <label for="product-<?= $loop['id']; ?>">
                                            <div style="text-align: center;margin-bottom:10px;margin-top:10px;">
                                                <?php if (!empty($loop['image'])): ?>
                                                <img onerror="this.style.display='none'"
                                                    src="<?= base_url(); ?>/assets/images/product/<?= $loop['image']; ?>"
                                                    loading="lazy" class="icon-diamondx">
                                                    <br>
                                                <?php endif; ?>
                                                
                                                <a style="font-size: 14px;font-weight:600; text-align: center;color:var(--warna_hitam);"
                                                    for="product-<?= $loop['id']; ?>"><?= $loop['product']; ?></a>
                                                    <br>
                                                <?php
                                                $price = null;
                                                $discountPrice = null;
                                                
                                                if ($loop['discount_price'] != 0) {
                                                    if ($users !== false) {
                                                        switch ($users['level']) {
                                                            case 'Silver':
                                                                $price = $loop['price_silver'] ?? $loop['price'];
                                                                break;
                                                            case 'Gold':
                                                                $price = $loop['price_gold'] ?? $loop['price'];
                                                                break;
                                                            case 'Platinum':
                                                                $price = $loop['price_platinum'] ?? $loop['price'];
                                                                break;
                                                            case 'Member':
                                                                $price = $loop['price_bronze'] ?? $loop['price'];
                                                                break;
                                                            default:
                                                                $price = $loop['price'];
                                                                break;
                                                        }
                                                    } else if ($price == 0 OR empty($price)){
                                                        $price = $loop['price'];
                                                    } else {
                                                        $price = $loop['price'];
                                                    }
                                                    $discountPrice = $loop['discount_price'];
                                                } else {
                                                    if ($users !== false) {
                                                        switch ($users['level']) {
                                                            case 'Silver':
                                                                $price = !empty($loop['price_silver']) && $loop['price_silver'] !== 0 ? $loop['price_silver'] : $loop['price'];
                                                                break;
                                                            case 'Gold':
                                                                $price = !empty($loop['price_gold']) && $loop['price_gold'] !== 0 ? $loop['price_gold'] : $loop['price'];
                                                                break;
                                                            case 'Platinum':
                                                                $price = !empty($loop['price_platinum']) && $loop['price_platinum'] !== 0 ? $loop['price_platinum'] : $loop['price'];
                                                                break;
                                                            case 'Member':
                                                                $price = !empty($loop['price_bronze']) && $loop['price_bronze'] !== 0 ? $loop['price_bronze'] : $loop['price'];
                                                                break;
                                                            default:
                                                                $price = $loop['price'];
                                                                break;
                                                        }
                                                    } else if ($price == 0 OR empty($price)){
                                                        $price = $loop['price'];
                                                    } else {
                                                        $price = $loop['price'];
                                                    }
                                                }
                                                
                                                ?>

                                                <a style="font-size: 12px; font-weight:500;color:var(--warna_hitam);" class="currency-idr">
                                                    <?= $price; ?>
                                                </a>

                                                <?php if ($discountPrice != null): ?>
                                                <p class="currency-idr-2 discount-price"><?= $discountPrice; ?></p>
                                                <?php endif; ?>

                                            </div>


                                            </input>

                                        </label>
                                    </div>
                                    <?php endforeach ?>
                                </div>
                            </div>
                            <?php if ($games['slug'] == 'joki-paket-rank'): ?>
                            <style>
                            .kuantitibox {
                                visibility: hidden;
                            }
                            </style>
                            <?php endif ?>


                            <?php if ($games['target'] == 'joki'): ?>
                            <div id="kuantitibox" class="kuantitibox mt-4">
                                <h5 class="mb-2">Masukkan Jumlah (Star/Win)</h5>
                                <input type="number" class="form-control name-joki" value="1" id="jumlah_star_poin"
                                    name="joki[jumlah_star_poin]" onchange="update_total();">
                                <p style="font-size: 12px;">Minimal Order adalah 5, Jika Kurang Dari
                                    Minimal order maka
                                    uang akan hangus</p>
                            </div>


                            <?php if ($games['slug'] == 'paket-hemat-joki'): ?>
                            <style>
                            #kuantitibox {
                                visibility: hidden;
                            }
                            </style>


                            <?php endif ?>
                            <?php endif ?>

                            <?php if ($games['target'] == 'jokigendong'): ?>
                            <div id="kuantitibox2" class="kuantitibox2 mt-4 text-dark">
                                <h5 class="mb-2">Masukkan Jumlah (Star/Win)</h5>
                                <input type="number" class="form-control name-jokigendong" value="1"
                                    id="jumlah_star_poin" name="jokigendong[jumlah_star_poin]"
                                    onchange="update_total();">
                                <p style="font-size: 12px;">Minimal Order adalah 5, Jika Kurang Dari Minimal order maka
                                    uang akan hangus</p>
                            </div>

                            <?php if ($games['slug'] == 'paket-joki-gendong-rank'): ?>
                            <style>
                            #kuantitibox2 {
                                visibility: hidden !important;
                            }
                            </style>


                            <?php endif ?>
                            <?php endif ?>

                            <?php if ($games['target'] == 'videomontage'): ?>
                            <div class="kuantitibox mt-4">
                                <h5 class="mb-2">Masukkan Jumlah Menit</h5>
                                <input type="number" class="form-control name-videomontage" value="1" id="jumlah_menit"
                                    name="videomontage[jumlah_menit]" onchange="update_total();">
                            </div>
                            <?php endif ?>
                            
                            <?php if ($games['target'] == 'growtopia'): ?>
                            <div id="kuantitibox" class="kuantitibox2 mt-4 text-dark">
                                <h5 class="mb-2">Masukkan Quantity</h5>
                                <input type="number" class="form-control name-growtopia" min="5" value="5"
                                    id="jumlah_star_poin" name="growtopia[jumlah_star_poin]"
                                    onchange="update_total();">
                                <p style="font-size: 12px;">Minimal Order adalah 5, Jika Kurang Dari Minimal order maka
                                    uang akan hangus</p>
                            </div>
                            <?php endif ?>
                            

                        </div>
                    </div>
                </div>





                <div class="pb-3">
                    <div class="section section-game" id="pembayaran-section"
                        style="border: 0px;box-shadow: none!important;background:var(--warna_2);">
                        <div class="body-games shadow-form">
                            <h5 style="color:var(--warna_2) !important;">Pilih Pembayaran</h5>
                            <?php if ($pay_balance === 'Y'): ?>
                            <div class="mt-3 mb-3" id="bsaldo">
                                <div class="accordion-button single-payment">
                                    <input class="radio-nominal" type="radio" name="method" value="balance"
                                        id="method-balance">
                                    <label for="method-balance" class="mb-0">
                                        <div class="diskon"></div>
                                        <div class="row">
                                            <style>
                                                .diskon {
                                                    padding-top: 0.25rem;
                                                    padding-bottom: 0.25rem;
                                                    padding-left: 0.5rem;
                                                    padding-right: 0.75rem;
                                                    width: 87px;
                                                    height: 34px;
                                                    color: #fff;
                                                    background: #ff3956;
                                                    font-weight: bold;
                                                    font-family: 'Inter', sans-serif;
                                                    -webkit-font-smoothing: antialiased;
                                                    position: absolute;
                                                    top: -2px;
                                                    left: 0;
                                                    font-size: 17px;
                                                    line-height: 1.25rem;
                                                    border-radius: 10px 0px 20px 0px;
                                                    border-bottom: 3px solid #fff;
                                                    border-right: 3px solid #fff;
                                                }
                                            </style>
                                            <div  class="diskon" id="price-diskon-method-balance"><span id="price-diskon-balance {"></span></div>
                                            <div class="col-3 d-flex justify-content-center align-items-center">
                                                <div class="pb-0">
                                                    <img src="<?= base_url(); ?>/assets/images/new-assets/HIDDENPAY1.webp" width="40px" class="mx-auto d-block bhahah"></img>
                                                </div>
                                            </div>
                                            <div class="col-4 d-flex align-items-center">
                                                <div>
                                                    <div style="color:var(--warna_hitam);"> HiddenPay</div>
                                                    <div style="color: var(--warna_hitam);">Saldo: Rp
                                                        <?= number_format($users['balance'], 0, ',', '.'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-5">
                                                <div class="mt-2 text-right">
                                                    <p class="m-0 harga-price-method" id="price-member-method-balance" style="color:var(--warna_hitam)!important;"></p>
                                                    <p class="m-0 balancedisc" id="price-disc-method-balancedisc"></p>
                                                </div>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                            <?php endif ?>
                            <div class="mb-3" id="bbank">
                                <?php
                                $count = 0;
                                foreach ($accordion_data as $category => $methods):
                                    $count++;
                                    ?>
                                <?php if ($category === 'QRIS'): ?>
                                <?php foreach ($methods as $method): ?>
                                <div class="mt-3 mb-3" id="bbank">
                                    <div class="accordion-button single-payment">
                                        <input class="radio-nominal" type="radio" name="method"
                                            value="<?= $method['id']; ?>" id="method-<?= $method['id']; ?>">
                                        <label for="method-<?= $method['id']; ?>"
                                            id="method-<?= $method['id']; ?>-label" class="mb-0" style="background: #e6f1e0;">
                                            <div class="row">
                                                <div class="col-3 d-flex justify-content-center align-items-center">
                                                    <div class="pb-0">
                                                        <img src="<?= base_url(); ?>/assets/images/new-assets/qris-white.svg" width="100%" style="filter: invert(1);">
                                                    </div>
                                                </div>

                                                <div class="col-4 d-flex align-items-center">
                                                    <div style="color:var(--warna_hitam);"> <?= $category; ?></div>
                                                </div>
                                                <div class="col-5">
                                                    <div class="mt-2 text-right">
                                                        <p class="mb-2 harga-price-method"
                                                            id="price-method-<?= $method['provider']; ?>-<?= $method['code']; ?><?= $method['tambahan']; ?>" style="color:var(--warna_hitam)!important;"></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                                <?php else:?>
                                <div class="accordion-item mb-3 boks">
                                    <h2 class="accordion-header mb-0" id="heading-bank">
                                        <button class="accordion-button collapsed " type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapse<?= $count; ?>"
                                            aria-expanded="false" aria-controls="collapse<?= $count; ?>"
                                            aria-labelledby="<?= $count; ?>" data-bs-parent="#bbank">
                                            <div class="left" style="color:var(--warna_hitam) !important;">
                                                <?php if ($category == 'Bank Transfer'): ?>
                                                <img src="<?= base_url(); ?>/assets/images/new-assets/mdi_bank.svg"
                                                    class="mr-3" style=" filter: invert(1);">
                                                </img>&nbsp<?= $category; ?>
                                                
                                                <?php elseif ($category == 'E-Wallet'): ?>
                                                <img src="<?= base_url(); ?>/assets/images/new-assets/e-wallet.svg"
                                                    class="mr-3" style="filter: invert(1);">
                                                </img>&nbsp<?= $category; ?>
                                                
                                                <?php elseif ($category == 'Virtual Account'): ?>
                                                <img src="<?= base_url(); ?>/assets/images/new-assets/vabank-white.svg"
                                                    class="mr-3" style=" filter: invert(1);">
                                                </img>&nbsp<?= $category; ?>
                                                    
                                                <?php elseif ($category == 'Convenience Store'): ?>
                                                <img src="<?= base_url(); ?>/assets/images/new-assets/store.svg"
                                                    class="mr-3" style=" filter: invert(1);">
                                                </img>&nbsp<?= $category; ?>
                                                    
                                                <?php elseif ($category == 'Pulsa'): ?>
                                                <img src="<?= base_url(); ?>/assets/images/new-assets/cell-phone.png"
                                                    class="mr-3" width="23" style=" filter: invert(1);">
                                                </img>&nbsp<?= $category; ?>
                                                <?php endif ?>
                                            </div>
                                            <iconify-icon class="pl-1" inline icon="subway:down-2"
                                                style="margin-left: auto;"></iconify-icon>
                                        </button>
                                    </h2>
                                    <div id="collapse<?= $count; ?>" class="accordion-collapse collapse"
                                        aria-labelledby="heading<?= $count; ?>" data-bs-parent="#bbank">
                                        <div class="accordion-body">

                                            <?php foreach ($methods as $method): ?>
                                            <div class="method-accordion mb-0" id="bbank">
                                                <button class="accordion-button">
                                                    <input class="radio-nominal" type="radio" name="method"
                                                        value="<?= $method['id']; ?>" id="method-<?= $method['id']; ?>" style="background: #e6f1e0;">
                                                    <label for="method-<?= $method['id']; ?>"
                                                        id="method-<?= $method['id']; ?>-label" class="mb-0" style="background: #e6f1e0;">
                                                        <div class="row">
                                                            <div class="col-1 d-flex align-items-center pr-4">
                                                                <div class="rounded-radio mr-2 pb-0">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                        height="12" viewBox="0 0 12 12" fill="none">
                                                                        <circle cx="6" cy="6" r="5.77941" stroke="white"
                                                                            stroke-width="0.441176" />
                                                                    </svg>
                                                                </div>
                                                            </div>
                                                            <div class="col-3 pl-0 d-flex align-items-center">
                                                                <div class="mr-2 pb-0">
                                                                    <img src="<?= base_url(); ?>/assets/images/method/<?= $method['image']; ?>"
                                                                        class="mr-3" width=" 60px"></img>
                                                                </div>
                                                            </div>

                                                            <div class="col-3 d-flex align-items-center px-0">
                                                                <div class="text-method" style="color:var(--warna_hitam);"> <?= $method['method']; ?>
                                                                </div>
                                                            </div>
                                                            <div
                                                                class="col-4 p-0 d-flex align-items-center justify-content-end">
                                                                <div class="mr-2 mt-2">
                                                                    <p class="mb-2 harga-price-method"
                                                                        id="price-method-<?= $method['provider']; ?>-<?= $method['code']; ?><?= $method['tambahan']; ?>" style="color:var(--warna_hitam)!important;"></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </label>
                                                </button>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            <div class="d-flex gap-2 pt-5 resp">
                                <h5 style="color:var(--warna_2) !important;">Kode Voucher</h5><i style="opacity:0.5;color: #eee;"> (Opsional)</i>
                            </div>
                            <?php if ($is_mobile == false): ?>
                            <div class="form-group pt-3 resp">
                                <input type="text" name="voucher" placeholder="Masukkan kode voucher"
                                    class="form-control w-80">
                                <div class="d-flex justify-content-end">
                                    <button class="btn btn-primary mt-3 d-flex align-items-center gap-2" type=" button"
                                        onclick="cek_voucher();"><svg xmlns="http://www.w3.org/2000/svg" width="16"
                                            height="12" viewBox="0 0 16 12" fill="none">
                                            <path
                                                d="M2 0C1.60218 0 1.22064 0.158035 0.93934 0.43934C0.658035 0.720644 0.5 1.10218 0.5 1.5V4.5C0.897825 4.5 1.27936 4.65804 1.56066 4.93934C1.84196 5.22064 2 5.60218 2 6C2 6.39782 1.84196 6.77936 1.56066 7.06066C1.27936 7.34196 0.897825 7.5 0.5 7.5V10.5C0.5 10.8978 0.658035 11.2794 0.93934 11.5607C1.22064 11.842 1.60218 12 2 12H14C14.3978 12 14.7794 11.842 15.0607 11.5607C15.342 11.2794 15.5 10.8978 15.5 10.5V7.5C15.1022 7.5 14.7206 7.34196 14.4393 7.06066C14.158 6.77936 14 6.39782 14 6C14 5.60218 14.158 5.22064 14.4393 4.93934C14.7206 4.65804 15.1022 4.5 15.5 4.5V1.5C15.5 1.10218 15.342 0.720644 15.0607 0.43934C14.7794 0.158035 14.3978 0 14 0H2ZM10.625 2.25L11.75 3.375L5.375 9.75L4.25 8.625L10.625 2.25ZM5.6075 2.28C6.3425 2.28 6.935 2.8725 6.935 3.6075C6.935 3.95958 6.79514 4.29723 6.54618 4.54618C6.29723 4.79514 5.95958 4.935 5.6075 4.935C4.8725 4.935 4.28 4.3425 4.28 3.6075C4.28 3.25543 4.41986 2.91777 4.66882 2.66882C4.91777 2.41986 5.25543 2.28 5.6075 2.28ZM10.3925 7.065C11.1275 7.065 11.72 7.6575 11.72 8.3925C11.72 8.74457 11.5801 9.08223 11.3312 9.33118C11.0822 9.58014 10.7446 9.72 10.3925 9.72C9.6575 9.72 9.065 9.1275 9.065 8.3925C9.065 8.04042 9.20486 7.70277 9.45382 7.45382C9.70277 7.20486 10.0404 7.065 10.3925 7.065Z"
                                                fill="#333333" />
                                        </svg> Gunakan Voucher</button>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>



                <div class="pb-3">
                    <div class="section">
                        <div class="body-games shadow-form">
                            <div class="d-flex gap-2">
                                <h5 style="color:var(--warna_2) !important;">Bukti Transaksi</h5><i style="opacity:0.5;color: #eee;"> (Opsional)</i>
                            </div>
                            <div class="form-group pt-3">
                                <p style="font-size: 12px;color:var(--warna_2) !important;">Opsional : Masukkan email kalian jika ingin mendapatkan bukti transaksi & promo menarik lainnya</p>

                                <input type="email" name="email_order" placeholder="Alamat E-Mail" class="form-control"
                                    value="">

                                <small class="mt-2 d-block mb-3 white" style="color:var(--warna_2) !important;">
                                    Dengan membeli otomatis saya menyutujui <a
                                        href="<?= base_url(); ?>/syarat-ketentuan/" target="_blank" style="color: var(--warna_5);">Ketentuan
                                        Layanan
                                        <?= $web['name']; ?>
                                    </a>.
                                </small>
                                <div class="g-recaptcha mt-3 mb-3" data-sitekey="<?= $sitekey ?>" id="recaptcha" hidden></div>

                            </div>
                        </div>
                    </div>
                </div>


                <div class="modal fade" id="modal-detail">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content animated bounceIn" style="background: var(--warna_3);color: #fff !important;">
                            <div class="card-header border-bottom-0">
                                <h5 class="text-white">Detail Pembelian</h5>
                            </div>
                            <div class="modal-body pt-0">

                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade hanz-modal" id="modal-loading" style="">
                    <div class="modal-dialog modal-dialog-centered text-center hanzmodal-dialog"
                        style="max-width: 155px;">
                        <img src="https://usagif.com/wp-content/uploads/loading-11.gif.webp" alt="" width="155"
                            style="border-radius: 40px;">
                    </div>
                </div>

                <input type="hidden" id="product_id" value="0">
            </div>
        </div>
    </div>
</div>
<?php $this->endSection(); ?>

<?php $this->section('js'); ?>

<script>
    var imageModalButton = document.getElementById('imageModalButton');
    var imageModal = new bootstrap.Modal(document.getElementById('imageModal'));

    var tooltipImage = document.getElementById('tooltipImage');
    var imageTooltipContainer = document.getElementById('imageTooltipContainer');

    tooltipImage.onload = function () {
        imageTooltipContainer.style.display = 'block';
    };

    tooltipImage.onerror = function () {
        imageTooltipContainer.style.display = 'none';
    };

    if (tooltipImage.complete && tooltipImage.naturalWidth !== 0) {
        imageTooltipContainer.style.display = 'block';
    }

    imageModalButton.addEventListener('click', function () {
        if (window.innerWidth <= 1000) {
            imageModal.show();
        }
    });
</script>

<script>
    document.querySelectorAll('input[name="user_id"], input[name="zone_id"], input[name="email_order"]').forEach(function(input) {
      input.addEventListener('input', function() {
        var gameName = '<?= $games['games']; ?>'; 
        localStorage.setItem(gameName + '-' + this.name, this.value);
      });
    });
    
    window.addEventListener('load', function() {
      var gameName = '<?= $games['games']; ?>'; 
      document.querySelectorAll('input[name="user_id"], input[name="zone_id"], input[name="email_order"]').forEach(function(input) {
        var savedValue = localStorage.getItem(gameName + '-' + input.name);
        if (savedValue) {
          input.value = savedValue;
        }
      });
    });
</script>

<script type="text/javascript">
$(document).ready(function() {
    // Set the initial price
    var initialPrice = $('input[name="product"]:checked').siblings('label').find('.currency-idr').text();
    $('#nominal-text').text(initialPrice);

    // Handle product radio button change event
    $('input[name="product"]').on('change', function() {
        // Check if the radio button is checked
        if ($(this).is(':checked')) {
            // Get the price from the selected product
            var price = $(this).siblings('label').find('.currency-idr').text();
            // Set the price to the nominal-text element if method radio button is not checked
            if (!$('input[name="method"]').is(':checked')) {
                $('#nominal-text').text(price);
            }
        }
    });

    // Handle method radio button change event
    $('input[name="method"]').on('change', function() {
        // Check if the radio button is checked
        if ($(this).is(':checked')) {
            // Get the price from the selected method
            var price = $(this).siblings('label').find('.harga-price-method').text();
            // Set the price to the nominal-text element
            $('#nominal-text').text(price);
        }
    });

    // Observe changes to harga-price-method elements using MutationObserver
    var hargaPriceMethodObserver = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            // Get the changed price element
            var changedPriceElement = $(mutation.target);
            // Check if the changed price element is part of the selected method radio button
            if (changedPriceElement.parents('label').siblings('input[name="method"]').is(
                    ':checked')) {
                // Get the new price from the changed price element
                var newPrice = changedPriceElement.text();
                // Set the price to the nominal-text element
                $('#nominal-text').text(newPrice);
            }
        });
    });

    // Observe all harga-price-method elements for changes
    $('.harga-price-method').each(function() {
        hargaPriceMethodObserver.observe(this, {
            subtree: true,
            characterData: true,
            childList: true
        });
    });
});

// Helper function to parse number from string
function parseNumber(str) {
    return parseInt(str.replace(/[^\d]/g, ''));
}
</script>

<!-- Facebook Pixel Code -->
<!--<script>-->
<!--  !function(f,b,e,v,n,t,s)-->
<!--  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?-->
<!--  n.callMethod.apply(n,arguments):n.queue.push(arguments)};-->
<!--  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';-->
<!--  n.queue=[];t=b.createElement(e);t.async=!0;-->
<!--  t.src=v;s=b.getElementsByTagName(e)[0];-->
<!--  s.parentNode.insertBefore(t,s)}(window, document,'script',-->
<!--  'https://connect.facebook.net/en_US/fbevents.js');-->
  
<!--  fbq('init', '{938473200580408}');-->
<!--  fbq('init', '{9532506813488688}');-->
<!--  fbq('init', '{584979920420062}');-->
<!--  fbq('track', 'ViewContent');-->
<!--</script>-->
<!--<noscript>-->
<!--  <img height="1" width="1" style="display:none" -->
<!--       src="https://www.facebook.com/tr?id={938473200580408}&ev=ViewContent&noscript=1"/>-->
<!--  <img height="1" width="1" style="display:none" -->
<!--       src="https://www.facebook.com/tr?id={9532506813488688}&ev=ViewContent&noscript=1"/>-->
<!--       <img height="1" width="1" style="display:none" -->
<!--       src="https://www.facebook.com/tr?id={584979920420062}&ev=ViewContent&noscript=1"/>-->
<!--</noscript>-->
<!-- End Facebook Pixel Code -->


<script>
// Get the value of the diamonds parameter from the URL
const urlParams = new URLSearchParams(window.location.search);
const diamonds = urlParams.get('diamonds');

// If the diamonds parameter is present, find the corresponding radio button and check it
if (diamonds) {
    const radio = document.querySelector(`input[type=radio][value="${diamonds}"]`);
    if (radio) {
        radio.checked = true;
        // Scroll to the selected product
        const productDiv = radio.closest('.col-sm-4');
        if (productDiv) {
            const rect = productDiv.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            if (rect.bottom > windowHeight) {
                // The bottom of the product div is below the bottom of the viewport,
                // so adjust the scroll position to align the bottom of the div with
                // the bottom of the viewport
                window.scrollTo(0, window.scrollY + rect.bottom - windowHeight);
            } else if (rect.top < 0) {
                // The top of the product div is above the top of the viewport,
                // so adjust the scroll position to align the top of the div with
                // the top of the viewport
                window.scrollTo(0, window.scrollY + rect.top);
            }
        }
    }
}
</script>

<script>
<!-- 
var enableDisable = function() {
    var UTC_hours = new Date().getUTCHours(); //Don't add 1 here       
    var day = new Date().getUTCDay(); //Use UTC here also

    if (day != 1 && UTC_hours >= 15 && UTC_hours < 20) {
        $('#price-method-3').replaceWith("Bank sedang offline, kembali online pukul 03.00 WIB");

        $('#method-3-label').addClass('cutoffbank');



    } else {
        $('#method-3-label').removeClass('cutoffbank');
    }
};

setInterval(enableDisable, 1000 * 60);
enableDisable();
// 
-->
</script>
<script>
$('.currency-idr').each(function() {
    var monetary_value = $(this).text();
    var i = new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
    }).format(monetary_value);
    $(this).text(i);
});

$('.currency-idr-2').each(function() {
    var monetary_value = $(this).text();
    var i = new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
    }).format(monetary_value);
    $(this).text(i);
});

function parseNumber(strg) {
    var strg = strg || "";
    var decimal = '.';
    strg = strg.replace(/[^0-9$.,]/g, '');
    if (strg.indexOf(',') > strg.indexOf('.')) decimal = ',';
    if ((strg.match(new RegExp("\\" + decimal, "g")) || []).length > 1) decimal = "";
    if (decimal !== "" && (strg.length - strg.indexOf(decimal) - 1 == 3) && strg.indexOf("0" + decimal) !== 0) decimal =
        "";
    strg = strg.replace(new RegExp("[^0-9$" + decimal + "]", "g"), "");
    strg = strg.replace(',', '.');
    return parseFloat(strg);
}



function get_price(id = null) {

    <?php if ($games['target'] == 'joki'): ?>
    var jumlah = $("#jumlah_star_poin").val();
    <?php elseif ($games['target'] == 'videomontage'): ?>
    var jumlah = $("#jumlah_menit").val();
    <?php elseif ($games['target'] == 'growtopia'): ?>
    var jumlah = $("#jumlah_star_poin").val();
    <?php else: ?>
    var jumlah = 1;
    <?php endif; ?>


    $("#product_id").val(id);

    $.ajax({
        url: '<?= base_url(); ?>/games/order/get-price/' + id,
        type: 'POST',
        data: 'jumlah=' + jumlah,
        dataType: 'JSON',
        success: function(result) {
            for (let price in result) {
                $("#price-method-" + result[price].method).text('Rp ' + result[price].price);
               if (result[price].price_disc && result[price].price_member) {
                var balanceValue = parseNumber(result[price].price_member);
                var balancediscValue = parseNumber(result[price].price_disc);
                var diskonPersen = ((balancediscValue - balanceValue) / balancediscValue) * 100;
                var diskonText = diskonPersen < 0 ? diskonPersen.toFixed(2) + "%" : "-" + diskonPersen.toFixed(2) + "%";
                $("#price-disc-method-" + result[price].method).text('Rp ' + result[price].price_disc);
                $("#price-member-method-" + result[price].method).text('Rp ' + result[price].price_member);
                $("#price-diskon-method-" + result[price].method).text(diskonText);
                }
                
                var harga = parseNumber(result[price].price);
                var textinfo = (result[price].info);

                var balance = document.getElementById("price-member-method-balance");
                var balancedisc = document.getElementById("price-disc-method-balancedisc");
                var diskonPersen = document.getElementById("price-diskon-method");
                
                var BCATransfer = document.getElementById("price-method-Manual-BCATransfer");
                var BNITransfer = document.getElementById("price-method-Manual-BNITransfer");
                var BRITransfer = document.getElementById("price-method-Manual-BRITransfer");
                var MandiriTransfer = document.getElementById("price-method-Manual-Gopay");
                var BCAQRIS = document.getElementById("price-method-Manual-QRIS");

                var qrisc = document.getElementById("price-method-Tripay-QRISC");
                var qris1 = document.getElementById("price-method-Tripay-QRIS");
                var ovo = document.getElementById("price-method-Tripay-OVO");
                var tdana = document.getElementById("price-method-Tripay-DANA");
                var shopee = document.getElementById("price-method-Tripay-SHOPEEPAY");
                var vabsi = document.getElementById("price-method-Tripay-BSIVA");
                var vabni = document.getElementById("price-method-Tripay-BNIVA");
                var vapermata = document.getElementById("price-method-Tripay-PERMATAVA");
                var vamandiri = document.getElementById("price-method-Tripay-MANDIRIVA");
                var vabri = document.getElementById("price-method-Tripay-BRIVA");
                var vabca = document.getElementById("price-method-Tripay-BCAVA");
                var indomaret = document.getElementById("price-method-Tripay-INDOMARET");
                var alfamart = document.getElementById("price-method-Tripay-ALFAMART");
                var alfamidi = document.getElementById("price-method-Tripay-ALFAMIDI");

                var qrisd = document.getElementById("price-method-Duitku-LQ");
                var qrisspd = document.getElementById("price-method-Duitku-SP");
                var ovod = document.getElementById("price-method-Duitku-OV");
                var danad = document.getElementById("price-method-Duitku-DA");
                var shopeed = document.getElementById("price-method-Duitku-SA");
                var linkajad = document.getElementById("price-method-Duitku-LA");
                var vaatmd = document.getElementById("price-method-Duitku-A1");
                var vabnid = document.getElementById("price-method-Duitku-I1");
                var dvabri = document.getElementById("price-method-Duitku-BR");
                var vamayd = document.getElementById("price-method-Duitku-VA");
                var vapermatad = document.getElementById("price-method-Duitku-BT");
                var vacimbd = document.getElementById("price-method-Duitku-B1");
                var vaagd = document.getElementById("price-method-Duitku-AG");
                var vabncd = document.getElementById("price-method-Duitku-NC");
                var alfamartd = document.getElementById("price-method-Duitku-FT");
                var vamandirid = document.getElementById("price-method-Duitku-M2");
                var vaarthagrahad = document.getElementById("price-method-Duitku-AG");

                var qrissl = document.getElementById("price-method-Smartlink-WALLET_QRIS");
                var ovosl = document.getElementById("price-method-Smartlink-WALLET_OVO");
                var danasl = document.getElementById("price-method-Smartlink-WALLET_DANA");
                var shopeesl = document.getElementById("price-method-Smartlink-WALLET_SHOPEEPAY");
                var linkajasl = document.getElementById("price-method-Smartlink-WALLET_LINKAJA");
                var ccvisasl = document.getElementById("price-method-Smartlink-CC_VISA");
                var alfamartsl = document.getElementById("price-method-Smartlink-OTC_ALFAMART");
                var indomaretsl = document.getElementById("price-method-Smartlink-OTC_INDOMARET");
                var vabnisl = document.getElementById("price-method-Smartlink-VA_BNI");
                var vabrisl = document.getElementById("price-method-Smartlink-VA_BRI");
                var vabncsl = document.getElementById("price-method-Smartlink-VA_BNC");
                var vacimbsl = document.getElementById("price-method-Smartlink-VA_CIMB");
                var vamandirisl = document.getElementById("price-method-Smartlink-VA_MANDIRI");
                var vapermatasl = document.getElementById("price-method-Smartlink-VA_PERMATA");
                
                var qrislq = document.getElementById("price-method-Linkqu-QRIS");
                var ovolq = document.getElementById("price-method-Linkqu-PAYOVO");
                var danalq = document.getElementById("price-method-Linkqu-PAYDANA");
                var shopeelq = document.getElementById("price-method-Linkqu-PAYSHOPEE");
                var linkajalq = document.getElementById("price-method-Linkqu-PAYLINKAJA");
                var alfamartlq = document.getElementById("price-method-Linkqu-ALFAMART");
                var indomaretlq = document.getElementById("price-method-Linkqu-INDOMARET");
                var vapermatalq = document.getElementById("price-method-Linkqu-013");
                var vacimblq = document.getElementById("price-method-Linkqu-022");
                var vadanamonq = document.getElementById("price-method-Linkqu-011");
                var vamandirilq = document.getElementById("price-method-Linkqu-008");
                var vabrilq = document.getElementById("price-method-Linkqu-002");
                var vaneolq = document.getElementById("price-method-Linkqu-490");
                var vabsilq = document.getElementById("price-method-Linkqu-451");
                var vabnilq = document.getElementById("price-method-Linkqu-009");
                var vabcalq = document.getElementById("price-method-Linkqu-014");
                var vamaybanklq = document.getElementById("price-method-Linkqu-016");

                var qrisx = document.getElementById("price-method-Xendit-ID_DANAqris");
                var ovox = document.getElementById("price-method-Xendit-ID_OVO");
                var danax = document.getElementById("price-method-Xendit-ID_DANAewallet");
                var shopeex = document.getElementById("price-method-Xendit-ID_SHOPEEPAY");
                var linkajax = document.getElementById("price-method-Xendit-ID_LINKAJA");
                var astrapayx = document.getElementById("price-method-Xendit-ID_ASTRAPAY");
                var vabcax = document.getElementById("price-method-Xendit-BCA");
                var vabnix = document.getElementById("price-method-Xendit-BNI");
                var vamandirix = document.getElementById("price-method-Xendit-MANDIRI");
                var vabrix = document.getElementById("price-method-Xendit-BRI");
                var vapermatax = document.getElementById("price-method-Xendit-PERMATA");
                var vaBJBx = document.getElementById("price-method-Xendit-BJB");
                var vaBSIx = document.getElementById("price-method-Xendit-BSI");
                var vaSAHABAT_SAMPOERNA = document.getElementById("price-method-Xendit-SAHABAT_SAMPOERNA");
                var indomaretx = document.getElementById("price-method-Xendit-INDOMARET");
                var alfamartx = document.getElementById("price-method-Xendit-ALFAMART");
                
                var tpqris = document.getElementById("price-method-Tokopay-QRIS");
                var tpqrisrt = document.getElementById("price-method-Tokopay-QRISREALTIME");
                var tpqriscs = document.getElementById("price-method-Tokopay-QRIS_CUSTOM");
                var tpbcava = document.getElementById("price-method-Tokopay-BCAVA");
                var tpmandiriva = document.getElementById("price-method-Tokopay-MANDIRIVA");
                var tpbniva = document.getElementById("price-method-Tokopay-BNIVA");
                var tpcimbva = document.getElementById("price-method-Tokopay-CIMBVA");
                var tppermatava = document.getElementById("price-method-Tokopay-PERMATAVA");
                var tpbriva = document.getElementById("price-method-Tokopay-BRIVA");
                var tpbncva = document.getElementById("price-method-Tokopay-BNCVA");
                var tpdanamonva = document.getElementById("price-method-Tokopay-DANAMONVA");
                var tpbsiva = document.getElementById("price-method-Tokopay-BSIVA");
                var tppermatavaa = document.getElementById("price-method-Tokopay-PERMATAVAA");
                var tpalfamart = document.getElementById("price-method-Tokopay-ALFAMART");
                var tpindomaret = document.getElementById("price-method-Tokopay-INDOMARET");
                var tpgopay = document.getElementById("price-method-Tokopay-GOPAY");
                var tpovo = document.getElementById("price-method-Tokopay-OVOPUSH");
                var tpshopee = document.getElementById("price-method-Tokopay-SHOPEEPAY");
                var tpdana = document.getElementById("price-method-Tokopay-DANA");
                var tpvirgo = document.getElementById("price-method-Tokopay-VIRGO");
                var tpastrapay = document.getElementById("price-method-Tokopay-ASTRAPAY");
                var tplinkaja = document.getElementById("price-method-Tokopay-LINKAJA");
                var tptelkom = document.getElementById("price-method-Tokopay-TELKOMSEL");
                var tpaxis = document.getElementById("price-method-Tokopay-AXIS");
                var tpxl = document.getElementById("price-method-Tokopay-XL");
                var tptri = document.getElementById("price-method-Tokopay-TRI");
                var tpdanacs = document.getElementById("price-method-Tokopay-DANA_CUSTOM");
                var tpshopeecs = document.getElementById("price-method-Tokopay-SHOPEE_CUSTOM");
                var tpovocs = document.getElementById("price-method-Tokopay-OVO_CUSTOM");
                var tplinkajacs = document.getElementById("price-method-Tokopay-LINKAJA_CUSTOM");
                
                if (tpqris !== null) {tpqris.innerHTML = 'Rp ' + (Math.round((harga*1.007)+100)).toLocaleString('id-ID');} 
                if (tpqrisrt !== null) {tpqrisrt.innerHTML = 'Rp ' + (Math.round(harga*1.017)).toLocaleString('id-ID');}
                if (tpqriscs !== null) {tpqriscs.innerHTML = 'Rp ' + (Math.round((harga*1.007)+250)).toLocaleString('id-ID');}
                if (tpbcava !== null) {tpbcava.innerHTML = 'Rp ' + (Math.round(harga+4200)).toLocaleString('id-ID');} 
                if (tpmandiriva !== null) {tpmandiriva.innerHTML = 'Rp ' + (Math.round(harga+3500)).toLocaleString('id-ID');}
                if (tpbniva !== null) {tpbniva.innerHTML = 'Rp ' + (Math.round(harga+3500)).toLocaleString('id-ID');}
                if (tpcimbva !== null) {tpcimbva.innerHTML = 'Rp ' + (Math.round(harga+2500)).toLocaleString('id-ID');}
                if (tppermatava !== null) {tppermatava.innerHTML = 'Rp ' + (Math.round(harga+2000)).toLocaleString('id-ID');}
                if (tpbriva !== null) {tpbriva.innerHTML = 'Rp ' + (Math.round(harga+3000)).toLocaleString('id-ID');}
                if (tpbncva !== null) {tpbncva.innerHTML = 'Rp ' + (Math.round(harga+3000)).toLocaleString('id-ID');}
                if (tpdanamonva !== null) {tpdanamonva.innerHTML = 'Rp ' + (Math.round(harga+2500)).toLocaleString('id-ID');}
                if (tpbsiva !== null) {tpbsiva.innerHTML = 'Rp ' + (Math.round(harga+3500)).toLocaleString('id-ID');}
                if (tppermatavaa !== null) {tppermatavaa.innerHTML = 'Rp ' + (Math.round(harga+3000)).toLocaleString('id-ID');}
                if (tpalfamart !== null) {tpalfamart.innerHTML = 'Rp ' + (Math.round(harga+3000)).toLocaleString('id-ID');}
                if (tpindomaret !== null) {tpindomaret.innerHTML = 'Rp ' + (Math.round(harga+3000)).toLocaleString('id-ID');}
                if (tpgopay !== null) {tpgopay.innerHTML = 'Rp ' + (Math.round(harga*1.03)).toLocaleString('id-ID');}
                if (tpovo !== null) {tpovo.innerHTML = 'Rp ' + (Math.round(harga*1.025)).toLocaleString('id-ID');}
                if (tpshopee !== null) {tpshopee.innerHTML = 'Rp ' + (Math.round(harga*1.025)).toLocaleString('id-ID');} 
                if (tpdana !== null) {tpdana.innerHTML = 'Rp ' + (Math.round(harga*1.025)).toLocaleString('id-ID');}
                if (tplinkaja !== null) {tplinkaja.innerHTML = 'Rp ' + (Math.round(harga*1.03)).toLocaleString('id-ID');}
                if (tpvirgo !== null) {tpvirgo.innerHTML = 'Rp ' + (Math.round(harga*1.02)).toLocaleString('id-ID');}
                if (tpastrapay !== null) {tpastrapay.innerHTML = 'Rp ' + (Math.round(harga*1.028)).toLocaleString('id-ID');}
                if (tptelkom !== null) {tptelkom.innerHTML = 'Rp ' + (Math.ceil(harga * 1.32 / 1000) * 1000).toLocaleString('id-ID');}
                if (tpaxis !== null) {tpaxis.innerHTML = 'Rp ' + (Math.ceil(harga * 1.25 / 1000) * 1000).toLocaleString('id-ID');}
                if (tpxl !== null) {tpxl.innerHTML = 'Rp ' + (Math.ceil(harga * 1.25 / 1000) * 1000).toLocaleString('id-ID');}
                if (tptri !== null) {tptri.innerHTML = 'Rp ' + (Math.ceil(harga * 1.25 / 1000) * 1000).toLocaleString('id-ID');}
                if (tpdanacs !== null) {tpdanacs.innerHTML = 'Rp ' + (Math.round(harga*1.028)).toLocaleString('id-ID');}
                if (tpshopeecs !== null) {tpshopeecs.innerHTML = 'Rp ' + (Math.round(harga*1.025)).toLocaleString('id-ID');}
                if (tpovocs !== null) {tpovocs.innerHTML = 'Rp ' + (Math.round(harga*1.025)).toLocaleString('id-ID');}
                if (tplinkajacs !== null) {tplinkajacs.innerHTML = 'Rp ' + (Math.round(harga*1.025)).toLocaleString('id-ID');}

                if (balance !== null && result[price].price_member) {
                    balance.innerHTML = 'Rp ' + (Math.round((parseNumber(result[price].price_member)))).toLocaleString('id-ID');
                }
                
                if (balancedisc !== null && result[price].price_disc) {
                    balancedisc.innerHTML = 'Rp ' + (Math.round((parseNumber(result[price].price_disc)))).toLocaleString('id-ID');
                }

                if (qrisd !== null) {
                    qrisd.innerHTML = 'Rp ' + (Math.round((harga * 1.007) + 0)).toLocaleString('id-ID');
                }
                if (qrisspd !== null) {
                    qrisspd.innerHTML = 'Rp ' + (Math.round((harga * 1.007) + 0)).toLocaleString('id-ID');
                }
                if (ovod !== null) {
                    ovod.innerHTML = 'Rp ' + (Math.round(harga * 1.0167)).toLocaleString('id-ID');
                }
                if (danad !== null) {
                    danad.innerHTML = 'Rp ' + (Math.round(harga * 1.0167)).toLocaleString('id-ID');
                }
                if (shopeed !== null) {
                    shopeed.innerHTML = 'Rp ' + (Math.round(harga * 1.04)).toLocaleString('id-ID');
                }
                if (linkajad !== null) {
                    linkajad.innerHTML = 'Rp ' + (Math.round(harga * 1.0167)).toLocaleString('id-ID');
                }
                if (vaatmd !== null) {
                    vaatmd.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vaagd !== null) {
                    vaagd.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vabncd !== null) {
                    vabncd.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vabnid !== null) {
                    vabnid.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (dvabri !== null) {
                    dvabri.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vamayd !== null) {
                    vamayd.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vapermatad !== null) {
                    vapermatad.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vacimbd !== null) {
                    vacimbd.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (alfamartd !== null) {
                    alfamartd.innerHTML = 'Rp ' + (Math.round(harga + 2500)).toLocaleString('id-ID');
                }
                if (vamandirid !== null) {
                    vamandirid.innerHTML = 'Rp ' + (Math.round(harga + 4000)).toLocaleString('id-ID');
                }
                if (vaarthagrahad !== null) {
                    vaarthagrahad.innerHTML = 'Rp ' + (Math.round(harga + 1500)).toLocaleString('id-ID');
                }

                if (qrisx !== null) {
                    qrisx.innerHTML = 'Rp ' + (Math.round((harga * 1.007) + 0)).toLocaleString('id-ID');
                }
                if (ovox !== null) {
                    ovox.innerHTML = 'Rp ' + (Math.round(harga * 1.007)).toLocaleString('id-ID');
                }
                if (shopeex !== null) {
                    shopeex.innerHTML = 'Rp ' + (Math.round(harga * 1.007)).toLocaleString('id-ID');
                }
                if (danax !== null) {
                    danax.innerHTML = 'Rp ' + (Math.round(harga * 1.007)).toLocaleString('id-ID');
                }
                if (linkajax !== null) {
                    linkajax.innerHTML = 'Rp ' + (Math.round(harga * 1.007)).toLocaleString('id-ID');
                }
                if (astrapayx !== null) {
                    astrapayx.innerHTML = 'Rp ' + (Math.round(harga * 1.007)).toLocaleString('id-ID');
                }
                if (vabnix !== null) {
                    vabnix.innerHTML = 'Rp ' + (Math.round(harga + 5000)).toLocaleString('id-ID');
                }
                if (vapermatax !== null) {
                    vapermatax.innerHTML = 'Rp ' + (Math.round(harga + 5000)).toLocaleString('id-ID');
                }
                if (vamandirix !== null) {
                    vamandirix.innerHTML = 'Rp ' + (Math.round(harga + 5000)).toLocaleString('id-ID');
                }
                if (vabrix !== null) {
                    vabrix.innerHTML = 'Rp ' + (Math.round(harga + 5000)).toLocaleString('id-ID');
                }
                if (vabcax !== null) {
                    vabcax.innerHTML = 'Rp ' + (Math.round(harga + 5000)).toLocaleString('id-ID');
                }
                if (vaBJBx !== null) {
                    vaBJBx.innerHTML = 'Rp ' + (Math.round(harga + 5000)).toLocaleString('id-ID');
                }
                if (vaBSIx !== null) {
                    vaBSIx.innerHTML = 'Rp ' + (Math.round(harga + 5000)).toLocaleString('id-ID');
                }
                if (vaSAHABAT_SAMPOERNA !== null) {
                    vaSAHABAT_SAMPOERNA.innerHTML = 'Rp ' + (Math.round(harga + 5000)).toLocaleString(
                        'id-ID');
                }
                if (indomaretx !== null) {
                    indomaretx.innerHTML = 'Rp ' + (Math.round(harga + 6000)).toLocaleString('id-ID');
                }
                if (alfamartx !== null) {
                    alfamartx.innerHTML = 'Rp ' + (Math.round(harga + 6000)).toLocaleString('id-ID');
                }

                if (qrissl !== null) {
                    qrissl.innerHTML = 'Rp ' + (Math.round((harga * 1.01) + 0)).toLocaleString('id-ID');
                }
                if (ovosl !== null) {
                    ovosl.innerHTML = 'Rp ' + (Math.round(harga * 1.04)).toLocaleString('id-ID');
                }
                if (danasl !== null) {
                    danasl.innerHTML = 'Rp ' + (Math.round(harga * 1.04)).toLocaleString('id-ID');
                }
                if (shopeesl !== null) {
                    shopeesl.innerHTML = 'Rp ' + (Math.round(harga * 1.04)).toLocaleString('id-ID');
                }
                if (linkajasl !== null) {
                    linkajasl.innerHTML = 'Rp ' + (Math.round(harga * 1.04)).toLocaleString('id-ID');
                }
                if (ccvisasl !== null) {
                    ccvisasl.innerHTML = 'Rp ' + (Math.round(harga * 1.0275)).toLocaleString('id-ID');
                }
                if (alfamartsl !== null) {
                    alfamartsl.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                if (indomaretsl !== null) {
                    indomaretsl.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                if (vabnisl !== null) {
                    vabnisl.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                if (vabrisl !== null) {
                    vabrisl.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                if (vabncsl !== null) {
                    vabncsl.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                if (vacimbsl !== null) {
                    vacimbsl.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                if (vamandirisl !== null) {
                    vamandirisl.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                if (vapermatasl !== null) {
                    vapermatasl.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                
                
                if (qrislq !== null) {
                    qrislq.innerHTML = 'Rp ' + (Math.round((harga * 1.007) + 0)).toLocaleString('id-ID');
                }
                if (ovolq !== null) {
                    ovolq.innerHTML = 'Rp ' + (Math.round(harga * 1.018) + 1000).toLocaleString('id-ID');
                }
                if (danalq !== null) {
                    danalq.innerHTML = 'Rp ' + (Math.round(harga * 1.018) + 1000).toLocaleString('id-ID');
                }
                if (shopeelq !== null) {
                    shopeelq.innerHTML = 'Rp ' + (Math.round(harga * 1.023) + 1000).toLocaleString('id-ID');
                }
                if (linkajalq !== null) {
                    linkajalq.innerHTML = 'Rp ' + (Math.round(harga * 1.018) + 1000).toLocaleString('id-ID');
                }
                if (alfamartlq !== null) {
                    alfamartlq.innerHTML = 'Rp ' + (Math.round(harga + 1500)).toLocaleString('id-ID');
                }
                if (indomaretlq !== null) {
                    indomaretlq.innerHTML = 'Rp ' + (Math.round(harga + 1500)).toLocaleString('id-ID');
                }
                if (vapermatalq !== null) {
                    vapermatalq.innerHTML = 'Rp ' + (Math.round(harga + 2500)).toLocaleString('id-ID');
                }
                if (vacimblq !== null) {
                    vacimblq.innerHTML = 'Rp ' + (Math.round(harga + 2500)).toLocaleString('id-ID');
                }
                if (vadanamonq !== null) {
                    vadanamonq.innerHTML = 'Rp ' + (Math.round(harga + 2500)).toLocaleString('id-ID');
                }
                if (vamandirilq !== null) {
                    vamandirilq.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vabrilq !== null) {
                    vabrilq.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vaneolq !== null) {
                    vaneolq.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vabsilq !== null) {
                    vabsilq.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vabnilq !== null) {
                    vabnilq.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                if (vabcalq !== null) {
                    vabcalq.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                if (vamaybanklq !== null) {
                    vamaybanklq.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }



                if (BCATransfer !== null) {
                    BCATransfer.innerHTML = 'Rp ' + (Math.round((harga * 1))).toLocaleString('id-ID');
                }
                if (BNITransfer !== null) {
                    BNITransfer.innerHTML = 'Rp ' + (Math.round((harga * 1))).toLocaleString('id-ID');
                }
                if (BRITransfer !== null) {
                    BRITransfer.innerHTML = 'Rp ' + (Math.round((harga * 1))).toLocaleString('id-ID');
                }
                if (MandiriTransfer !== null) {
                    MandiriTransfer.innerHTML = 'Rp ' + (Math.round((harga * 1))).toLocaleString('id-ID');
                }
                if (BCAQRIS !== null) {
                    BCAQRIS.innerHTML = 'Rp ' + (Math.round((harga * 1.007) + 800)).toLocaleString('id-ID');
                }
                

                if (qrisc !== null) {
                    qrisc.innerHTML = 'Rp ' + (Math.round((harga * 1.007) + 800)).toLocaleString('id-ID');
                }
                if (qris1 !== null) {
                    qris1.innerHTML = 'Rp ' + (Math.round((harga * 1.007) + 750)).toLocaleString('id-ID');
                }
                if (ovo !== null) {
                    ovo.innerHTML = 'Rp ' + (Math.round(harga * 1.03)).toLocaleString('id-ID');
                }
                if (tdana) {
                    tdana.innerHTML = 'Rp ' + (Math.round(harga * 1.03)).toLocaleString('id-ID');
                }
                if (shopee !== null) {
                    shopee.innerHTML = 'Rp ' + (Math.round(harga * 1.03)).toLocaleString('id-ID');
                }
                if (vabsi !== null) {
                    vabsi.innerHTML = 'Rp ' + (Math.round(harga + 4250)).toLocaleString('id-ID');
                }
                if (vabni !== null) {
                    vabni.innerHTML = 'Rp ' + (Math.round(harga + 4250)).toLocaleString('id-ID');
                }
                if (vabca !== null) {
                    vabca.innerHTML = 'Rp ' + (Math.round(harga + 5500)).toLocaleString('id-ID');
                }
                if (vapermata !== null) {
                    vapermata.innerHTML = 'Rp ' + (Math.round(harga + 4250)).toLocaleString('id-ID');
                }
                if (vamandiri !== null) {
                    vamandiri.innerHTML = 'Rp ' + (Math.round(harga + 4250)).toLocaleString('id-ID');
                }
                if (vabri !== null) {
                    vabri.innerHTML = 'Rp ' + (Math.round(harga + 4250)).toLocaleString('id-ID');
                }
                if (indomaret !== null) {
                    indomaret.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                if (alfamart !== null) {
                    alfamart.innerHTML = 'Rp ' + (Math.round(harga + 6000)).toLocaleString('id-ID');
                }
                if (alfamidi !== null) {
                    alfamidi.innerHTML = 'Rp ' + (Math.round(harga + 6000)).toLocaleString('id-ID');
                }

            }

        }
    });
}

function update_total() {
    get_price($("#product_id").val());
    
     var jumlah_star_poin = document.getElementById("jumlah_star_poin");
    if (jumlah_star_poin.value < 5) {
        jumlah_star_poin.value = 5;
    }
}

function process_order() {
    
    var buyButton = document.getElementById('buyButton');
    buyButton.disabled = true; // Menonaktifkan tombol

    <?php if ($games['target'] == 'joki'): ?>
    var user_id = $('.name-joki').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'skinml'): ?>
    var user_id = $('.name-skinml').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'videomontage'): ?>
    var user_id = $('.name-videomontage').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'topuplogin'): ?>
    var user_id = $('.name-topuplogin').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-ragnarox'): ?>
    var user_id = $('.name-lg-ragnarox').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-dragonhunter'): ?>
    var user_id = $('.name-lg-dragonhunter').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-fourgods'): ?>
    var user_id = $('.name-lg-fourgods').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-genshinimpact'): ?>
    var user_id = $('.name-lg-genshinimpact').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-ninokuni'): ?>
    var user_id = $('.name-lg-ninokuni').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-neverafter'): ?>
    var user_id = $('.name-lg-neverafter').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-clashofclans'): ?>
    var user_id = $('.name-lg-clashofclans').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginapex'): ?>
    var user_id = $('.name-loginapex').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginefootball'): ?>
    var user_id = $('.name-loginefootball').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginff'): ?>
    var user_id = $('.name-loginff').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'logingenshin'): ?>
    var user_id = $('.name-logingenshin').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginml'): ?>
    var user_id = $('.name-loginml').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginninokuni'): ?>
    var user_id = $('.name-loginninokuni').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginpokemon'): ?>
    var user_id = $('.name-loginpokemon').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginraven'): ?>
    var user_id = $('.name-loginraven').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'logintiktok'): ?>
    var user_id = $('.name-logintiktok').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'logintower'): ?>
    var user_id = $('.name-logintower').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginwildrift'): ?>
    var user_id = $('.name-loginwildrift').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);
    
    <?php elseif ($games['target'] == 'growtopia'): ?>
    var user_id = $('.name-growtopia').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'tournament'): ?>
    var user_id = $('.name-tournament').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php else: ?>
    var user_id = $("input[name=user_id]").val();
    var zone_id = $("input[name=zone_id]").val();
    <?php endif; ?>

    if (zone_id == undefined) {
        zone_id = $("select[name=zone_id]").val();
    }

    if (user_id == undefined) {
        user_id = $("select[name=user_id]").val();
    }

    var product = $("input[name=product]:checked").val();
    var method = $("input[name=method]:checked").val();
    var voucher = $("input[name=voucher]").val();
    var email_order = $("input[name=email_order]").val();
    // var recaptchaResponse = grecaptcha.getResponse();
    var wa = $("input[name=wa]").val();
    
    if (wa == undefined) {
        wa = '';
    }

    <?php if ($games['target'] == 'joki'): ?>
    var jumlah = $("#jumlah_star_poin").val();
    <?php elseif ($games['target'] == 'videomontage'): ?>
    var jumlah = $("#jumlah_menit").val();
    <?php elseif ($games['target'] == 'growtopia'): ?>
    var jumlah = $("#jumlah_star_poin").val();
    <?php else: ?>
    var jumlah = 1;
    <?php endif; ?>

    if (user_id == '' || user_id == ' ') {
        Swal.fire({
            title: 'Gagal',
            text: 'ID Player harus diisi',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "var(--warna_4)",
            
            
        });
        buyButton.disabled = false;
    } else if (zone_id == '' || zone_id == ' ') {
        Swal.fire({
            title: 'Gagal',
            text: 'ID Player harus diisi',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "var(--warna_4)",
            
            
        });
        buyButton.disabled = false;
    } else if (product == '' || product == ' ') {
        Swal.fire({
            title: 'Gagal',
            text: 'Nominal produk harus dipilih',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "var(--warna_4)",
            
            
        });
        buyButton.disabled = false;
    } else if (method == '' || method == ' ') {
        Swal.fire({
            title: 'Gagal',
            text: 'Pilih metode pembayaran',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "var(--warna_4)",
            
            
        });
        buyButton.disabled = false;
    } else {
        $.ajax({
            url: '<?= base_url(); ?>/games/order/get-detail/' + product,
            data: 'user_id=' + user_id + '&zone_id=' + zone_id + '&method=' + method + '&email_order=' + email_order + '&wa=' + wa + 
                '&voucher=' + voucher + '&target=<?= $games['target'] ?>' + '&jumlah=' + jumlah ,
            type: 'POST',
            dataType: 'JSON',
            beforeSend: function() {
                $('#modal-loading').modal('show');
            },
            success: function(result) {

                $('#modal-loading').modal('hide');

                if (result.status == true) {
                    $("#modal-detail div div .modal-body").html(result.msg);

                    $("#modal-detail").modal('show');
                } else {
                    Swal.fire({
                        title: 'Gagal',
                        text: result.msg,
                        icon: 'error',
                        confirmButtonText: 'OKE',
                        confirmButtonColor: "var(--warna_4)",
                        didClose: () => {
                            buyButton.disabled = false; // Aktifkan tombol setelah Swal.fire ditutup
                        }
                    });
                }
            }
        });

        $('#modal-detail').on('shown.bs.modal', function() {
            $("#modal-loading").modal('hide');
        });
    }
    
    $('#modal-detail').on('hidden.bs.modal', function () {
        buyButton.disabled = false; // Mengaktifkan tombol kembali
    });
}

function nonaktif_button() {
    document.getElementById('1xorder').innerHTML = 'Menunggu...';
    document.getElementById('1xorder').style.pointerEvents = 'none';
}

function cek_voucher() {

    var product = $("input[name=product]:checked").val();
    var voucher = $("input[name=voucher]").val();

    <?php if ($games['target'] == 'joki'): ?>
    var jumlah = $("#jumlah_star_poin").val();
    <?php elseif ($games['target'] == 'videomontage'): ?>
    var jumlah = $("#jumlah_menit").val();
    <?php else: ?>
    var jumlah = 1;
    <?php endif; ?>


    if (voucher == '' || voucher == ' ') {
        Swal.fire({
            title: 'Gagal',
            text: 'Kode voucher harus diisi',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "var(--warna_4)",
            
            
        });
    } else if (product == '' || product == ' ') {
        Swal.fire({
            title: 'Gagal',
            text: 'Nominal produk harus dipilih',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "var(--warna_4)",
            
            
        });
    } else if (product == undefined) {
        Swal.fire({
            title: 'Gagal',
            text: 'Nominal produk harus dipilih',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "var(--warna_4)",
            
            
        });
    } else {
        $.ajax({
            url: '<?= base_url(); ?>/games/voucher/' + product,
            data: 'voucher=' + voucher + '&jumlah=' + jumlah,
            type: 'POST',
            dataType: 'JSON',
            success: function(result) {
                if (result.success) {
                    Swal.fire({
                        title: 'Berhasil',
                        text: result.msg,
                        icon: 'success',
                        confirmButtonText: 'OKE',
                        confirmButtonColor: "var(--warna_4)",
                        
                        
                    });
                } else {
                    Swal.fire({
                        title: 'Gagal',
                        text: result.msg,
                        icon: 'error',
                        confirmButtonText: 'OKE',
                        confirmButtonColor: "var(--warna_4)",
                        
                        
                    });
                }
            }
        });
    }
}
</script>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
  $(document).ready(function() {
    // Menanggapi event klik pada elemen <a>
    $(".nav-link").on("click", function() {
      // Mengubah ikon dan menambahkan kelas rotasi
      toggleIcon();
    });

    // Fungsi untuk mengubah ikon
    function toggleIcon() {
      var icon = $(".nav-link").find("iconify-icon");
      var currentIcon = icon.attr("icon");

      // Mengganti ikon berdasarkan keadaan sebelumnya
      if (currentIcon === "subway:up-2") {
        icon.attr("icon", "subway:down-2");
      } else {
        icon.attr("icon", "subway:up-2");
      }

      // Menambahkan atau menghapus kelas rotasi
      icon.parent().toggleClass("rotate");
    }
  });
</script>

<script type="text/javascript" defer="defer">
<!-- 
var enableDisable = function() {
    var UTC_hours = new Date().getUTCHours(); //Don't add 1 here       
    var day = new Date().getUTCDay(); //Use UTC here also

    if (day != 1 && UTC_hours >= 14 && UTC_hours < 20) {
        document.getElementById('bankbca-on').style.display = 'none';
        document.getElementById('bankbca-off').style.display = 'block';
    } else {
        document.getElementById('bankbca-on').style.display = 'block';
        document.getElementById('bankbca-off').style.display = 'none';
    }
};

setInterval(enableDisable, 1000 * 60);
enableDisable();
// 
-->
</script>
<script>
    function get_price_and_scroll(productId) {
        // Call your existing function (get_price)
        get_price(productId);

        // Scroll to the "pembayaran-section"
        var pembayaranSection = document.getElementById('pembayaran-section');
        pembayaranSection.scrollIntoView({ behavior: 'smooth' });
    }
</script>
<?php $this->endSection(); ?>