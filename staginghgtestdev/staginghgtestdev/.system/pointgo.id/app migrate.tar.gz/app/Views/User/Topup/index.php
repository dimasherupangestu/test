<?php $this->extend('template'); ?>

<?php $this->section('css'); ?>
<!-- Facebook Pixel Code -->

<!-- End Facebook Pixel Code -->
<style>
.cutoffbank {
filter: grayscale(1);
pointer-events: none;

}

.cutoffbank p {
font-size: 10px !important;
line-height: 13px;
margin-bottom: 0.5rem !important;
margin-right: 1rem !important;
margin-left: 1rem !important;
font-weight: 600;
}


button.accordion-button.single-payment:focus {
border: 1px solid var(--warna_4);
box-shadow: 0 0 200px rgb(123 172 103 / 47%) inset;
transition: 0.3s ease;
}

.accordion-button[aria-expanded="true"] {
border: 1px solid var(--warna_4);
box-shadow: 0 0 200px rgb(123 172 103 / 47%) inset;
border-bottom-left-radius: 0px;
border-bottom-right-radius: 0px;
}

.text-end {
text-align: right !important;
}

.accordion {
--bs-accordion-color: #000;
--bs-accordion-bg: #fff;
--bs-accordion-transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, border-radius 0.15s ease;
--bs-accordion-border-color: var(--bs-border-color);
--bs-accordion-border-width: 1px;
--bs-accordion-border-radius: 0.375rem;
--bs-accordion-inner-border-radius: calc(0.375rem - 1px);
--bs-accordion-btn-padding-x: 1.25rem;
--bs-accordion-btn-padding-y: 1rem;
--bs-accordion-btn-color: var(--bs-body-color);
--bs-accordion-btn-bg: var(--bs-accordion-bg);
--bs-accordion-btn-icon: url(data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='var%28--bs-body-color%29'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e);
--bs-accordion-btn-icon-width: 1.25rem;
--bs-accordion-btn-icon-transform: rotate(-180deg);
--bs-accordion-btn-icon-transition: transform 0.2s ease-in-out;
--bs-accordion-btn-active-icon: url(data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%230c63e4'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e);
--bs-accordion-btn-focus-border-color: #86b7fe;
--bs-accordion-btn-focus-box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
--bs-accordion-body-padding-x: 1.25rem;
--bs-accordion-body-padding-y: 1rem;
--bs-accordion-active-color: #0c63e4;
--bs-accordion-active-bg: #e7f1ff;
}


.boks {
box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
border-radius: 6px;
}

.accordion-button {
position: relative;
display: flex;
align-items: center;
width: 100%;
padding: var(--bs-accordion-btn-padding-y) var(--bs-accordion-btn-padding-x);
font-size: 1rem;
color: var(--bs-accordion-btn-color);
text-align: left;
background-color: var(--bs-accordion-btn-bg);
border: 0;
border-radius: 0;
overflow-anchor: none;
transition: var(--bs-accordion-transition);
}

.accordion-button iconify-icon.pl-1 {
transform: rotateX(177deg);
transition: 0.2s ease;
}

.accordion-button.collapsed iconify-icon.pl-1 {
transform: rotateX(0deg);
transition: 0.2s ease;
}

.single-payment .radio-nominal:checked + label {
border: 2px solid var(--warna_4) !important;
box-shadow: 0 0 200px rgb(123 172 103 / 47%) inset !important;
transition: 0.3s ease;
}

.accordion-button[aria-expanded="true"] {
border: 1px solid var(--warna_4);
box-shadow: 0 0 200px rgb(123 172 103 / 47%) inset;
border-bottom-left-radius: 0px;
border-bottom-right-radius: 0px;
}

.method-accordion .accordion-button {
padding: 0px 0px;
}

.radio-nominal+label .row .col-1 .rounded-radio svg circle {
fill: #0000;
transition: 0.3s ease;
}

.radio-nominal:checked+label .row .col-1 .rounded-radio svg circle {
fill: var(--warna_4);
}

@media (max-width:480px) {
.harga-price-method {
    font-weight: 600;
    font-size: 11px;
}

.text-method {
    font-size: 8px;
}
}

@media (min-width:481px) {
button.accordion-button {
    /* padding: 7px 20px; */
}

.harga-price-method {
    font-weight: 600;
    font-size: 14px;
}
}
button.accordion-button {
outline: none !important;
border: 1px solid #0000;
background-color: var(--warna_6);
border-radius: 6px;
padding: 7px 20px;
font-weight: 600;
}
</style>
<?php $this->endSection(); ?>

<?php $this->section('content'); ?>
<div class="content" style="min-height: 580px;">
    <div class="container">
        <div class="row d-flex justify-content-center">

            <?= $this->include('header-user'); ?>
            <div class="col-sm-6">
                <a class="box-back" onclick="goBack()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path d="M11.4375 18.75L4.6875 12L11.4375 5.25M5.625 12H19.3125" stroke="white"
                            stroke-opacity="0.6" stroke-width="2.15625" stroke-linecap="round"
                            stroke-linejoin="round" />
                    </svg>
                </a>
                <?= alert(); ?>
                <div class="pb-3">
                    <div class="section">
                        <div class="body-games shadow-form">
                            <div class="position-absolute mt-1" style="right: 35px;">
                                <a href="<?= base_url(); ?>/user/topup/riwayat?status=Pending">
                                    <h6 class=" text-secondary-pointgo"><i class="fa fa-history mr-2"></i> Riwayat
                                    </h6>
                                </a>
                            </div>
                            <h5 class="text-center pb-4">Top-up</h5>

                            <form action="" method="POST" onsubmit="handleFormSubmit(event);">
                                <div class="form-group">
                                    <label class="text-dark">Nominal Topup</label>
                                    <input type="number" step="10000" class="form-control" autocomplete="off" name="nominal"
                                        placeholder="Masukkan Nominal" >
                                        <small class="text-warning">* Nominal harus merupakan kelipatan 10.000</small>
                                </div>
                                
                                    <?php
                                    $count = 0;
                                    foreach ($accordion_data as $category => $methods):
                                        $count++;
                                        ?>
                                    <?php if ($category === 'QRIS'): ?>
                                    <?php foreach ($methods as $method): ?>
                                    <div class="mt-3 mb-3" id="bbank">
                                        <div class="accordion-button single-payment">
                                            <input class="radio-nominal" type="radio" name="method"
                                                value="<?= $method['id']; ?>" id="method-<?= $method['id']; ?>">
                                            <label for="method-<?= $method['id']; ?>"
                                                id="method-<?= $method['id']; ?>-label" class="mb-0">
                                                <div class="row">
                                                    <div class="col-3 pl-0 d-flex align-items-center">
                                                        <div class="mr-2 pb-0">
                                                            <img src="<?= base_url(); ?>/assets/images/new-assets/qris-white.svg"
                                                                class="mr-3 ml-3" style="filter: invert(1);"></img>
                                                        </div>
                                                    </div>
                                                    <div class="col-4 d-flex align-items-center">
                                                        <div> <?= $category; ?></div>
                                                    </div>
                                                    <div class="col-5 p-0">
                                                        <div class="mt-2 text-right">
                                                            <p class="mb-2 harga-price-method"
                                                                id="price-method-<?= $method['id']; ?>"></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                    <?php else:?>
                                    <div class="accordion-item mb-3 boks">
                                        <h2 class="accordion-header mb-0" id="heading-bank">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#collapse<?= $count; ?>"
                                                aria-expanded="false" aria-controls="collapse<?= $count; ?>"
                                                aria-labelledby="<?= $count; ?>" data-bs-parent="#bbank">
                                                <div class="left">
                                                    <?php if ($category == 'Bank Transfer'): ?>
                                                    <img src="<?= base_url(); ?>/assets/images/new-assets/mdi_bank.svg"
	                                                        lass="mr-3"style="filter: invert(1);"></img>&nbsp<?= $category; ?>
                                                    <?php elseif ($category == 'Virtual Account'): ?>
                                                    <img src="<?= base_url(); ?>/assets/images/new-assets/vabank-white.svg"
	                                                        lass="mr-3"style="filter: invert(1);"></img>&nbsp<?= $category; ?>
                                                    <?php elseif ($category == 'E-Wallet'): ?>
                                                    <img src="<?= base_url(); ?>/assets/images/new-assets/e-wallet.svg"
	                                                        lass="mr-3"style="filter: invert(1);"></img>&nbsp<?= $category; ?>
                                                    <?php elseif ($category == 'Convenience Store'): ?>
                                                    <img src="<?= base_url(); ?>/assets/images/new-assets/store.svg"
	                                                        lass="mr-3"style="filter: invert(1);"></img>&nbsp<?= $category; ?>
                                                    <?php elseif ($category == 'Pulsa'): ?>
                                                    <img src="<?= base_url(); ?>/assets/images/new-assets/cell-phone.png"class="mr-3" width="23" style=" filter: invert(1);">
                                                     </img>&nbsp<?= $category; ?>
                                                    <?php endif ?>
                                                </div>
                                                <iconify-icon class="pl-1" inline icon="subway:down-2"
                                                    style="margin-left: auto;"></iconify-icon>
                                            </button>
                                        </h2>
                                        <div id="collapse<?= $count; ?>" class="accordion-collapse collapse"
                                            aria-labelledby="heading<?= $count; ?>" data-bs-parent="#bbank">
                                            <div class="accordion-body">

                                                <?php foreach ($methods as $method): ?>
                                                <div class="method-accordion mb-0" id="bbank">
                                                    <button class="accordion-button">
                                                        <input class="radio-nominal" type="radio" name="method"
                                                            value="<?= $method['id']; ?>"
                                                            id="method-<?= $method['id']; ?>">
                                                        <label for="method-<?= $method['id']; ?>"
                                                            id="method-<?= $method['id']; ?>-label" class="mb-0">
                                                            <div class="row" style="pointer-events: none;">
                                                                <div class="col-1 d-flex align-items-center pr-4">
                                                                    <div class="rounded-radio mr-2 pb-0">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            width="12" height="12"
                                                                            viewBox="0 0 12 12" fill="none">
                                                                            <circle cx="6" cy="6" r="5.77941"
                                                                                stroke="white"
                                                                                stroke-width="0.441176" />
                                                                        </svg>
                                                                    </div>
                                                                </div>
                                                                <div class="col-3 pl-0 d-flex align-items-center">
                                                                    <div class="mr-2 pb-0">
                                                                        <img src="<?= base_url(); ?>/assets/images/method/<?= $method['image']; ?>"
                                                                            class="mr-3" width=" 60px"></img>
                                                                    </div>
                                                                </div>

                                                                <div class="col-3 d-flex align-items-center">
                                                                    <div class="text-method">
                                                                        <?= $method['method']; ?>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-4 p-0 d-flex align-items-center justify-content-end">
                                                                    <div class="mr-2 mt-2">
                                                                        <p class="mb-2 harga-price-method"
                                                                            id="price-method-<?= $method['id']; ?>">
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </label>
                                                    </button>
                                                </div>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php endforeach; ?>
                                
                                <div class="d-block pt-4">
                                    <button class="btn btn-primary btn-block" type="submit" name="tombol"
                                        value="submit">Topup
                                        Sekarang</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $this->endSection(); ?>

<?php $this->section('js'); ?>

<script>
function adjustToNearestMultiple(input) {
    var value = parseInt(input.value);

    var nearestMultiple = Math.round(value / 10000) * 10000;

    input.value = nearestMultiple;
}
</script>

<script>
function handleFormSubmit(event) {
var targetButton = event.submitter;

if (targetButton.value === 'submit') {
    return;
} else {
    event.preventDefault();
}
}
</script>
<?php $this->endSection(); ?>