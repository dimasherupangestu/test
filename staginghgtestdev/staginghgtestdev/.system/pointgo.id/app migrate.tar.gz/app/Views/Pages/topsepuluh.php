<?php $this->extend('template'); ?>

<?php $this->section('css'); ?>
<style>
    body {
        font-family: 'Proxima Nova Rg';
        font-weight: normal;
    }
    
    .table {
        margin-bottom: 0px;
        border-radius: 10px;
        color: black;
    }
    .bootstrap-table .fixed-table-container {
        background: var(--warna_6);
    }
    .table-responsive {
        border-radius: 10px;
    }
    .table-dark td, .table-dark th, .table-dark thead th {
        border-color: rgb(244 245 250 / 0%);
    }
    .table-dark.table-striped tbody tr:nth-of-type(odd) {
        background-color: rgb(43 46 47);;
    }
    .table-dark.table-striped tbody tr:nth-of-type(even) {
        background-color: rgb(41 44 45);
    }
    .bootstrap-table .auto-refresh, .fixed-table-toolbar, button[name="refresh"] {
        display: none;
    }
    .bootstrap-table .fixed-table-container .table td, .bootstrap-table .fixed-table-container .table th {
        border-color: rgb(244 245 250 / 0%);
    }
    .table-hover tbody tr:hover {
    color: black;
    background-color: rgba(0,0,0,.075);
    }
     
    [data-index="0"] {
        font-weight: 500;
    }
     [data-index="0"]:hover {
             font-weight: 500;
    }
    [data-index="1"] {
    font-weight: 500;
    }
     [data-index="1"]:hover {
    font-weight: 500;
    }
    [data-index="2"] {
        font-weight: 500;
    }
     [data-index="2"]:hover {
    font-weight: 500;
    }
    .fixed-table-header {
        background: var(--warna_4) !important;
    }
    .fixed-table-container.fixed-height {
        border: none !important;
    }
    thead tr {
        border: none !important;
    }
    thead th {
        border-top: none !important;
        border-bottom: none !important;
        background-color: var(--warna_3);
        color: black;
    }
    
    .top-3{
        margin-top: 1rem;
    }
    
    @media (max-width: 760px) {
        .text-hp {
            font-size: 14px !important;
        }
        .text-hp-h3 {
            font-size: 16px !important;
        }
        .hp-image {
            width: 30px ;
            height: 30px ;
        }
        .top-3{
            margin: 0px !important;
        }
    }
</style>
<?php $this->endSection(); ?>

<?php $this->section('content'); ?>
<div class="pt-4 pb-5" style="min-height: 500px;">
    <div class="container">
        <div class="d-flex justify-content-center align-items-center mb-1 mt-4">
            <div class="background-flex row align-items-center pr-3 pl-3" style="background:var(--warna_3);border-radius:10px;padding:10px;gap:0.25rem;">
                <img class="hp-image" src="<?= base_url(); ?>/assets/images/new-assets/crown2.png" height="62" width="62" style="z-index:100;">
                <h3 class="text-center text-hp-h3 font-proximanovabl top-3" style="color: var(--warna_4);font-size:24px ;">LEADERBOARD PARA SULTAN</h3>
                <img class="hp-image" src="<?= base_url(); ?>/assets/images/new-assets/crown2.png" height="62" width="62" style="z-index:100;">
            </div>
        </div>
        <p class="mb-5 text-center text-hp" style="font-size: 18px;font-weight: 500;color: var(--warna_4); !important">Berikut adalah nama para Sultan-Sultan di Hidden Game!</p>
        <div class="row justify-content-center">
            <div class="mb-3 col-md-4">
                 <div class="d-flex justify-content-start align-items-center mb-2">
                        <h4 class="mb-4 text-hp-h3 font-proximanovabl" style="color:var(--warna_4)!important;">Top 50 Daily</h4>
                        <span class="strip-primary mt-4"></span>
                    </div>
                <div class="card-bodyss">
                    <div class="table-responsive">
                        <table class="table" id="table1" data-id-field="id" data-toolbar="#toolbar" data-show-refresh="true"
                            data-auto-refresh="true" data-auto-refresh-interval="15" data-show-search-clear-button="true" 
                            data-height="520" data-show-footer="false"
                            data-url="<?= base_url(); ?>/Pages/get_top_sepuluh_daily">
                            <thead>
                                <tr style="background: var(--warna_3);">
                                    <th data-field="no">No</th>
                                    <th data-field="username" data-formatter="usernameFormatter">Nickname</th>
                                    <th data-field="total">Total Topup</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
                <p class="mt-2">Data ini akan direfresh setiap 5 menit sekali</p>
            </div>

            <div class="mb-3 col-md-4">
                <div class="d-flex justify-content-start align-items-center mb-2">
                        <h4 class="mb-4 text-hp-h3 font-proximanovabl" style="color:var(--warna_4) !important;">Top 50 Weekly</h4>
                        <span class="strip-primary mt-4"></span>
                </div>
                <div class="card-bodyss" >
                    <div class="table-responsive">
                        <table class="table" id="table2" data-id-field="id" data-toolbar="#toolbar" data-show-refresh="true"
                                data-auto-refresh="true" data-auto-refresh-interval="15" data-show-search-clear-button="true" data-height="520" data-show-footer="false"
                               data-url="<?= base_url(); ?>/Pages/get_top_sepuluh_weekly">
                            <thead>
                            <tr style="background: var(--warna_3);">
                                <th data-field="no">No</th>
                                <th data-field="username" data-formatter="usernameFormatter">Nickname</th>
                                <th data-field="total">Total Topup</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
                <p class="mt-2">Data ini akan direfresh setiap 15 menit sekali</p>
            </div>

            <div class="mb-3 col-md-4">
                <div class="d-flex justify-content-start align-items-center mb-2">
                        <h4 class="mb-4 text-hp-h3 font-proximanovabl" style="color:var(--warna_4) !important;">Top 50 Monthly</h4>
                        <span class="strip-primary mt-4"></span>
                </div>
                <div class="card-bodyss" >
                    <div class="table-responsive">
                        <table class="table" id="table3" data-id-field="id" data-toolbar="#toolbar" data-show-refresh="true"
                                data-auto-refresh="true" data-auto-refresh-interval="15" data-show-search-clear-button="true" data-height="520" data-show-footer="false"
                               data-url="<?= base_url(); ?>/Pages/get_top_sepuluh_monthly">
                            <thead>
                            <tr style="background: var(--warna_3);">
                                <th data-field="no">No</th>
                                <th data-field="username" data-formatter="usernameFormatter">Nickname</th>
                                <th data-field="total">Total Topup</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
                <p class="mt-2">Data ini akan direfresh setiap 1 jam sekali</p>
            </div>

        </div>
    </div>
</div>

<?php $this->endSection(); ?>

<?php $this->section('js'); ?>

<link href="https://unpkg.com/bootstrap-table@1.22.0/dist/bootstrap-table.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.0/font/bootstrap-icons.css">

<script src="https://unpkg.com/bootstrap-table@1.22.0/dist/bootstrap-table.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.22.0/dist/extensions/auto-refresh/bootstrap-table-auto-refresh.min.js">
</script>
<script
    src="https://unpkg.com/bootstrap-table@1.22.0/dist/extensions/filter-control/bootstrap-table-filter-control.min.js">
</script>
<script src="https://cdn.jsdelivr.net/npm/tableexport.jquery.plugin@1.10.21/tableExport.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.22.0/dist/extensions/export/bootstrap-table-export.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
   
<script>
    // Simpan posisi scroll sebelum tabel diperbarui
    var scrollPosition = 0;

    $(document).ready(function() {
        // Event listener untuk mengambil posisi scroll saat tabel di-scroll
        $('.table-responsive').on('scroll', function() {
            // Simpan posisi scroll saat tabel di-scroll
            scrollPosition = $(this).scrollTop();
        });

        // Panggil fungsi untuk menjaga posisi scroll setelah tabel diperbarui
        keepScrollPosition();
    });

    // Fungsi untuk menjaga posisi scroll setelah tabel diperbarui
    function keepScrollPosition() {
        // Atur kembali posisi scroll ke nilai yang disimpan setelah tabel diperbarui
        $('.table-responsive').scrollTop(scrollPosition);
    }
</script>

   
<script>
$(function() {
    $('#table').bootstrapTable()
        .on('refresh.bs.table', function() {
            console.timeEnd()
            console.time()
        })
})
</script>
<script>
  var $table = $('#table1')
   var $table = $('#table2')
    var $table = $('#table3')

  $(function() {
    $('#toolbar').find('select').change(function () {
      $table.bootstrapTable('destroy').bootstrapTable({
        exportDataType: $(this).val(),
        exportTypes: ['csv', 'excel'],
        columns: [
          {
            field: 'no',
            title: 'No'
          }
        ]
      })
    }).trigger('change')
  })
</script>

<script>
    function usernameFormatter(value, row, index) {

        if (index == 0) {
            return '<span><iconify-icon icon="fluent:crown-20-filled" style="vertical-align: sub;font-size: 17px;color: #ffcc00;"></iconify-icon> ' + value + '</span>';
        } else if (index == 1) {
            return '<span><iconify-icon icon="fluent:crown-20-filled" style="vertical-align: sub;font-size: 17px;"></iconify-icon> ' + value + '</span>';
        } else if (index == 2) {
            return '<span><iconify-icon icon="fluent:crown-20-filled" style="vertical-align: sub;font-size: 17px;color: #ae5533;"></iconify-icon> ' + value + '</span>';
        } else {
            return value;
        }
    }

    $(function () {
        $('#table1').bootstrapTable({
            // Konfigurasi atau opsi lainnya disini
        });
    });
    
    $(function () {
        $('#table2').bootstrapTable({
            // Konfigurasi atau opsi lainnya disini
        });
    });
    
    $(function () {
        $('#table3').bootstrapTable({
            // Konfigurasi atau opsi lainnya disini
        });
    });
</script>

<?php $this->endSection(); ?>