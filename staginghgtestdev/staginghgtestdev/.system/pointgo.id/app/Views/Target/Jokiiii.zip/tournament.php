<div class="form-row pt-3">
    <div class="col-lg-6">
        <input type="text" name="tournament[id]" class="form-control mb-2 name-tournament" placeholder="Masukkan ID" autocomplete="off">
    </div>
    <div class="col-lg-6">
        <input type="text" name="tournament[server]" class="form-control mb-2 name-tournament" placeholder="Masukkan Server" autocomplete="off">
    </div>
    <div class="col-lg-6">
        <input type="text" name="tournament[jam]" class="form-control mb-2 name-tournament" placeholder="Masukkan Jam (HH:MM)" autocomplete="off">
    </div>
    <div class="col-lg-6">
        <input type="text" name="tournament[tanggal]" class="form-control mb-2 name-tournament" placeholder="Masukkan Tanggal (HH-BB-TTTT)" autocomplete="off">
    </div>

    <!-- <p class="col-12 mt-2" style="font-size: 10px">Untuk mengetahui User ID Anda, silahkan klik menu profile dibagian kiri atas pada menu utama game. User ID akan terlihat dibagian bawah Nama karakter game Anda. Silahkan masukan User ID dan Server ID Anda untuk menyelesaikan transaksi. <b>Contoh: 12345678(1234)</b>. </p> -->
</div>