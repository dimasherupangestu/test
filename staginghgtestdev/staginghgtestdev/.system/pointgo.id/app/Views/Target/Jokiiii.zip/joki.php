<div class="form-row pt-3">
    <div class="col-lg-6">
        <input type="text" name="joki[request_hero]" class="form-control mb-2 name-joki" placeholder="Request Hero" autocomplete="off">
    </div>
    <div class="col-lg-6">
        <input type="email" name="joki[email]" class="form-control mb-2 name-joki" placeholder="Email/No HP" autocomplete="off">
    </div>
    <div class="col-lg-6">
        <input type="text" name="joki[password]" class="form-control mb-2 name-joki" placeholder="Masukkan Password" autocomplete="off">
    </div>
    <div class="col-lg-6">
        <input type="text" name="joki[catatan_joki]" class="form-control mb-2 name-joki" placeholder="Catatan/Keterangan" autocomplete="off">
    </div>
    <div class="col-lg-6">
        <input type="text" name="joki[nickname]" class="form-control mb-2 name-joki" placeholder="Nickname" autocomplete="off">
    </div>
    <div class="col-lg-6">
    	<select name="joki[login_via]" class="form-control name-joki">
    		<option value="Moonton">Moonton</option>
    		<option value="VK">VK</option>
    		<option value="TikTok">TikTok</option>
    		<option value="Facebook">Facebook</option>
    	</select>
    </div>
    <!-- <p class="col-12 mt-2" style="font-size: 10px">Untuk mengetahui User ID Anda, silahkan klik menu profile dibagian kiri atas pada menu utama game. User ID akan terlihat dibagian bawah Nama karakter game Anda. Silahkan masukan User ID dan Server ID Anda untuk menyelesaikan transaksi. <b>Contoh: 12345678(1234)</b>. </p> -->
</div>