<div class="form-row pt-3">
    <div class="col-lg-6 mb-1">
        <input type="text" name="jokigendong[id]" class="form-control mb-2 name-jokigendong" placeholder="Masukkan ID" autocomplete="off">
    </div>
    <div class="col-lg-6 mb-1">
        <input type="text" name="jokigendong[nickname]" class="form-control mb-2 name-jokigendong" placeholder="Masukkan Nickname" autocomplete="off">
    </div>
    <div class="col-lg-6 mb-1">
        <select name="jokigendong[role]" class="form-control name-jokigendong">
            <option value="Pilih Role">Pilih Role</option>
            <option value="Tank">Tank</option>
            <option value="Fighter">Fighter</option>
            <option value="Assassin">Assassin</option>
            <option value="Mage">Mage</option>
            <option value="Marksman">Marksman</option>
            <option value="Support">Support</option>
        </select>
    </div>
    <div class="col-lg-6 mb-1">
        <input type="text" name="jokigendong[tanggal]" class="form-control mb-2 name-jokigendong" placeholder="Masukkan Tanggal (HH-BB-TTTT)" autocomplete="off">
    </div>
    <div class="col-lg-6 mb-1">
        <input type="text" name="jokigendong[jam]" class="form-control mb-2 name-jokigendong" placeholder="Masukkan Jam (HH:MM)" autocomplete="off">
    </div>
    <div class="col-lg-6 mb-1">
        <input type="text" name="jokigendong[catatan]" class="form-control mb-2 name-jokigendong" placeholder="Catatan untuk Penjoki" autocomplete="off">
    </div>


    <!-- <p class="col-12 mt-2" style="font-size: 10px">Untuk mengetahui User ID Anda, silahkan klik menu profile dibagian kiri atas pada menu utama game. User ID akan terlihat dibagian bawah Nama karakter game Anda. Silahkan masukan User ID dan Server ID Anda untuk menyelesaikan transaksi. <b>Contoh: 12345678(1234)</b>. </p> -->
</div>