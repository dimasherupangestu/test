<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Username Gmail / FB / Apple / Floor Email" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
          <select placeholder="Pilih Server" name="additional_id" class="DynamicForm__Select-sc-wj46ik-2 hmEMvb"><option value="">Pilih Server</option><option value="Asia">Asia</option><option value="Europe">Europe</option><option value="America">America</option></select>    
                                </select>


    
    </div>
</div>        