<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Username Email / Gmail / FB" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
          <option value="">Pilih Server</option><option value="ASIA2 1-1">ASIA2 1-1</option><option value="ASIA2 1-2">ASIA2 1-2</option><option value="ASIA2 1-3">ASIA2 1-3</option><option value="ASIA2 1-4">ASIA2 1-4</option><option value="ASIA2 1-5">ASIA2 1-5</option><option value="ASIA2 1-6">ASIA2 1-6</option><option value="ASIA2 1-7">ASIA2 1-7</option><option value="ASIA2 1-8">ASIA2 1-8</option><option value="ASIA2 1-9">ASIA2 1-9</option><option value="ASIA2 1-10">ASIA2 1-10</option></select>
                                    </select>
    
    </div>
</div>        