<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Masukkan Account ID" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
          <option value="">Pilih Server</option><option value="MiskaTown">MiskaTown</option><option value="SandCastle">SandCastle</option><option value="MouthSwamp">MouthSwamp</option><option value="RedwoodTown">RedwoodTown</option><option value="Obelisk">Obelisk</option><option value="FallForest">FallForest</option><option value="MountSnow">MountSnow</option><option value="NancyCity">NancyCity</option><option value="CharlesTown">CharlesTown</option><option value="SnowHighlands">SnowHighlands</option><option value="Santopany">Santopany</option><option value="LevinCity">LevinCity</option><option value="NewLand">NewLand</option><option value="MileStone">MileStone</option><option value="ChaosOutpost">ChaosOutpost</option><option value="ChaosCity">ChaosCity</option><option value="TwinIslands">TwinIslands</option><option value="HopeWall">HopeWall</option><option value="IronStride">IronStride</option><option value="LabyrinthSea">LabyrinthSea</option><option value="CrystalthornSea">CrystalthornSea</option></select>
                                    </select>
    </div>
</div>        