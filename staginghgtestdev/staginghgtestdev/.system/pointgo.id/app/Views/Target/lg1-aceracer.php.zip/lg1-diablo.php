<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Username Gmail / FB / Battlenet" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
          <option value="">Pilih Server</option><option value="Zann Esu">Zann Esu</option><option value="Peth">Peth</option><option value="Gillian">Gillian</option><option value="Bloodrime">Bloodrime</option><option value="Blood Raven">Blood Raven</option><option value="Enigma">Enigma</option><option value="Ghirn">Ghirn</option><option value="Anu">Anu</option><option value="Verathiel">Verathiel</option><option value="YL Nira">YL Nira</option><option value="Vasily">Vasily</option><option value="Nilfur">Nilfur</option><option value="Agronix">Agronix</option><option value="Breath of the Dying">Breath of the Dying</option></select>
                                    </select>
    
    </div>
</div>        