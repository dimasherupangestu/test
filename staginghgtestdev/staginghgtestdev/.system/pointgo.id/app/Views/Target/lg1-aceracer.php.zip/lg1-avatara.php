<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Username Gmail / FB" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
            <option value="">Pilih Server</option><option value="ASIA-1">ASIA-1</option><option value="ASIA-2">ASIA-2</option><option value="ASIA-3">ASIA-3</option><option value="ASIA-4">ASIA-4</option><option value="ASIA-5">ASIA-5</option><option value="ASIA-6">ASIA-6</option><option value="ASIA-7">ASIA-7</option><option value="WEST-1">WEST-2</option></select>
                                    </select>
    
    </div>
</div>        