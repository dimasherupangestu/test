<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Masukkan User ID" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
                 <option value="">Server</option><option value="asia">亞洲分站/ASIA/아시아/サブ会場-アジア</option><option value="korea">韓國分站/KOREA/한국/サブ会場-韓国</option><option value="japan">日本分站/JAPAN/일본-구역/サブ会場-日本</option><option value="northamerica">北美分站/NORTH-AMERICA/북미/サブ会場-北米</option><option value="europe">歐洲分站/EUROPE/유럽/サブ会場-ヨーロッパ</option></select>
                                    </select>
    
    </div>
</div>        