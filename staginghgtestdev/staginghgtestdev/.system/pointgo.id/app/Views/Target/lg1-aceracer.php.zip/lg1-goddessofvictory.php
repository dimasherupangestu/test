<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Masukkan Player ID" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
          <option value="">Pilih Server</option><option value="SEA">SEA</option><option value="Global">Global</option><option value="NA">NA</option><option value="JP">JP</option><option value="KR">KR</option></select>
                                    </select>
    </div>
</div>        