<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Masukkan User ID" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
          <option value="">Pilih Server</option><option value="DeathQuay">DeathQuay</option><option value="CrosRiver">CrosRiver</option><option value="Buckland">Buckland</option><option value="BurntPlan">BurntPlan</option><option value="JadeCoast">JadeCoast</option><option value="PadHill">PadHill</option><option value="RoniLand">RoniLand</option><option value="BeautyLake">BeautyLake</option><option value="BlizzardBay">BlizzardBay</option><option value="LushField">LushField</option><option value="DustyPlan">DustyPlan</option><option value="IceRiver">IceRiver</option><option value="GreenGully">GreenGully</option><option value="AzureField">AzureField</option><option value="EosBeach">EosBeach</option><option value="TwilightBay">TwilightBay</option><option value="Gray Plain">Gray Plain</option><option value="SandSnow">SandSnow</option><option value="Craglslet">Craglslet</option><option value="SkyotHill">SkyotHill</option><option value="GreenHill">GreenHill</option></select>
                                    </select>
    </div>
</div>        