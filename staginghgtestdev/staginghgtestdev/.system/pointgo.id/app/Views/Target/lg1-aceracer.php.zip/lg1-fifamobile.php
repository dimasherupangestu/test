<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Username Gmail / FB" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
          <option value="">Pilih Login</option><option value="Google">Google</option><option value="Facebook">Facebook</option></select>
                                    </select>
    
    </div>
</div>        