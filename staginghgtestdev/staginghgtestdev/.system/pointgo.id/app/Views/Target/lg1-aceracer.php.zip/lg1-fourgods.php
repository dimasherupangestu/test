<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Username Gmail / FB" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
             <option value="">Pilih Server</option><option value="ASIA01">ASIA01</option><option value="ASIA02">ASIA02</option><option value="ASIA03">ASIA03</option><option value="ASIA04">ASIA04</option><option value="ASIA05">ASIA05</option></select>                                    
               </select>
    </div>
</div>        