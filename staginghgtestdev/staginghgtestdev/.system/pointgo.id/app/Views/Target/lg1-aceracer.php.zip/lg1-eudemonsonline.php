<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Masukkan Account Name" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
            <option value="">Server</option><option value="America - NewYork/Toronto">America - NewYork/Toronto</option><option value="America - LA/LasVegas">America - LA/LasVegas</option><option value="America - Aries">America - Aries</option><option value="America - Cronus">America - Cronus</option><option value="America - Chaosacre">America - Chaosacre</option><option value="America - SkyPark">America - SkyPark</option><option value="America - Hyperion">America - Hyperion</option><option value="America - EveGarden">America - EveGarden</option><option value="America - RedAltar">America - RedAltar</option><option value="America - KingGround">America - KingGround</option><option value="America - ReturnHero">America - ReturnHero</option><option value="Europe - London">Europe - London</option><option value="Europe - DarkMarsh">Europe - DarkMarsh</option><option value="Europe - RoseHall">Europe - RoseHall</option><option value="Europe - Lyra">Europe - Lyra</option><option value="Europe - SongPark">Europe - SongPark</option><option value="Europe - Mocci">Europe - Mocci</option><option value="Asia - Jin">Asia - Jin</option><option value="Asia - ElvenCity">Asia - ElvenCity</option><option value="Asia - Draconis">Asia - Draconis</option><option value="Asia - Dragon">Asia - Dragon</option></select>                                    
               </select>
    </div>
</div>        