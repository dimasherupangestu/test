<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Masukkan User ID" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
          <option value="">Masukkan Server</option><option value="America">America</option><option value="Asia">Asia</option><option value="Europe">Europe</option><option value="TW_HK_MO">TW_HK_MO</option></select>
                                    </select>
    </div>
</div>        