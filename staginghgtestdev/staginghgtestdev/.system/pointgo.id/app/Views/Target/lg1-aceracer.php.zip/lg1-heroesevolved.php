<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Masukkan Player ID" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
        <option value="">Server</option><option value="North America - LOST TEMPLE [NA]">North America - LOST TEMPLE [NA]</option><option value="North America - NEW ORDER [NA]">North America - NEW ORDER [NA]</option><option value="Europe - ASGARD[EU]">Europe - ASGARD[EU]</option><option value="Europe - OLYMPUS[EU]">Europe - OLYMPUS[EU]</option><option value="South America - AMAZON [SA]">South America - AMAZON [SA]</option><option value="South America - EL DORADO [SA]">South America - EL DORADO [SA]</option><option value="ASIA - S1.ANGKOR [AS]">ASIA - S1.ANGKOR [AS]</option><option value="ASIA - S2.EL NIDO [AS]">ASIA - S2.EL NIDO [AS]</option><option value="ASIA - ไทย[TH]">ASIA - ไทย[TH]</option><option value="ASIA - SHANGRI-LA [AS]">ASIA - SHANGRI-LA [AS]</option><option value="ASIA - ไทยแลนด์[TH]">ASIA - ไทยแลนด์[TH]</option></select>    
             </select>
        </div>
</div>        