<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Username Supercell ID" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
           <option value="">Pilih Login</option><option value="Supercell ID">Supercell ID</option></select>
                                    </select>
    
    </div>
</div>        