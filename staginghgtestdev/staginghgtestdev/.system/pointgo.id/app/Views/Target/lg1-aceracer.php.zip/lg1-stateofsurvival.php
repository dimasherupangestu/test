<div class="form-row pt-3">
    <div class="col">
        <input type="text" name="user_id" class="form-control" placeholder="Username Gmail / FB / Funplus" autocomplete="off">
    </div>
    <div class="col">
        <select placeholder="Pilih Server" name="zone_id" class="form-control">
          <select placeholder="Pilih Login" name="additional_information" class="DynamicForm__Select-sc-wj46ik-2 hmEMvb"><option value="">Pilih Login</option><option value="Google">Google</option><option value="Facebook">Facebook</option><option value="Funplus">Funplus</option></select>
                                    </select>
    
    </div>
</div>        