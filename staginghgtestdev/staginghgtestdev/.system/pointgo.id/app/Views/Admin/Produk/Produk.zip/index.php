<?php $this->extend('template'); ?>
				
				<?php $this->section('css'); ?>
				<?php $this->endSection(); ?>
				
				<?php $this->section('content'); ?>
				<div class="content">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								
								<?= $this->include('header-admin'); ?>

								<div class="card">
									<div class="card-body">
										<h5 class="mb-0">Produk</h5>
										<div class="card-tools">
											<a href="<?= base_url(); ?>/admin/produk/get" class="btn btn-primary btn-sm"  hidden>Get Produk Digiflazz</a>
											<a href="<?= base_url(); ?>/admin/produk/add" class="btn btn-primary btn-sm">Tambah Produk</a>
											<a href="<?= base_url(); ?>/admin/produk/rawprice" class="btn btn-primary btn-sm" >Update Harga Modal</a>
										</div>
									</div>
									<div class="table-responsive" style="font-size: 11px;">
										<table class="table-white table table-striped">
											<tr>
												<<th width="10">No</th>
												<th>Games</th>
												<th>Produk</th>
												<th>Provider</th>
												<th>Harga Jual</th>
												<th>Harga Modal</th>
												<th>Profit</th>
												<th>Status</th>
												<th>Action</th>
											</tr>
											<?php $no = 1; foreach ($product as $loop): ?>
											<tr>
												<td><?= $no++; ?></td>
												<td><?= $loop['games']; ?></td>
												<td><?= $loop['product']; ?></td>
												<td>
												 <?php
													if ($loop['provider'] == 'BJ') {
														echo "BangJeff";
													} else if ($loop['provider'] == 'OC') {
														echo "Oke Connect";														
													} else if ($loop['provider'] == 'DF') {
														echo "Digiflazz";
													} else if ($loop['provider'] == 'AG') {
														echo "Apigames";
													} else if ($loop['provider'] == 'WG') {
														echo "Warunk Gamers";
													} else if ($loop['provider'] == 'VR') {
														echo "Games VIP Reseller";
													} else if ($loop['provider'] == 'SVR') {
														echo "Sosmed VIP Reseller";
													} else if ($loop['provider'] == 'PVR') {
														echo "Prepaid VIP Reseller";
													} else {
														echo "Manual";
													}
													?>
												</td>
												<td>Rp <?= number_format($loop['price'],0,',','.'); ?></td>
												<td>Rp <?= number_format($loop['raw_price'],0,',','.'); ?></td>
												<td>Rp <?= number_format(($loop['price'] - $loop['raw_price']),0,',','.'); ?></td>
												<td><?= $loop['status']; ?></td>
												<td width="10">
												<a href="<?= base_url(); ?>/admin/produk/edit/<?= $loop['id']; ?>" class="btn btn-primary btn-sm">Edit</a>
													<a href="<?= base_url(); ?>/admin/metode/price/<?= $loop['id']; ?>" class="btn btn-success btn-sm">Member</a>
													<button type="button" onclick="hapus('<?= base_url(); ?>/admin/produk/delete/<?= $loop['id']; ?>');" class="btn btn-danger btn-sm">Hapus</button>
												</td>
											</tr>
											<?php endforeach ?>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php $this->endSection(); ?>
				
				<?php $this->section('js'); ?>
				<?php $this->endSection(); ?>