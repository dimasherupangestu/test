				<?php $this->extend('templateadmin'); ?>
				
				<?php $this->section('css'); ?>
						<style>
					#datatable_wrapper {
						padding: 0;
					}
				
					#datatable_wrapper .row:nth-child(1),
					#datatable_wrapper .row:nth-child(3) {
						padding: 20px 15px;
					}
					body {
						font-size:11px !important;
					}
					label {
						color:#fff;
					}
					.table thead th {
					font-size: .52rem;}
					
					.form-select {
					padding: 5px;
					margin: 5px;
					overflow: hidden;
					font-size: 11px;
					}
					.filter-control .form-select {
						width:90% !important;
					}
					
				
				</style>
				<?php $this->endSection(); ?>
				
				<?php $this->section('content'); ?>
				<div class="content" style="min-height: 580px;">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								
								<?= $this->include('header-admin'); ?>

								<div class="card">
									<div class="card-body">
										<h5 class="mb-3">Pengguna</h5>
										<a href="<?= base_url(); ?>/admin/pengguna/add" class="btn btn-primary">Tambah Akun</a>
										<?= alert(); ?>
									</div>
									
								<div class="table-responsive table-white ">
							<table id="table" data-page-size="50" data-toggle="table" data-search-highlight="true" data-search="true"  data-filter-control="true"  data-pagination="true" class="table table-white table-striped" >                
				
										<thead>
											<tr>
												<th width="10">No</th>
												<th data-sortable="true">Username</th>
												<th data-filter-control="select" data-field="level" data-sortable="true">Level</th>
												<th>Whatsapp</th>
												<th data-sortable="true">Saldo</th>
												<th data-sortable="true">Status</th>
												<th>Action</th>
												
											</tr>
										</thead>
										<tbody>
											<?php $no = 1;
											foreach ($account as $loop): ?>
				
															<tr>
																<td><?= $no++; ?></td>
																<td><?= $loop['username']; ?></td>
																<td>
																	<?php
																	if ($loop['level'] == 'Member') {
																		echo "Member";
																	} else if ($loop['level'] == 'Silver') {
																		echo "Reseller";
																	} else if ($loop['level'] == 'Gold') {
																		echo "Distributor";
																	} else {
																		echo "Member";
																	}
																	?>
																</td>
																<td><?= $loop['wa']; ?></td>
																<td>Rp <?= number_format($loop['balance'], 0, ',', '.'); ?></td>
																<td><?= $loop['status']; ?></td>
																<td width="10">
																	<a href="<?= base_url(); ?>/admin/pengguna/topup/<?= $loop['id']; ?>" class="btn btn-success btn-sm">Topup Manual</a>
																	<a href="<?= base_url(); ?>/admin/pengguna/edit/<?= $loop['id']; ?>" class="btn btn-primary btn-sm">Edit</a>
																	<button type="button" onclick="hapus('<?= base_url(); ?>/admin/pengguna/delete/<?= $loop['id']; ?>');" class="btn btn-danger btn-sm">Hapus</button>
																</td>
															</tr>
											<?php endforeach ?>
				
										</tbody>
									</table>
								</div>


								</div>
							</div>
						</div>
					</div>
				</div>
				<?php $this->endSection(); ?>
				
				<?php $this->section('js'); ?>
				<script>
	
					 $(function() {
					$('#table').bootstrapTable()
				  })
				
				
				
				</script>
				<?php $this->endSection(); ?>