<?php $this->extend('template'); ?>

<?php $this->section('css'); ?>
<style>


p {
    color: #fff;
}

.mb-1,
.my-1 {
    margin-bottom: 0.75rem !important;
}

.container {
    max-width: 1300px;
}

.h3,
h3 {
    font-size: 25px;
}

.accordion-item {
    border-radius: 7px;
}

button.accordion-button {
    outline: none !important;
    border: none !important;
    box-shadow: none !important;
}

.text-end {
    text-align: right !important;
}

.icon-diamondx {
    height: 2.9rem;
    float: right;
}

.accordion {
    --bs-accordion-color: #000;
    --bs-accordion-bg: #fff;
    --bs-accordion-transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, border-radius 0.15s ease;
    --bs-accordion-border-color: var(--bs-border-color);
    --bs-accordion-border-width: 1px;
    --bs-accordion-border-radius: 0.375rem;
    --bs-accordion-inner-border-radius: calc(0.375rem - 1px);
    --bs-accordion-btn-padding-x: 1.25rem;
    --bs-accordion-btn-padding-y: 1rem;
    --bs-accordion-btn-color: var(--bs-body-color);
    --bs-accordion-btn-bg: var(--bs-accordion-bg);
    --bs-accordion-btn-icon: url(data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='var%28--bs-body-color%29'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e);
    --bs-accordion-btn-icon-width: 1.25rem;
    --bs-accordion-btn-icon-transform: rotate(-180deg);
    --bs-accordion-btn-icon-transition: transform 0.2s ease-in-out;
    --bs-accordion-btn-active-icon: url(data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%230c63e4'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e);
    --bs-accordion-btn-focus-border-color: #86b7fe;
    --bs-accordion-btn-focus-box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
    --bs-accordion-body-padding-x: 1.25rem;
    --bs-accordion-body-padding-y: 1rem;
    --bs-accordion-active-color: #0c63e4;
    --bs-accordion-active-bg: #e7f1ff;
}

.accordion-button::after {
    flex-shrink: 0;
    width: var(--bs-accordion-btn-icon-width);
    height: var(--bs-accordion-btn-icon-width);
    margin-left: auto;
    content: "";
    background-image: var(--bs-accordion-btn-icon);
    background-repeat: no-repeat;
    background-size: var(--bs-accordion-btn-icon-width);
    transition: var(--bs-accordion-btn-icon-transition);
}

.accordion-body {
    padding: var(--bs-accordion-body-padding-y) var(--bs-accordion-body-padding-x);
    background: var(--warna);
}

.accordion-button {
    box-shadow: none !important;
    position: relative;
    display: flex;
    align-items: center;
    width: 100%;
    padding: var(--bs-accordion-btn-padding-y) var(--bs-accordion-btn-padding-x);
    font-size: 1rem;
    color: var(--bs-accordion-btn-color);
    text-align: left;
    background-color: var(--bs-accordion-btn-bg);
    border: 0;
    border-radius: 0;
    overflow-anchor: none;
    transition: var(--bs-accordion-transition);
}

.accordion-button.collapsed::after {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23fff'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
}

.accordion-button:not(.collapsed)::after {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23fff'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
}

.boks {
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    border-radius: 6px;
}

.shadow-form {
    box-shadow: 0 4px 80px hsl(0deg 0% 77% / 13%), 0 1.6711px 33.4221px hsl(0deg 0% 77% / 9%), 0 0.893452px 17.869px hsl(0deg 0% 77% / 8%), 0 0.500862px 10.0172px hsl(0deg 0% 77% / 7%), 0 0.266004px 5.32008px hsl(0deg 0% 77% / 5%), 0 0.11069px 2.21381px hsl(0deg 0% 77% / 4%);
}

.badge {
    display: inline-block;
    padding: 7px 10px;
    font-size: 12px;
    font-weight: 500;
    line-height: 1;
    text-align: center;
    white-space: nowrap;
    vertical-align: top;
    border-radius: 0.25rem;
    box-shadow: 0 0.125rem 0.25rem rgb(0 0 0 / 8%);
}

.items-center {
    display: flex;
    place-items: center;
}

.border-b {
    border-bottom: 1px solid white;
}

.icon-voucher {
    padding-left: 1rem;
    align-items: center;
    left: 0;
    top: 0;
    bottom: 0;
    position: absolute;
    pointer-events: none;
    z-index: 20;
    display: flex;
}

.icon-voucher2 {
    color: rgb(156 163 175);
    width: 1.5rem;
}

.pl-10 {
    padding-left: 3rem;
}

.input-group>.form-control:not(:first-child) {
    border-top-left-radius: 999px;
    border-bottom-left-radius: 999px;
}

.input-group .btn {
    box-shadow: none;
    padding: 0.3rem 1.2rem;
    border-radius: 0px 999px 999px 0px;
}

hr {
    border-top: 1px solid rgba(0, 0, 0, 0.1);
    margin: 5px;
}

.banner-games {
    width: -webkit-fill-available;
    height: 14rem;
    object-fit: cover;
}

.col-12+p {
    padding-left: 5px;
    color: #b9b9b9;
    font-size: .735rem !important;
}

.bg-blue {
    background: #bfdbfe;
    color: #1d4ed8 !important;
}



@media (min-width: 640px) {
    .sm\:py-2 {
        padding-top: 0.5rem;
        padding-bottom: 0.5rems;
    }
}

@media (min-width: 640px) {
    .sm\:gap-3 {
        gap: 0.75rem;
    }
}

@media (min-width: 640px) {
    .sm\:grid-cols-3 {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }
}

@media (min-width: 640px) {
    .sm\:grid {
        display: grid;
    }
}

@media (min-width: 1024px) {
    .lg\:gap-0 {
        gap: 0;
    }

    .lg\:flex-row {
        flex-direction: row !important;
    }
}


@media (min-width: 768px) {
    md\:gap-0 {
        gap: 0;
    }

    .md\:flex-row {
        flex-direction: row !important;
    }

    .gap-3 {
        gap: 0.75rem;
    }
}


</style>

<?php $this->endSection(); ?>

<?php $this->section('content'); ?>
<div class="pt-4 pb-5">
    <div class="content" style="min-height: 580px;">
    <div class="container">
        <div class="row">
            <?= $this->include('header-user'); ?>
            <div class="col-lg-9 col-10">

                
                <?php if ($users['level'] == 'Member'): ?>
                <div class="card-body rounded-2xl flex justify-between items-center bg-blue mb-4">
                    <div class="row" style="align-items: baseline;">
                        <div class="pl-4">
                            <i class="fa fa-info-circle" aria-hidden="true" width="30px" class="gap-4"></i>
                        </div>
                        <div class="col">
                            <p style="color: #1d4ed8 !important;">Hi <strong>
                                    <?= $users['username']; ?>
                                </strong>, Kamu
                                belum memiliki paket membership, <strong>Upgrade membership</strong> sekarang untuk
                                mendapatkan harga produk yang lebih murah!. <strong>*Membership yang sudah dibayar tidak
                                    bisa dikembalikan*</strong></p>
                        </div>
                    </div>
                </div>
                <?php endif ?>

                <div class="pb-4">
                    <div class="float-right mt-2">
                        <a href="<?= base_url(); ?>/user/membership/riwayat">
                            <h6><i class="fa fa-history mr-2"></i> Riwayat</h6>
                        </a>
                    </div>
                    <h5>Upgrade Membership</h5>
                    <span class="strip-primary"></span>
                </div>
                
                <div class="pt-3 pb-3" hidden>
				    <a href="<?= base_url(); ?>/user" class="btn btn-warning btn-block" style="font-weight: 600;width:10rem">Kembali</a>
				</div>
				
				<?= alert(); ?>

                <div class="pb-3">
                    <div class="section rounded-2xl">
                        <div class="card-body rounded-2xl">
                            <div class="col-12 pb-3 items-center border-b">
                                <img src="<?= base_url(); ?>/assets/images/step-one.svg" class="pr-2" />
                                <a id="judulgame" style="font-size:1.1rem;font-weight:600;">Upgrade Membership </a>
                            </div>
                            <div class="card-body">
                                <div class="row pt-3 mb-2  pl-3 pr-3">
                                    
                                    <?php if ($users['level'] == 'Gold'): ?>
                                          <style>
                                              #div-product-Gold {
                                                  display:none !important;
                                              }
                                          </style>
                                    <?php endif ?>
                                    <?php if ($users['level'] == 'Silver'): ?>
                                          <style>
                                              #div-product-Silver {
                                                  display:none !important;
                                              }
                                          </style>
                                    <?php endif ?>
                                    
                                    <?php foreach ($level as $loop): ?>
                                    <div class="col-sm-6 col-12" id="div-product-<?= $loop['level']; ?>" style="padding: 0px 5px 0px 5px;display: flex;">
                                        <input type="radio" for="product-<?= $loop['level']; ?>" id="product-<?= $loop['level']; ?>" class="radio-nominale"
                                            name="product" value="<?= $loop['level']; ?>" onchange="get_price(this.value);">
                                        <label class="rounded-2xl" for="product-<?= $loop['level']; ?>"
                                            style="display: flex;justify-content: space-between;  place-items: center;padding:1.5rem;">
                                            <div>
                                                <a style="display: flex;font-weight: bold;font-size: 16px;"
                                                    for="product-<?= $loop['level']; ?>"><?= $loop['alias']; ?></a>
                                                <a style="font-style: italic;;font-size: 13px;">
                                                   <?= 'Rp ' . number_format($loop['price'], 0, ',', '.'); ?>
                                                </a>
                                            </div>
                                            <img onerror="this.style.display='none'"
                                                src="<?= base_url(); ?>/assets/images/<?= $loop['image']; ?>" loading="lazy"
                                                class="icon-diamondx pr-3">
                                            </input>
                                        </label>
                                    </div>
                                   <?php endforeach ?>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="pb-3">
                    <div class="section section-game" style="border: 0px;box-shadow: none!important;background:var(--warna_2);">
                        <div class="card-body">
                            <div class="text-white text-center position-absolute circle-primary" hidden>3</div>
                            <h5 style="margin-top: 5px;">Pilih Pembayaran</h5>
                            <?php if ($users !== false): ?>
                            <?php if ($pay_balance === 'Y'): ?>
                            <div class="accordion mb-3 mt-3 boks" id="bsaldo">
                                <div class="accordion-item">
                                    <h2 class="accordion-header mb-0" id="heading-saldo">
                                        <button class="accordion-button collapsed" style="background-color: #282C30;height: 0;padding: 20px;border-radius: 7px;font-size: 14px;" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-saldo" aria-expanded="false" aria-controls="collapse-saldo">
                                            <div class="left">
                                                <i class="fa fa-address-card"></i> Saldo Akun (Member/Reseller)
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="collapse-saldo" class="accordion-collapse collapse" aria-labelledby="heading-saldo" data-bs-parent="#bbank">
                                        <div class="accordion-body">
                                            <div class="row">

                                                <div class="col-lg-4 ceklis" style="padding-right: 5px;padding-left: 5px;display:grid;">
                                                    <input class="radio-nominal" type="radio" name="method" value="balance" id="method-balance">
                                                    <label for="method-balance">
                                                        <div class="row">
                                                            <div class="col-4">
                                                                <div class="mr-2">
                                                                    <img src="<?= base_url(); ?>/assets/images/method/saldo-akun.png" class="rounded mb-1" style="height: 17px;width:auto">
                                                                </div>
                                                            </div>
                                                            <div class="col-8 ">
                                                                <div class="mx-2 mt-1 text-right">
                                                                    <b class="mb-2" style="font-weight: 600; font-size: 12x;" id="price-method-balance"></b>
                                                                </div>
                                                            </div>
                                                            <div style="font-size: 10px;" class="col-12 ">
                                                                <b class="d-block mt-1 mx-1 text-left">Saldo Akun (Member/Reseller)</b>
                                                                <b class="d-block"></b>
                                                            </div>
                                                        </div>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="p-2 text-end " style="border-radius: 0 0 6px 6px;background: #2f3234;">
                                        <img class="img-payment" src="<?= base_url(); ?>/assets/images/method/saldo-akun.png" alt="" height="20" tyle="border-radius:5px">
                                    </div>
                                </div>
                            </div>
                            <?php endif ?>
                            <?php endif ?>

                            <div class="accordion mb-3 mt-3 boks" id="bbank">
                                <?php
                                $count = 0;
                                foreach ($accordion_data as $category => $methods):
                                    $count++;
                                    ?>

                                <div class="accordion-item mb-3">
                                    <h2 class="accordion-header mb-0">
                                        <button class="accordion-button collapsed" style="background-color: #282C30;height: 0;padding: 20px;border-radius: 7px;font-size: 14px;" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $count; ?>" aria-expanded="false" aria-controls="collapse<?= $count; ?>">
                                            <div class="left">
                                                <?php if ($category == 'Bank Transfer'): ?>
                                                <i class="fa fa-university"></i>&nbsp<?= $category; ?>
                                                <?php elseif ($category == 'QRIS'): ?>
                                                <i class="fa fa-barcode"></i> &nbsp<?= $category; ?>
                                                <?php elseif ($category == 'Virtual Account'): ?>
                                                <i class="fa fa-credit-card-alt"></i>&nbsp<?= $category; ?>
                                                <?php elseif ($category == 'E-Wallet'): ?>
                                                <i class="fa fa-money"></i>&nbsp<?= $category; ?>
                                                <?php elseif ($category == 'Convenience Store'): ?>
                                                <i class="fa fa-shopping-basket"></i>&nbsp<?= $category; ?>
                                                <?php elseif ($category == 'Pulsa'): ?>
                                                <i class="fa fa-phone"></i>&nbsp<?= $category; ?>
                                                <?php endif ?>
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="collapse<?= $count; ?>" class="accordion-collapse collapse" aria-labelledby="heading<?= $count; ?>" data-bs-parent="#bbank">
                                        <div class="accordion-body">
                                            <div class="row">

                                                <?php foreach ($methods as $method): ?>
                                                <div class="col-lg-4 ceklis" style="padding-right: 5px;padding-left: 5px;display:grid;" id="metode-<?= $method['id']; ?>">
                                                    <input class="radio-nominal" type="radio" name="method" value="<?= $method['id']; ?>" id="method-<?= $method['id']; ?>">
                                                    <label for="method-<?= $method['id']; ?>">
                                                        <div class="row">
                                                            <div class="col-4">
                                                                <div class="mr-2">
                                                                    <img src="<?= base_url(); ?>/assets/images/method/<?= $method['image']; ?>" class="rounded mb-1" style="height: 17px;width:auto">
                                                                </div>
                                                            </div>
                                                            <div class="col-8 ">
                                                                <div class="mx-2 mt-1 text-right">
                                                                    <b class="mb-2" style="font-weight: 600; font-size: 10px;" id="price-method-<?= $method['provider']; ?>-<?= $method['code']; ?><?= $method['tambahan']; ?>"></b>
                                                                </div>
                                                            </div>
                                                            <div style="font-size: 10px;" class="col-12 ">
                                                                <b class="d-block mt-1 mx-1 text-left"><?= $method['method']; ?></b>
                                                                <b class="d-block"></b>
                                                            </div>
                                                        </div>
                                                    </label>
                                                </div>
                                                <?php endforeach; ?>


                                            </div>
                                        </div>
                                    </div>
                                    <div class="p-2 text-end " style="border-radius: 0 0 6px 6px;background: #2f3234;">
                                        <?php foreach ($methods as $method): ?>
                                        <img class="img-payment" src="<?= base_url(); ?>/assets/images/method/<?= $method['image']; ?>" alt="" height="13" style="background:#fff;border-radius:3px">
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="pb-3" hidden>
                    <div class="section">
                        <div class="card-body rounded-2xl">
                            <div class="col-12 pb-3 items-center border-b">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 16 16"
                                    height="24" width="24" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z">
                                    </path>
                                </svg>
                                <a id="judulgame" style="font-size:1.1rem;font-weight:600;" class="pl-2">Informasi
                                    Pembayaran </a>
                            </div>
                            <div class="card-body">
                                <div class="flex flex-col gap-2 lg:flex-row justify-between text-start lg:items-center">
                                    <h5 class="font-bold">Detail</h5>
                                </div>
                                <div class="flex flex-col gap-2 lg:flex-row justify-between text-start lg:items-center">
                                    <dt class="text-sm font-medium">Harga Membership</dt>
                                    <dd class="mt-1 text-sm font-bold sm:col-span-2 sm:mt-0">Rp 500.000</dd>
                                </div>
                                <div class="flex flex-col gap-2 lg:flex-row justify-between text-start lg:items-center">
                                    <dt class="text-sm font-medium">Sistem Pembayaran</dt>
                                    <dd class="mt-1 text-sm font-bold sm:col-span-2 sm:mt-0"
                                        style="color: var(--warna_3)">Manual</dd>
                                </div>
                                <div class="flex flex-col gap-2 lg:flex-row justify-between text-start lg:items-center">
                                    <dt class="text-sm font-medium">Total Pembayaran</dt>
                                    <dd class="mt-1 text-sm font-bold sm:col-span-2 sm:mt-0">Rp 502.500</dd>
                                </div>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="pb-3 pt-3 text-center">
                    <button type="button" class="btn btn-primary text-white" onclick="process_order();">Upgrade Membership Sekarang
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="24"
                            width="24" xmlns="http://www.w3.org/2000/svg">
                            <path fill="none" d="M0 0h24v24H0z"></path>
                            <path
                                d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z">
                            </path>
                        </svg>
                    </button>
                </div>
                <div class="modal fade" id="modal-detail">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content text-white animated bounceIn" style="background: var(--warna_2);">
                            <div class="card-header border-bottom-0">
                                <h5 class="text-white">Detail Pembelian</h5>
                            </div>
                            <div class="modal-body pt-0">

                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="modal-loading" >
                    <div class="modal-dialog modal-dialog-centered text-center" style="max-width: 100px;">
                        <img src="<?= base_url(); ?>/assets/images/loading.gif" alt="" width="150"
                            style="border-radius: 40px;">
                    </div>
                </div>

            </div>
        </div>
    </div>
    </div>
</div>

<?php $this->endSection(); ?>

<?php $this->section('js'); ?>
<script>



function parseNumber(strg) {
    var strg = strg || "";
    var decimal = '.';
    strg = strg.replace(/[^0-9$.,]/g, '');
    if (strg.indexOf(',') > strg.indexOf('.')) decimal = ',';
    if ((strg.match(new RegExp("\\" + decimal, "g")) || []).length > 1) decimal = "";
    if (decimal !== "" && (strg.length - strg.indexOf(decimal) - 1 == 3) && strg.indexOf("0" + decimal) !== 0) decimal =
        "";
    strg = strg.replace(new RegExp("[^0-9$" + decimal + "]", "g"), "");
    strg = strg.replace(',', '.');
    return parseFloat(strg);
}



function get_price(id = null) {



    $("#product_id").val(id);

    $.ajax({
        url: '<?= base_url(); ?>/user/order/get-price/' + id,
        type: 'POST',
        data: '',
        dataType: 'JSON',
        success: function(result) {
            for (let price in result) {
                $("#price-method-" + result[price].method).text('Rp ' + result[price].price);

               var harga = parseNumber(result[price].price);

                var balance = document.getElementById("price-method-balance");

                var BCATransfer = document.getElementById("price-method-Manual-BCATransfer");
                var BNITransfer = document.getElementById("price-method-Manual-BNITransfer");
                var BRITransfer = document.getElementById("price-method-Manual-BRITransfer");
                var MandiriTransfer = document.getElementById("price-method-Manual-MandiriTransfer");

                var qrisc = document.getElementById("price-method-Tripay-QRISC");
                var qris1 = document.getElementById("price-method-Tripay-QRIS");
                var ovo = document.getElementById("price-method-Tripay-OVO");
                var shopee = document.getElementById("price-method-Tripay-SHOPEEPAY");
                var vabsi = document.getElementById("price-method-Tripay-BSIVA");
                var vabni = document.getElementById("price-method-Tripay-BNIVA");
                var vapermata = document.getElementById("price-method-Tripay-PERMATAVA");
                var vamandiri = document.getElementById("price-method-Tripay-MANDIRIVA");
                var vabri = document.getElementById("price-method-Tripay-BRIVA");
                var vabca = document.getElementById("price-method-Tripay-BCAVA");
                var indomaret = document.getElementById("price-method-Tripay-INDOMARET");
                var alfamart = document.getElementById("price-method-Tripay-ALFAMART");
                var alfamidi = document.getElementById("price-method-Tripay-ALFAMIDI");


                var qrisd = document.getElementById("price-method-Duitku-SP");
                var ovod = document.getElementById("price-method-Duitku-OV");
                var danad = document.getElementById("price-method-Duitku-DA");
                var shopeed = document.getElementById("price-method-Duitku-SA");
                var linkajad = document.getElementById("price-method-Duitku-LA");
                var vaatmd = document.getElementById("price-method-Duitku-A1");
                var vabnid = document.getElementById("price-method-Duitku-I1");
                var dvabri = document.getElementById("price-method-Duitku-BR");
                var vamayd = document.getElementById("price-method-Duitku-VA");
                var vapermatad = document.getElementById("price-method-Duitku-BT");
                var vacimbd = document.getElementById("price-method-Duitku-B1");
                var vaagd = document.getElementById("price-method-Duitku-AG");
                var vabncd = document.getElementById("price-method-Duitku-NC");
                var alfamartd = document.getElementById("price-method-Duitku-FT");
                var vamandirid = document.getElementById("price-method-Duitku-M1");

                var qrislq = document.getElementById("price-method-Linkqu-QRIS");
                var ovolq = document.getElementById("price-method-Linkqu-PAYOVO");
                var danalq = document.getElementById("price-method-Linkqu-PAYDANA");
                var shopeelq = document.getElementById("price-method-Linkqu-PAYSHOPEE");
                var linkajalq = document.getElementById("price-method-Linkqu-PAYLINKAJA");
                var alfamartlq = document.getElementById("price-method-Linkqu-ALFAMART");
                var indomaretlq = document.getElementById("price-method-Linkqu-INDOMARET");
                var vapermatalq = document.getElementById("price-method-Linkqu-013");
                var vacimblq = document.getElementById("price-method-Linkqu-022");
                var vadanamonq = document.getElementById("price-method-Linkqu-011");
                var vamandirilq = document.getElementById("price-method-Linkqu-008");
                var vabrilq = document.getElementById("price-method-Linkqu-002");
                var vaneolq = document.getElementById("price-method-Linkqu-490");
                var vabsilq = document.getElementById("price-method-Linkqu-451");
                var vabnilq = document.getElementById("price-method-Linkqu-009");
                var vabcalq = document.getElementById("price-method-Linkqu-014");
                var vamaybanklq = document.getElementById("price-method-Linkqu-016");


                var qrisx = document.getElementById("price-method-Xendit-ID_DANAqris");
                var ovox = document.getElementById("price-method-Xendit-ID_OVO");
                var danax = document.getElementById("price-method-Xendit-ID_DANAewallet");
                var shopeex = document.getElementById("price-method-Xendit-ID_SHOPEEPAY");
                var linkajax = document.getElementById("price-method-Xendit-ID_LINKAJA");
                var astrapayx = document.getElementById("price-method-Xendit-ID_ASTRAPAY");
                var vabcax = document.getElementById("price-method-Xendit-BCA");
                var vabnix = document.getElementById("price-method-Xendit-BNI");
                var vamandirix = document.getElementById("price-method-Xendit-MANDIRI");
                var vabrix = document.getElementById("price-method-Xendit-BRI");
                var vapermatax = document.getElementById("price-method-Xendit-PERMATA");
                var vaBJBx = document.getElementById("price-method-Xendit-BJB");
                var vaBSIx = document.getElementById("price-method-Xendit-BSI");
                var vaSAHABAT_SAMPOERNA = document.getElementById("price-method-Xendit-SAHABAT_SAMPOERNA");
                var indomaretx = document.getElementById("price-method-Xendit-INDOMARET");
                var alfamartx = document.getElementById("price-method-Xendit-ALFAMART");
                
 var qrissl = document.getElementById("price-method-Smartlink-WALLET_QRIS");
                var ovosl = document.getElementById("price-method-Smartlink-WALLET_OVO");
                var danasl = document.getElementById("price-method-Smartlink-WALLET_DANA");
                var shopeesl = document.getElementById("price-method-Smartlink-WALLET_SHOPEEPAY");
                var linkajasl = document.getElementById("price-method-Smartlink-WALLET_LINKAJA");
                var ccvisasl = document.getElementById("price-method-Smartlink-CC_VISA");
                var alfamartsl = document.getElementById("price-method-Smartlink-OTC_ALFAMART");
                var indomaretsl = document.getElementById("price-method-Smartlink-OTC_INDOMARET");
                var vabnisl = document.getElementById("price-method-Smartlink-VA_BNI");
                var vabrisl = document.getElementById("price-method-Smartlink-VA_BRI");
                var vabncsl = document.getElementById("price-method-Smartlink-VA_BNC");
                var vacimbsl = document.getElementById("price-method-Smartlink-VA_CIMB");
                var vamandirisl = document.getElementById("price-method-Smartlink-VA_MANDIRI");
                var vapermatasl = document.getElementById("price-method-Smartlink-VA_PERMATA");

                

                 if (qrissl !== null) {
        qrissl.innerHTML = 'Rp ' + (Math.round((harga * 1.01) + 0)).toLocaleString('id-ID');
    }
    if (ovosl !== null) {
        ovosl.innerHTML = 'Rp ' + (Math.round(harga * 1.035)).toLocaleString('id-ID');
    }
    if (danasl !== null) {
        danasl.innerHTML = 'Rp ' + (Math.round(harga * 1.02)).toLocaleString('id-ID');
    }
    if (shopeesl !== null) {
        shopeesl.innerHTML = 'Rp ' + (Math.round(harga * 1.045)).toLocaleString('id-ID');
    }
    if (linkajasl !== null) {
        linkajasl.innerHTML = 'Rp ' + (Math.round(harga * 1.02)).toLocaleString('id-ID');
    }
    if (ccvisasl !== null) {
        ccvisasl.innerHTML = 'Rp ' + (Math.round(harga * 1.0275)).toLocaleString('id-ID');
    }
    if (alfamartsl !== null) {
        alfamartsl.innerHTML = 'Rp ' + (Math.round(harga) + 3500).toLocaleString('id-ID');
    }
    if (indomaretsl !== null) {
        indomaretsl.innerHTML = 'Rp ' + (Math.round(harga) + 3500).toLocaleString('id-ID');
    }
    if (vabnisl !== null) {
        vabnisl.innerHTML = 'Rp ' + (Math.round(harga)+ 3500).toLocaleString('id-ID');
    }
    if (vabrisl !== null) {
        vabrisl.innerHTML = 'Rp ' + (Math.round(harga) + 3500).toLocaleString('id-ID');
    }
    if (vabncsl !== null) {
        vabncsl.innerHTML = 'Rp ' + (Math.round(harga) + 3500).toLocaleString('id-ID');
    }
    if (vacimbsl !== null) {
        vacimbsl.innerHTML = 'Rp ' + (Math.round(harga) + 3500).toLocaleString('id-ID');
    }
    if (vamandirisl !== null) {
        vamandirisl.innerHTML = 'Rp ' + (Math.round(harga) + 3500).toLocaleString('id-ID');
    }
    if (vapermatasl !== null) {
        vapermatasl.innerHTML = 'Rp ' + (Math.round(harga) + 3500).toLocaleString('id-ID');
    }

                if (qrislq !== null) {
                    qrislq.innerHTML = 'Rp ' + (Math.round((harga * 1.007) + 0)).toLocaleString('id-ID');
                }
                if (ovolq !== null) {
                    ovolq.innerHTML = 'Rp ' + (Math.round(harga * 1.018) + 1000).toLocaleString('id-ID');
                }
                if (danalq !== null) {
                    danalq.innerHTML = 'Rp ' + (Math.round(harga * 1.018) + 1000).toLocaleString('id-ID');
                }
                if (shopeelq !== null) {
                    shopeelq.innerHTML = 'Rp ' + (Math.round(harga * 1.023) + 1000).toLocaleString('id-ID');
                }
                if (linkajalq !== null) {
                    linkajalq.innerHTML = 'Rp ' + (Math.round(harga * 1.018) + 1000).toLocaleString('id-ID');
                }
                if (alfamartlq !== null) {
                    alfamartlq.innerHTML = 'Rp ' + (Math.round(harga + 1500)).toLocaleString('id-ID');
                }
                if (indomaretlq !== null) {
                    indomaretlq.innerHTML = 'Rp ' + (Math.round(harga + 1500)).toLocaleString('id-ID');
                }
                if (vapermatalq !== null) {
                    vapermatalq.innerHTML = 'Rp ' + (Math.round(harga + 2500)).toLocaleString('id-ID');
                }
                if (vacimblq !== null) {
                    vacimblq.innerHTML = 'Rp ' + (Math.round(harga + 2500)).toLocaleString('id-ID');
                }
                if (vadanamonq !== null) {
                    vadanamonq.innerHTML = 'Rp ' + (Math.round(harga + 2500)).toLocaleString('id-ID');
                }
                if (vamandirilq !== null) {
                    vamandirilq.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vabrilq !== null) {
                    vabrilq.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vaneolq !== null) {
                    vaneolq.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vabsilq !== null) {
                    vabsilq.innerHTML = 'Rp ' + (Math.round(harga + 3000)).toLocaleString('id-ID');
                }
                if (vabnilq !== null) {
                    vabnilq.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                if (vabcalq !== null) {
                    vabcalq.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                if (vamaybanklq !== null) {
                    vamaybanklq.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }


                if (BCATransfer !== null) {
                    BCATransfer.innerHTML = 'Rp ' + (Math.round((harga * 1))).toLocaleString('id-ID');
                }
                if (BNITransfer !== null) {
                    BNITransfer.innerHTML = 'Rp ' + (Math.round((harga * 1))).toLocaleString('id-ID');
                }
                if (BRITransfer !== null) {
                    BRITransfer.innerHTML = 'Rp ' + (Math.round((harga * 1))).toLocaleString('id-ID');
                }
                if (MandiriTransfer !== null) {
                    MandiriTransfer.innerHTML = 'Rp ' + (Math.round((harga * 1))).toLocaleString('id-ID');
                }

                if (qrisc !== null) {
                    qrisc.innerHTML = 'Rp ' + (Math.round((harga * 1.007) + 800)).toLocaleString('id-ID');
                }
                if (qris1 !== null) {
                    qris1.innerHTML = 'Rp ' + (Math.round((harga * 1.007) + 750)).toLocaleString('id-ID');
                }
                if (ovo !== null) {
                    ovo.innerHTML = 'Rp ' + (Math.round(harga * 1.03)).toLocaleString('id-ID');
                }
                if (shopee !== null) {
                    shopee.innerHTML = 'Rp ' + (Math.round(harga * 1.03)).toLocaleString('id-ID');
                }
                if (vabsi !== null) {
                    vabsi.innerHTML = 'Rp ' + (Math.round(harga + 4250)).toLocaleString('id-ID');
                }
                if (vabni !== null) {
                    vabni.innerHTML = 'Rp ' + (Math.round(harga + 4250)).toLocaleString('id-ID');
                }
                if (vabca !== null) {
                    vabca.innerHTML = 'Rp ' + (Math.round(harga + 5500)).toLocaleString('id-ID');
                }
                if (vapermata !== null) {
                    vapermata.innerHTML = 'Rp ' + (Math.round(harga + 4250)).toLocaleString('id-ID');
                }
                if (vamandiri !== null) {
                    vamandiri.innerHTML = 'Rp ' + (Math.round(harga + 4250)).toLocaleString('id-ID');
                }
                if (vabri !== null) {
                    vabri.innerHTML = 'Rp ' + (Math.round(harga + 4250)).toLocaleString('id-ID');
                }
                if (indomaret !== null) {
                    indomaret.innerHTML = 'Rp ' + (Math.round(harga + 3500)).toLocaleString('id-ID');
                }
                if (alfamart !== null) {
                    alfamart.innerHTML = 'Rp ' + (Math.round(harga + 6000)).toLocaleString('id-ID');
                }
                if (alfamidi !== null) {
                    alfamidi.innerHTML = 'Rp ' + (Math.round(harga + 6000)).toLocaleString('id-ID');
                }



            }

        }
    });
}

function update_total() {
    get_price($("#product_id").val());
}

function nonaktif_button() {
    document.getElementById('1xorder').style.visibility = 'hidden';
}

function process_order() {

    var product = $("input[name=product]:checked").val();
    var method = $("input[name=method]:checked").val();

    if (product == '' || product == ' ') {
        Swal.fire('Gagal', 'Nominal produk harus dipilih', 'error');
    } else if (method == '' || method == ' ') {
        Swal.fire('Gagal', 'Pilih metode pembayaran', 'error');
    } else {
        $.ajax({
            url: '<?= base_url(); ?>/user/order/get-detail/' + product,
            data: 'method=' + method ,
            type: 'POST',
            dataType: 'JSON',
            beforeSend: function() {
                $("#modal-loading").modal('hide');
            },
            success: function(result) {

                $("#modal-loading").modal('hide');

                if (result.status == true) {
                    $("#modal-detail div div .modal-body").html(result.msg);

                    $("#modal-detail").modal('show');
                } else {
                    Swal.fire('Gagal', result.msg, 'error');
                }
            }
        });
    }
}
</script>
<?php $this->endSection(); ?>