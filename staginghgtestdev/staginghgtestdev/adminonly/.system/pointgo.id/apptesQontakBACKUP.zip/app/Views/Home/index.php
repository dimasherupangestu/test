<?php $this->extend('template'); ?>

<?php $this->section('css'); ?>



<style>
@media screen and (min-width: 768px) {
    .coda-about__card-container {
        width: 50%;
        display: inline-flex;
    }
    .banner-skeleton {
  height: 400px !important; /* Tinggi yang sesuai */
}
}

@media (max-width: 480px) {
    .card-title2 {
        font-size: 0.6rem !important;
        font-weight: 700 !important;
    }
}

@media (min-width:900px){f
    .img-fluid {
    max-width: 100%;
    height: auto;
}
.card img.img-games {
    width: 13rem;
}
}


.coda-about__card-icon-container[data-v-7e34a1fb] {
    max-width: 60px;
    max-height: 60px;
    width: 20%;
    padding: 10px;
    background-color: #eae8f7;
    border-radius: 50%;
    display: inline-flex;
    justify-content: center;
    align-items: center;
}

.coda-about__card-container[data-v-7e34a1fb] {
    padding: 10px 0;
    flex-direction: row;
    justify-content: flex-start;
    align-items: flex-start;
}

.coda-about__card-content[data-v-7e34a1fb] {
    padding-left: 10px;
}

.coda-about__sub-header[data-v-24b86abb] {
    word-break: break-word;
    font-size: 1rem;
}

.coda-about__header[data-v-24b86abb] {
    font-size: 3rem;
    font-weight: bold;
    padding: 5px 0 10px 0;
    margin: 0;
    word-break: break-word;
    line-height: 40px;
}

.coda-about__card-title[data-v-7e34a1fb] {
    margin: 0 0 10px;
    font-size: .875rem;
}

.tab-category.nav-pills .nav-link {
    color: rgba(255, 255, 255, 0.8);
    border: 1px solid #ffffff5c;
    border-radius: 10px;
}

.tab-category.nav-pills .nav-link:hover {
    color: var(--warna_4);
    border: 1px solid var(--warna_4);
}

.nav-pills .nav-link.active,
.nav-pills .show>.nav-link {
    color: var(--warna_4);
    background-color: #0000;
    border: 1px solid var(--warna_4);
}

.nav-pills .nav-link {
    margin: 0px !important;
    font-size: 11px;
}

.swiper-container {
    width: 100%;
    position: relative;
    overflow: hidden;
}

.swiper-slide {
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    font-size: 48px;
    font-weight: bold;
    color: #fff;
    transition: transform 0.3s ease;
    z-index: 1;
}



.swiper-pagination-bullet {
    width: 8px;
    height: 8px;
    margin: 0 8px;
    background-color: #fff;
    opacity: 0.5;
    border-radius: 50%;
    cursor: pointer;
    transition: opacity 0.3s ease;
}

.swiper-pagination-bullet.swiper-pagination-bullet-active {
    opacity: 1;
    background-color: var(--warna_4);
}

.swiper-pagination {
    bottom: inherit !important;
    padding-top: 15px;
}

.swiper-slide-active {
    transform: scale(1);
    z-index: 2;
}

@media(min-width: 700px) {
    .swiper-slide {
        height: 100% !important;
        margin-right: 10px !important;
        display: block;
        object-fit: contain;
    }
}

.swiper-slide {
    margin-right: 10px !important;
    display: block;
    object-fit: contain;
}

.swiper-button-next,
.swiper-button-prev {
    background: var(--warna);
    padding: 50px 20px 50px 20px;
    border-radius: 10px;
    color: var(--warna_4);
    top: var(--swiper-navigation-top-offset, 35%);
}

.swiper-button-next:after,
.swiper-button-prev:after {
    font-family: swiper-icons;
    font-size: 18px;
    font-weight: 600;
    text-transform: none !important;
    letter-spacing: 0;
    font-variant: initial;
    line-height: 1;
}


.produk-flash-sale {
    text-align: left;
    font-size: 19px;
    font-weight: 600;
    margin-bottom: 0rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.harga-disc {
    text-align: left;
    font-size: 15px;
    font-weight: 600px;
}

.harga-coret {
    text-align: left;
    font-size: 12px;
    font-weight: 500;
    text-decoration: line-through;
    color: red;
    padding-left: 10px;
}

.pl-title2 {
    font-size: 10px;
    padding-top: 5px;
    font-weight: 200;
    text-align: center;
    line-height: 15px;
    overflow: hidden;
}

.card-game {
    padding: 0rem;
}

.card.mb-3:hover {
    border: 1px solid var(--warna_4);
    transition: 0.3s ease
}

.card.mb-3 {
    border: 1px solid #0000;
}


.artikel-tanda {
    display: inline-flex;
    flex-direction: column;
    position: absolute;
    top: 0px;
    background-color: #707feb;
    padding: 4px 8px 4px;
    width: 100%;
    height: 45px;
    justify-content: center;
    right: -43%;
    transform: rotate(45deg);
}

.category-artikel {
    display: inline-flex;
    justify-content: center;
    overflow-wrap: break-word;
    word-break: break-word;
    overflow: hidden;
    position: relative;
    border-radius: 16px;
    width: 100%;
}

.gap-2 {
    gap: 0.5rem;
}

.readMore,
.readLess {
    color: var(--warna_4);
    cursor: pointer;
}

.img-promo {
    width: 100%;
    height: 150px;
}

.img-promo img {
    object-fit: cover;
    width: 100%;
    height: 100%;
    object-position: top;
}


.slick-list {
    padding-top: 5% !important;
    padding-bottom: 5% !important;
    padding-left: 15% !important;
    padding-right: 15% !important;
    overflow: visible;
}

.slick-dots {
    text-align: right;
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
}

.slick-track {
    max-width: 100% !important;
    transform: translate3d(0, 0, 0) !important;
    perspective: 100px;
}

.slick-slide {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    opacity: 0;
    width: 100% !important;
    transform: translate3d(0, 0, 0);
    transition: transform 1s, opacity 1s;
}

.slick-snext,
.slick-sprev {
    display: block;
    opacity: 0.7;
    filter: contrast(0.8);
}

.slick-current {
    opacity: 1;
    position: relative;
    display: block;
    transform: translate3d(0, 0, 20px);
    z-index: 2;
}

.slick-snext {
    transform: translate3d(60%, 0, 0px);
    z-index: 1;
}

.slick-sprev {
    transform: translate3d(-60%, 0, 0px);
}

.img-banner-slick {
    border-radius: 20px;
}

.slick-slide {
    border-radius: 20px;
    margin-right: 20px;
}

.bg-flashsale-up {
    position: absolute;
    bottom: 28px;
    right: 0;
    font-size: 13px;
    font-weight: 300;
}

.bg-flashsale-up .price-cor-fs {
    text-decoration: line-through;
}

.bg-flashsale-down {
    position: absolute;
    bottom: 0;
    right: 0;
    text-align: right;
    font-size: 20px;
}

.justify-between {
    justify-content: space-between;
}

.flex-col {
    flex-direction: column;
}
.banner-pad {
    padding: 0px 300px;
}

@media (max-width: 600px) {
    .banner-pad {
        padding: 8px 0px;
    }
}
.banner-skeleton {
  background-color: #e1e1e1; /* Warna latar belakang yang cocok */
  border-radius: 16px; /* Sudut bulat sesuai desain Anda */
  height: 175px; /* Tinggi yang sesuai */
  width: 100%; /* Lebar penuh */
  animation: pulse 1.5s infinite; /* Animasi pulsasi dengan durasi 1.5 detik dan berulang tak terbatas */
}

@keyframes pulse {
  0% {
    opacity: 1; /* Opasitas penuh pada awal animasi */
  }
  50% {
    opacity: 0.6; /* Opasitas sedikit lebih rendah di tengah animasi */
  }
  100% {
    opacity: 1; /* Kembali ke opasitas penuh pada akhir animasi */
  }
}
.rev_slider:not(.loaded) {
    display: none; /* Sembunyikan konten banner sebenarnya selama "skeleton" banner ditampilkan */
  }
</style>
<?php $this->endSection(); ?>

<?php $this->section('content'); ?>


<div class="mb-4" style="padding-top: 30px;">
    <div class="pt-0" style="">
        <div class="container banner-pad">
            <!-- Skeleton Loading Banner -->
            <div class="banner-skeleton">
              <!-- Placeholder gambar atau teks -->
            </div>
            <div class="rev_slider">
                <?php $no = 1;
                    foreach ($banner as $loop): ?>
                <a class="rev_slide" href="<?= $loop['url']; ?>">
                    <img style="border-radius: 16px;" class="d-block w-100 test"
                        src="<?= base_url(); ?>/assets/images/banner/<?= $loop['image']; ?>" alt="First slide">
                </a>
                <?php $no++; endforeach ?>
            </div>
        </div>
    </div>
</div>



<div class="container mb-3 mt-3">

    <div style="border-radius: 10px;padding: 10px 20px 10px 20px;    background-color: #0000!important;">
        <h5 style="display: inline-block;"><i class="fa fa-bolt"></i> Diskon Terbaik POINTGO</h5>
        <p style="display: inline-block;" id="expired_time_flash_sale" class="countdown-time"></p>
        <div class="swiper-container two">
            <div class="swiper-wrapper">
                <?php foreach ($flashsale as $flashsales): ?>
                <div class="swiper-slide slide-container">
                    <div class="slide-content">
                        <!-- Add your slide content here -->
                        <a
                            href="<?= base_url(); ?>/games/<?= $flashsales['game_slug']; ?>?diamonds=<?= $flashsales['product_id']; ?>">
                            <div style="background: linear-gradient(180deg, rgba(0,0,0,.00) 0%, #000), url(<?= base_url(); ?>/assets/images/games/<?= $flashsales['game_image']; ?>);background-size: cover;"
                                alt="slide <?= $no; ?>" class="card-flashsale">
                                <div class="row swiper-wrapper">
                                    <div class="col-12 pb-2 justify-between flex-col d-flex">
                                        <img src="<?= base_url(); ?>/assets/images/games/<?= $flashsales['game_image']; ?>"
                                            alt="flashsales <?= $title; ?> <?= $flashsales['title']; ?>"
                                            class="mb-2 img-games-fs"
                                            style="display: block; border-radius: 999px !important;object-position: left;border: 1px solid #fff;">
                                        <p class="produk-flash-sale"><?= $flashsales['title']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <svg class="bg-flashsale-up" xmlns="http://www.w3.org/2000/svg" width="78" height="27"
                            viewBox="0 0 78 27" fill="none">
                            <path d="M4.23913 4L78 0V24L0 27L4.23913 4Z" fill="black" />
                            <text x="77" y="20" fill="white" text-anchor="end"
                                class="price-cor-fs"><?= number_format($flashsales['discount_price'], 0, ',', '.'); ?></text>
                        </svg>
                        <svg class="bg-flashsale-down" xmlns="http://www.w3.org/2000/svg" width="137" height="31"
                            viewBox="0 0 137 31" fill="none">
                            <path d="M3.09023 4L137 0V11C137 22.0457 128.046 31 117 31H0L3.09023 4Z" fill="#BDFC50" />
                            <text x="125" y="23" fill="black" text-anchor="end"
                                class="price-fs"><?= number_format($flashsales['price'], 0, ',', '.'); ?></text>
                        </svg>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
        <div class="swiper-pagination"></div>
    </div>

</div>

<div class="container">
    <div class="PB-5 pt-5" style="border-radius: 10px;padding: 10px; overflow: hidden;">
        <ul class="nav nav-pills tab-category gap-2 pb-2" id="pills-tab" role="tablist"
            style="flex-wrap: nowrap;justify-content: flex-start;overflow-y: hidden;    padding-bottom: 0px;">
            <li class="nav-item">
                <a style="white-space: pre;font-weight: 600;" class="nav-link active" id="pills-all-tab"
                    data-toggle="pill" href="#pills-all" role="tab" aria-controls="pills-all"
                    aria-selected="true">All</a>
            </li>
            <?php $no = 1;
            foreach ($games as $game): ?>
            <li class="nav-item">
                <a style="white-space: pre;font-weight: 600;" class="nav-link "
                    id="pills-<?= url_title($game['category'], '-', true); ?>-tab" data-toggle="pill"
                    href="#pills-<?= url_title($game['category'], '-', true); ?>" role="tab"
                    aria-controls="pills-<?= url_title($game['category'], '-', true); ?>"
                    aria-selected="true"><?= $game['category']; ?></a>
            </li>
            <?php $no++; endforeach ?>

        </ul>
    </div>
</div>

<div class="tab-content" id="pills-tabContent">
    <!-- Tab All -->
    <div class="tab-pane fade show active" id="pills-all" role="tabpanel" aria-labelledby="pills-all-tab">
        <?php foreach ($games as $game): ?>
        <div class="container pt-4 pb-4">
            <div class="row">
                <div class="col-12">
                    <h5 style="font-size: 32px; color:#fff;"><?= $game['category']; ?></h5>
                </div>
            </div>
        </div>
        <div class="pb-4">
            <div class="container">
                <div class="row game">

                    <?php foreach ($game['games'] as $loop): ?>
                    <?php if ($loop['status'] == 'On'): ?>
                    <div style="margin-bottom: 30px;display: flex;" class="col-sm-3 col-lg-2 col-4 text-center">
                        <div class="card mb-3" style="">
                            <a href="<?= base_url(); ?>/games/<?= $loop['slug']; ?>" class="product_list">
                                <div style="margin-bottom: 0px;" class="card" bis_skin_checked="1">
                                    <img src="<?= base_url(); ?>/assets/images/games/<?= $loop['image']; ?>"
                                        class="img-fluid img-games" style="border-radius: 10px; display: block;">
                                    <div data-v-16b318a8="" class="product-tile__clip-path"></div>
                                    <div class="card-title2" bis_skin_checked="1"><?= $loop['games']; ?></div>
                                    <div class="card-subtitle" bis_skin_checked="1"></div>
                                    <div class="card-topup" bis_skin_checked="1" hidden>
                                        <div class="btn-topup" style="font-size: 0.60rem!important;"
                                            bis_skin_checked="1"> TOP UP </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php endif ?>
                    <?php endforeach ?>

                </div>
            </div>
        </div>
        <?php endforeach ?>
    </div>

    <?php $no = 1;
            foreach ($games as $game): ?>
    <div class="tab-pane fade " id="pills-<?= url_title($game['category'], '-', true); ?>" role="tabpanel"
        aria-labelledby="pills-<?= url_title($game['category'], '-', true); ?>-tab">
        <div class="container pt-4 pb-4">
            <div class="row">
                <div class="col-12">
                    <h5 style="font-size: 32px; color:#fff;"><?= $game['category']; ?></h5>

                </div>
            </div>
        </div>
        <div class="pb-4">
            <div class="container">
                <div class="row game">
                    <?php foreach ($game['games'] as $loop): ?>
                    <?php if ($loop['status'] == 'On'): ?>
                    <div style="margin-bottom: 30px;display: flex;" class="col-sm-3 col-lg-2 col-4 text-center">
                        <div class="card mb-3 " style="">
                            <a href="<?= base_url(); ?>/games/<?= $loop['slug']; ?>" class="product_list">
                                <div style="margin-bottom: 0px;" class="card" bis_skin_checked="1">
                                    <img src="<?= base_url(); ?>/assets/images/games/<?= $loop['image']; ?>"
                                        class="img-fluid img-games" style="border-radius: 10px; display: block;">
                                    <div data-v-16b318a8="" class="product-tile__clip-path"></div>
                                    <div class="card-title2" bis_skin_checked="1"><?= $loop['games']; ?></div>
                                    <div class="card-subtitle" bis_skin_checked="1"></div>
                                    <div class="card-topup" bis_skin_checked="1" hidden>
                                        <div class="btn-topup" style="font-size: 0.60rem!important;"
                                            bis_skin_checked="1"> TOP
                                            UP </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php endif ?>
                    <?php endforeach ?>
                </div>
            </div>
        </div>
    </div>
    <?php $no++; endforeach ?>
</div>

<div class="mb-5">

    <div class="container">
        <div class="row">
            <div style="border-radius:25px;padding:15px;">
                <h5 style="font-size: 32px; color:#fff;text-transform: uppercase;">PROMO </h5>
                <div class="d-flex element-scroll" style="overflow-x: scroll;">
                    <?php foreach ($post as $loop): ?>
                    <div class="col-sm-12 col-lg-4 col-12 text-center" style="display: grid;">
                        <div class="card tes-card"
                            style="margin-bottom: 2.5rem!important;margin-top: 1.5rem;padding: 0.4rem !important;">
                            <div href="<?= base_url(); ?>/post/<?= $loop['id']; ?>" class="category-artikel">
                                <div class="card-game pb-3">
                                    <div class="img-promo">
                                        <img src="<?= base_url(); ?>/assets/images/post/<?= $loop['image']; ?>"
                                            class="img-fluid">
                                    </div>
                                    <h5 style="padding: 18px 18px 18px 18px;text-align: left;margin-bottom: 0rem;">
                                        <?= $loop['title']; ?></h5>
                                    <div class="promo text-left" style="padding: 0px 18px 0px 18px;">
                                        <?= htmlspecialchars_decode($loop['content']); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container" style="padding-bottom: 100px;" hidden>
    <div data-v-3917c69b="" class="home__feeds-items">
        <!---->
        <!---->
        <!---->
        <!---->
        <div data-v-24b86abb="" data-v-3917c69b="" class="coda-about__container">
            <div data-v-24b86abb="" class="coda-about__content">
                <h1 data-v-24b86abb="" class="coda-about__header"><?= $title; ?></h1>
                <h2 data-v-24b86abb="" class="coda-about__sub-header"><?= $title; ?>: <?= $web['title']; ?></h2>
                <p data-v-24b86abb="" class="coda-about__short-description">Setiap bulannya, jutaan gamers menggunakan
                    <?= $title; ?> untuk melakukan pembelian kredit game dengan lancar: tanpa registrasi ataupun log-in,
                    dan kredit permainan akan ditambahkan secara instan. Top-up Mobile Legends, Free Fire, Ragnarok M,
                    dan berbagai game lainnya!</p>
                <article data-v-24b86abb="" class="coda-about__card-group">
                    <div data-v-7e34a1fb="" data-v-24b86abb="" class="coda-about__card-container">
                        <div data-v-7e34a1fb="" class="coda-about__card-icon-container">
                            <img data-v-7e34a1fb="" alt="Quick icon"
                                src=""
                                height="36" width="36" class="coda-about__card-icon">
                        </div>
                        <div data-v-7e34a1fb="" class="coda-about__card-content">
                            <h3 data-v-7e34a1fb="" class="coda-about__card-title">Bayar dalam hitungan detik</h3>
                            <p data-v-7e34a1fb="" class="coda-about__card-description">Hanya dibutuhkan beberapa detik
                                saja untuk menyelesaikan pembayaran di <?= $title; ?> karena situs kami berfungsi dengan
                                baik dan mudah untuk digunakan.</p>
                        </div>
                    </div>
                    <div data-v-7e34a1fb="" data-v-24b86abb="" class="coda-about__card-container">
                        <div data-v-7e34a1fb="" class="coda-about__card-icon-container">
                            <img data-v-7e34a1fb="" alt="Delivery icon"
                                src=""
                                height="36" width="36" class="coda-about__card-icon">
                        </div>
                        <div data-v-7e34a1fb="" class="coda-about__card-content">
                            <h3 data-v-7e34a1fb="" class="coda-about__card-title">Pengiriman instan</h3>
                            <p data-v-7e34a1fb="" class="coda-about__card-description">Ketika kamu melakukan top-up di
                                <?= $title; ?>, item atau barang yang kamu beli akan selalu dikirim ke akun kamu secara
                                instan dan cepat, tanpa tertunda.</p>
                        </div>
                    </div>
                    <div data-v-7e34a1fb="" data-v-24b86abb="" class="coda-about__card-container">
                        <div data-v-7e34a1fb="" class="coda-about__card-icon-container">
                            <img data-v-7e34a1fb="" alt="Payments icon"
                                src=""
                                height="36" width="36" class="coda-about__card-icon">
                        </div>
                        <div data-v-7e34a1fb="" class="coda-about__card-content">
                            <h3 data-v-7e34a1fb="" class="coda-about__card-title">Metode pembayaran terbaik</h3>
                            <p data-v-7e34a1fb="" class="coda-about__card-description">Kami menawarkan begitu banyak
                                pilihan pembayaran mulai dari potong pulsa, e-wallet, bank transfer, dan pembayaran di
                                mini market terdekat.</p>
                        </div>
                    </div>
                    <div data-v-7e34a1fb="" data-v-24b86abb="" class="coda-about__card-container">
                        <div data-v-7e34a1fb="" class="coda-about__card-icon-container">
                            <img data-v-7e34a1fb="" alt="Customer Support"
                                src=""
                                height="36" width="36" class="coda-about__card-icon">
                        </div>
                        <div data-v-7e34a1fb="" class="coda-about__card-content">
                            <h3 data-v-7e34a1fb="" class="coda-about__card-title">Layanan Pelanggan</h3>
                            <p data-v-7e34a1fb="" class="coda-about__card-description">Tim support siap membantu Anda
                                dari pukul 9 pagi hingga 10 malam, 7 hari seminggu. Kirimkan <a
                                    href="https://id.support.codashop.com/hc/id-id/requests/new" target="_blank">
                                    Support Request Form </a> dan kami akan segera menghubungi Anda!</p>
                        </div>
                    </div>
                    <div data-v-7e34a1fb="" data-v-24b86abb="" class="coda-about__card-container">
                        <div data-v-7e34a1fb="" class="coda-about__card-icon-container">
                            <img data-v-7e34a1fb="" alt="Promo icon"
                                src=""
                                height="36" width="36" class="coda-about__card-icon">
                        </div>
                        <div data-v-7e34a1fb="" class="coda-about__card-content">
                            <h3 data-v-7e34a1fb="" class="coda-about__card-title">Promosi-promosi menarik</h3>
                            <p data-v-7e34a1fb="" class="coda-about__card-description">Penggemar game dapat bergantung
                                pada POINTGO karena kami memberikan penawaran menarik, diskon dan kode item dari promosi
                                game yang disukai kamu.</p>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </div>
</div>
<div class="container pt-4 pb-4" style="padding: 1.5rem !important;" hidden>
    <div class="row">
        <div class="row col-sm-6 col-12">
            <h5 style="font-size: 40px; color:#fff;text-transform: uppercase;">Ikuti Kami</h5>
            <p><br>Dapatkan Informasi Dan Promo Menarik Dengan Cara Mengikuti Media Sosial kami.</p>
            <div class="col-3 card m-2" style="background-color:#32323E!important;align-items: center;">
                <img src="<?= base_url(); ?>/assets/images/instagram.svg" class="pt-4 img-fluid text-center"
                    style="border-radius: 10px; display: block; width: 80px" href="<?= $sm['ig']; ?>">
                <a href="<?= $sm['ig']; ?>" class="text-center mb-4"
                    style="font-weight:bold;font-size:17px">Instagram</a>
            </div>
            <div class="col-3 card m-2" style="background-color:#32323E!important;align-items: center;">
                <img src="<?= base_url(); ?>/assets/images/tiktok.svg" class="pt-4 img-fluid text-center"
                    style="border-radius: 10px; display: block; width: 80px" href="<?= $sm['tw']; ?>">
                <a href="<?= $sm['tw']; ?>" class="text-center mb-4" style="font-weight:bold;font-size:17px">Tiktok</a>
            </div>
            <div class="col-3 card m-2" style="background-color:#32323E!important;align-items: center;">
                <img src="<?= base_url(); ?>/assets/images/youtube.svg" class="pt-4 img-fluid text-center"
                    style="border-radius: 10px; display: block; width: 80px" href="<?= $sm['yt']; ?>">
                <a href="<?= $sm['yt']; ?>" class="text-center mb-4" style="font-weight:bold;font-size:17px">Youtube</a>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="myModal111" aria-labelledby="modalInformationsLabel" tabindex="-1" aria-hidden="true"
    style="display: none;">
    <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
        <div class="modal-content " style="background-color: #06142f !important;box-shadow:0 0 2rem #000000 !important">
            <div class="modal-body">
                <div class="row" id="textInfo">
                    <div class="col-12 mb-2">
                        <div class="card"
                            style="border:1px solid #4b4d50;background-color: #484d52;box-shadow:0px 0px 0px #e7e7e7 !important">
                            <div class="card-header">
                                <h5 style="color: #fff;font-size;1.25rem">Perhatian !</h5>
                            </div>
                            <div class="card-body pb-1" style="background-color: #06142f !important">
                                <div class="col-12" style="text-align:center">
                                    <img src="<?= base_url(); ?>/assets/images/<?= $web['logo']; ?>" width="70%" class="mb-2">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col" style="text-align: right!important;">
                        <button type="submit" data-dismiss="modal"
                            style="font-size:12px;background-color: #fff !important;color:#06142F !important;padding:10px;font-size:12px;font-weight:500"
                            class="close btn btn-sm">
                            Tutup
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if ($popup['status'] == 'On'): ?>
<!-- Modal -->
<div class="modal fade" id="PopUpText" tabindex="-1" role="dialog" aria-labelledby="PopUpTextTitle" aria-hidden="true"
    style="z-index: 99999; margin-top: -35px;">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content shadow-lg" style="background-color: var(--warna_2);">
            <div class="modal-header" style="background-color: var(--warna_2);">
                <h5 class="modal-title text-white"><b><?= $popup['title']; ?></b></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                    style="border:0;background: var(--warna_2);color: #fff;"><i class="fa fa-times text-white" aria-hidden="true"></i></button>
            </div>
            <div class="modal-body text-white" style="font-size: 13px;">
                <?php if (!empty($popup['image']) && $popup['image'] !== '-'): ?>
                    <img onerror="this.style.display='none'" src="<?= base_url(); ?>/assets/images/<?= $popup['image']; ?>"
                        width="100%" class="text-center img-fluid" style="border-radius: 5px;margin-bottom:20px">
                <?php endif; ?>
                <?= $popup['desc']; ?>
                <span style="font-size: 11px; color: rgba(37, 99, 235, 1);"><?= $popup['date']; ?></span>
            </div>
            <div class="modal-footer">
                <button type="button" id="popupButton" class="btn btn-sm btn-danger" data-bs-dismiss="modal">Saya sudah
                    membaca</button>
            </div>
        </div>
    </div>
</div>
<?php endif ?>

<?php $this->endSection(); ?>

<?php $this->section('js'); ?>
<script>
var rev = $('.rev_slider');
rev.on('init', function(event, slick, currentSlide) {
    var cur = $(slick.$slides[slick.currentSlide]),
        next = cur.next(),
        prev = cur.prev();
    prev.addClass('slick-sprev');
    next.addClass('slick-snext');
    cur.removeClass('slick-snext').removeClass('slick-sprev');
    slick.$prev = prev;
    slick.$next = next;
}).on('beforeChange', function(event, slick, currentSlide, nextSlide) {
    console.log('beforeChange');
    var cur = $(slick.$slides[nextSlide]);
    console.log(slick.$prev, slick.$next);
    slick.$prev.removeClass('slick-sprev');
    slick.$next.removeClass('slick-snext');
    next = cur.next(),
        prev = cur.prev();
    prev.prev();
    prev.next();
    prev.addClass('slick-sprev');
    next.addClass('slick-snext');
    slick.$prev = prev;
    slick.$next = next;
    cur.removeClass('slick-next').removeClass('slick-sprev');
});

rev.slick({
    speed: 1000,
    arrows: false,
    dots: false,
    focusOnSelect: true,
    infinite: true,
    centerMode: true,
    slidesPerRow: 1,
    slidesToShow: 1,
    slidesToScroll: 1,
    centerPadding: '0',
    swipe: true,
    customPaging: function(slider, i) {
        return '';
    },
    /*infinite: false,*/
    autoplay: true, // Add autoplay
    autoplaySpeed: 2000, // Set autoplay speed (in milliseconds)
}).on('setPosition', function() {
    $('.banner-skeleton').hide();
    $('.rev_slider').addClass('loaded');
});
</script>

<script>
function truncateContent(contentClass, maxLength) {
    var contentDivs = document.getElementsByClassName(contentClass);

    Array.from(contentDivs).forEach(function(contentDiv) {
        var content = contentDiv.textContent.trim();
        var truncatedContent = content.slice(0, maxLength);

        if (content.length > maxLength) {
            contentDiv.innerHTML = truncatedContent + '... <a href="#" class="readMore">Selengkapnya</a>';
        }

        contentDiv.addEventListener('click', function(event) {
            if (event.target.classList.contains('readMore')) {
                event.preventDefault();
                contentDiv.innerHTML = content + ' <a href="#" class="readLess">lebih sedikit</a>';
            } else if (event.target.classList.contains('readLess')) {
                event.preventDefault();
                contentDiv.innerHTML = truncatedContent +
                    '... <a href="#" class="readMore">Selengkapnya</a>';
            }
        });
    });
}

truncateContent('promo', 130);
</script>
<!-- Facebook Pixel Code -->
   <script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  
  fbq('init', '{938473200580408}');
  fbq('init', '{9532506813488688}');
  fbq('init', '{584979920420062}');
  fbq('track', 'PageView');
</script>
<noscript>
  <img height="1" width="1" style="display:none" 
       src="https://www.facebook.com/tr?id={938473200580408}&ev=PageView&noscript=1"/>
  <img height="1" width="1" style="display:none" 
       src="https://www.facebook.com/tr?id={9532506813488688}&ev=PageView&noscript=1"/>
  <img height="1" width="1" style="display:none" 
       src="https://www.facebook.com/tr?id={584979920420062}&ev=PageView&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

<script type="text/javascript">
$(window).on('load', function() {

    var popupLastShown = localStorage.getItem('popupLastShown');
    var time_left = popupLastShown ? Math.round((popupLastShown - Date.now()) / 1000) : 0;

    if (!popupLastShown || time_left <= 0) {
        $('#PopUpText').modal('show');
    } else {
        $('#PopUpText').modal('hide');
    }

    // When the button is clicked, hide the popup and store the current time
    $('#popupButton').click(function() {
        localStorage.setItem("popupLastShown", Date.now() + (24 * 60 * 60 * 1000));
        $('#PopUpText').modal('hide');
    });
});
</script>

<script>
$(document).ready(function() {
    var timeParsed = '<?= $expired; ?>'.replace(' ', 'T').split(/[^0-9]/);
    var countDown = new Date(new Date(timeParsed[0], timeParsed[1] - 1, timeParsed[2], timeParsed[3],
        timeParsed[4], timeParsed[5])).getTime();

    var x = setInterval(() => {
        let nowTime = new Date().getTime();
        // Find the distance between now and the count down date
        var distance = countDown - nowTime;

        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Display the result in the element with id="demo"
        if (distance > 0) {
            // document.getElementById("expired_time").innerHTML = `${minutes} minutes ${seconds} seconds`
            $("#expired_time_flash_sale").text(`${days}:${hours}:${minutes}:${seconds}`)
        }
    }, 1000);

    $("#paycode").tooltip();
    $("#paycode").click(function() {
        copyToClipboard($(this).text().trim().replace(".", ""), $(this));
    })
    $("#paycode").css('cursor', 'pointer');
})
</script>

<script>
var swiper = new Swiper(".swiper-container.two", {
    loop: true,
    centerSlide: 'true',
    fade: 'true',
    grabCursor: 'true',
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },

    autoplay: {
        delay: 3000,
        disableOnInteraction: false,
    },
    breakpoints: {
        // when window width is >= 320px
        320: {
            slidesPerView: 2,
            spaceBetween: 10
        },
        // when window width is >= 480px
        480: {
            slidesPerView: 2,
            spaceBetween: 10
        },
        // when window width is >= 640px
        640: {

            slidesPerView: 3,
            spaceBetween: 10

        }
    }
});
</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- <script>
$(document).ready(function() {
    $("#searchInput").keyup(function() {
        var searchQuery = $("#searchInput").val();
        if (searchQuery.length >= 2) {
            $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>/home/search",
                data: {
                    searchQuery: searchQuery
                },
                success: function(data) {
                    $("#searchResultsContainer").html(data);
                }
            });
        } else {
            $("#searchResultsContainer").empty();
        }
    });
});
</script>
<script>
const searchContainer = document.getElementById('searchResultsContainer');

// Tambahkan event listener ke elemen dokumen
document.addEventListener('click', function(event) {
    // Cek apakah elemen yang diklik adalah bagian dari kontainer pencarian atau tidak
    if (!searchContainer.contains(event.target)) {
        // Jika tidak, sembunyikan kontainer pencarian
        searchContainer.innerHTML = '';
    }
});
</script> -->
<?php $this->endSection(); ?>