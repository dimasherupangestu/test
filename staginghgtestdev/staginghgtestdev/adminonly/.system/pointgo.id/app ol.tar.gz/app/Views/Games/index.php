<?php $this->extend('template'); ?>

<?php $this->section('css'); ?>

<style>
.contentgame {
    color: #000;
    font-size: 12px;
    background: #d9d9d99c;
    padding: 1.5rem;
    border-radius: 9px;
}

.contentgame p {
    color: #000 !important;
}

h5.pb-2,
h5.mb-2 {
    color: .h5, h5
}

p {
    color: #fff
}

.h3,
h3 {
    font-size: 25px;
}

.cutoffbank {
    filter: grayscale(1);
    pointer-events: none;

}

@media (max-width: 900px) {
    .hanz-modal {
        margin-left: 30% !important;
    }
}

.cutoffbank p {
    font-size: 10px !important;
    line-height: 13px;
    margin-bottom: 0.5rem !important;
    margin-right: 1rem !important;
    margin-left: 1rem !important;
    font-weight: 600;
}

button.accordion-button {
    outline: none !important;
    border: 1px solid #0000;
    background-color: #272727;
    border-radius: 6px;
    padding: 7px 20px;
    font-weight: 600;
}

.single-payment .radio-nominal:checked + label {
    border: 2px solid var(--warna_4) !important;
    box-shadow: 0 0 200px rgb(189 252 80 / 10%) inset;
    transition: 0.3s ease;
}

.accordion-button[aria-expanded="true"] {
    border: 1px solid var(--warna_4);
    box-shadow: 0 0 200px rgb(189 252 80 / 10%) inset;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
}

/* .accordion-collapse.collapsing {
    border: 1px solid var(--warna_4);
    border-top: 0;
    border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
}

.accordion-collapse.collapse.show {
    border: 1px solid var(--warna_4);
    border-top: 0;
    border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
} */

.text-end {
    text-align: right !important;
}

.accordion {
    --bs-accordion-color: #000;
    --bs-accordion-bg: #fff;
    --bs-accordion-transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, border-radius 0.15s ease;
    --bs-accordion-border-color: var(--bs-border-color);
    --bs-accordion-border-width: 1px;
    --bs-accordion-border-radius: 0.375rem;
    --bs-accordion-inner-border-radius: calc(0.375rem - 1px);
    --bs-accordion-btn-padding-x: 1.25rem;
    --bs-accordion-btn-padding-y: 1rem;
    --bs-accordion-btn-color: var(--bs-body-color);
    --bs-accordion-btn-bg: var(--bs-accordion-bg);
    --bs-accordion-btn-icon: url(data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='var%28--bs-body-color%29'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e);
    --bs-accordion-btn-icon-width: 1.25rem;
    --bs-accordion-btn-icon-transform: rotate(-180deg);
    --bs-accordion-btn-icon-transition: transform 0.2s ease-in-out;
    --bs-accordion-btn-active-icon: url(data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%230c63e4'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e);
    --bs-accordion-btn-focus-border-color: #86b7fe;
    --bs-accordion-btn-focus-box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
    --bs-accordion-body-padding-x: 1.25rem;
    --bs-accordion-body-padding-y: 1rem;
    --bs-accordion-active-color: #0c63e4;
    --bs-accordion-active-bg: #e7f1ff;
}


.accordion-body {
    background: #272727;
    border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
    border: 1px solid var(--warna_4);
}

.accordion-button {
    position: relative;
    display: flex;
    align-items: center;
    width: 100%;
    padding: var(--bs-accordion-btn-padding-y) var(--bs-accordion-btn-padding-x);
    font-size: 1rem;
    color: var(--bs-accordion-btn-color);
    text-align: left;
    background-color: var(--bs-accordion-btn-bg);
    border: 0;
    border-radius: 0;
    overflow-anchor: none;
    transition: var(--bs-accordion-transition);
}


.boks {
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    border-radius: 6px;
}

.col-sm-4,
.col-6 {
    padding-right: 8px;
    padding-left: 8px;
}

.circle-primary {
    border: 4px solid #fff;
    background-color: #141414;
    height: 41px;
    width: 40px;
}


.mb-1,
.my-1 {
    margin-bottom: 0.75rem !important;
}

.border-top {
    border-top: 1px solid #ffffff00 !important;
}

.border-top:checked+label {
    border-top: 1px solid #141414 !important;
}


.discount-price {
    font-size: 10px;
    color: red;
    font-weight: 500;
    font-style: italic;
    text-decoration: line-through
}

.icon-diamondx {
    height: 4.6rem;
}

.accordion-button iconify-icon.pl-1 {
    transform: rotateX(177deg);
    transition: 0.2s ease;
}

.accordion-button.collapsed iconify-icon.pl-1 {
    transform: rotateX(0deg);
    transition: 0.2s ease;
}

.single-payment .radio-nominal+label[for="method-balance"], .single-payment .radio-nominal+label[for="method-2"] {
    padding-bottom: 20px;
    padding-top: 20px;
    border: 2px solid transparent;
    border-radius: 6px;
}

.method-accordion .accordion-button {
    padding: 0px 0px;
}

.radio-nominal+label .row .col-1 .rounded-radio svg circle {
    fill: #0000;
    transition: 0.3s ease;
}

.radio-nominal:checked+label .row .col-1 .rounded-radio svg circle {
    fill: var(--warna_4);
}

.bg-banner {
    width: 100%;
    height: 480px;
}

.container-min-banner {
    margin-top: -380px;
}

@media (max-width:480px) {
    .bg-banner {
        width: 100%;
        height: 425px;
    }

    .harga-price-method {
        font-weight: 600;
        font-size: 11px;
    }

    .text-method {
        font-size: 13px;
    }
}

@media (min-width:481px) {
    .bg-banner {
        width: 100%;
        height: 425px;
    }

    button.accordion-button {
        /* padding: 7px 20px; */
    }

    .harga-price-method {
        font-weight: 600;
        font-size: 14px;
    }
}

.total-price-box {
    position: fixed;
    width: 100%;
    bottom: 0;
    background: var(--warna_4);
    z-index: 999;
    padding: 10px 10px;
}

#nominal-text {
    font-size: 16px;
}

.btn-beli {
    background: linear-gradient(180deg, #2D2D2D 0%, #2D2D2D 0.01%, #232323 100%);
    border-radius: 10px;
    font-size: 12px;
    padding: 9px 9px 9px 19px;
}

.flex-col {
    flex-direction: column;
}
</style>

<?php $this->endSection(); ?>

<?php $this->section('content'); ?>
<div class="total-price-box">
    <div class="container">
        <div class="row">
            <div class="col-5">
                <p class="text-dark mb-0">Total</p>
                <h4 class="text-dark mb-0" id="nominal-text"></h4>
            </div>
            <div class="col-7 d-flex justify-content-end">
                <div class="text-right d-flex align-items-center">
                    <button type=" button" class="btn btn-beli text-white" onclick="process_order();">Beli
                    Sekarang <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                        fill="none">
                        <path
                            d="M8.45882 17.9999C8.93213 18.0005 9.3912 17.8381 9.75882 17.5399L14.8588 13.3299C15.0588 13.1707 15.2203 12.9685 15.3313 12.7382C15.4423 12.5079 15.5 12.2556 15.5 11.9999C15.5 11.7443 15.4423 11.492 15.3313 11.2617C15.2203 11.0314 15.0588 10.8292 14.8588 10.6699L9.75882 6.45995C9.45179 6.21394 9.08182 6.05913 8.69109 6.01316C8.30035 5.9672 7.90456 6.03191 7.54882 6.19995C7.23965 6.33623 6.97623 6.55862 6.79004 6.84057C6.60385 7.12251 6.50275 7.45209 6.49882 7.78995V16.2099C6.50275 16.5478 6.60385 16.8774 6.79004 17.1593C6.97623 17.4413 7.23965 17.6637 7.54882 17.7999C7.83469 17.9299 8.14479 17.9981 8.45882 17.9999Z"
                            fill="url(#paint0_linear_74_267)" />
                        <defs>
                            <linearGradient id="paint0_linear_74_267" x1="10.9994" y1="5.99878" x2="10.9994"
                                y2="17.9999" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#BDFB50" />
                                <stop offset="1" stop-color="#99D332" />
                            </linearGradient>
                        </defs>
                    </svg></button>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="pb-1">
    <div style="background: linear-gradient(180deg, rgba(0,0,0,.00) 0%, #000), url(<?= base_url(); ?>/assets/images/games/banner_img/<?= $games['banner_img']; ?>);background-size: cover;"
        alt="slide <?= $no; ?>" class="bg-banner">
    </div>
</div>
<div class="container-min-banner pb-5">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="" style="margin-bottom:20px;">
                    <div class="">
                        <div class="pt-3 pb-2">
                            <img src="<?= base_url(); ?>/assets/images/games/<?= $games['image']; ?>" class="mb-3"
                                style="display: block;border-radius: 99px !important;border: 3px solid #fff;"
                                width="120px" height="120px">
                            <h5><?= $games['games']; ?></h5>
                        </div>
                        <div class="pb-3">
                            <?= $games['content']; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">

                <?= alert(); ?>

                <div class="pb-3 " id="">
                    <div class="section">
                        <div class="body-games shadow-form">
                        <h5 id="judulgame" style="margin-top: 5px;">
                            <?php if ($games['target'] == 'custom'): ?>
                            <?= $games['st_title']; ?>
                            <?php else: ?>
                            Lengkapi Data
                            <?php endif ?>
                        </h5>
                        <?php if ($games['target'] == 'custom'): ?>


                        <div class="form-row pt-3">

                            <?php if ($games['st_col'] == 1): ?>
                            <div class="col">
                                <input type="<?= $games['st1_type']; ?>" name="user_id" class="form-control"
                                    placeholder="<?= $games['st1_text']; ?>" autocomplete="off">
                                <input type="hidden" name="zone_id" value="1">
                            </div>
                            <p class="col-12 mt-2" style="font-size: 10px">
                                <?= $games['st_desc']; ?>
                            </p>



                            <?php elseif ($games['st_col'] == 2): ?>

                            <?php if ($games['st2_type'] == 'dropdown'): ?>
                            <div class="col">
                                <input type="<?= $games['st1_type']; ?>" name="user_id" class="form-control"
                                    placeholder="<?= $games['st1_text']; ?>" autocomplete="off">
                            </div>

                            <div class="col">
                                <select name="zone_id" id="Server" class="form-control">
                                    <option value="<?= $games['st2_text']; ?>"><?= $games['st2_text']; ?></option>
                                    <?php
                                                $options = explode(',', $games['st2_data']);
                                                foreach ($options as $option) {
                                                    $parts = explode('///', $option);
                                                    $value = trim($parts[1]);
                                                    $label = trim($parts[0]);
                                                    echo "<option value=\"$value\">$label</option>";
                                                }
                                                ?>
                                </select>
                            </div>
                            <?php else: ?>
                            <div class="col">
                                <input type="<?= $games['st1_type']; ?>" name="user_id" class="form-control"
                                    placeholder="<?= $games['st1_text']; ?>" autocomplete="off">
                            </div>

                            <div class="col">
                                <input type="<?= $games['st2_type']; ?>" name="zone_id" class="form-control"
                                    placeholder="<?= $games['st2_text']; ?>" autocomplete="off">
                            </div>
                            <?php endif ?>
                            <p class="col-12 mt-2" style="font-size: 10px">
                                <?= $games['st_desc']; ?>
                            </p>

                            <?php endif ?>
                        </div>
                        <?php else: ?>
                        <?= $this->include('Target/' . $games['target']); ?>
                        <?php endif ?>
                        <?php if ($games['target'] == 'joki'): ?>
                        <input type="text" name="wa" placeholder="Masukan No. Whatsapp" class="form-control mt-2" value="" required>
                        <?php endif ?>
                        </div>
                    </div>
                </div>


                <div class="pb-3">
                    <div class="section">
                        <div class="body-games shadow-form">
                            <h5>Pilih Nominal Layanan</h5>
                            <?php $no = 1;
                            foreach ($category as $cat): ?>
                            <div class="row px-2 mt-4 <?= count($category) == 0 ? 'd-none' : ''; ?>">
                                <div class="col-12">
                                </div>
                                <div class="col-md-12 col-12">
                                    <div>
                                        <h5><?= $cat['category']; ?></h5><br>
                                    </div>
                                </div>

                            </div>

                            <?php $no = 1;
                                foreach ($products as $key => $value): ?>
                            <div class="row pl-2 pr-2 row-category" id="product-category-<?= $key; ?>">
                                <?php foreach ($value as $loop): ?>
                                <?php if ($loop['category_id'] != $cat['id']) {
                                                continue;
                                            } ?>
                                <div class="col-6 col-lg-4" style="padding-right: 5px;padding-left: 5px;display:grid;">
                                    <input type="radio" for="product-<?= $loop['id']; ?>"
                                        id="product-<?= $loop['id']; ?>" class="radio-nominale" name="product"
                                        value="<?= $loop['id']; ?>" onchange="get_price(this.value);">
                                    <label for="product-<?= $loop['id']; ?>">
                                        <div style="text-align: center;margin-bottom:10px;margin-top:10px;">
                                            <img onerror="this.style.display='none'"
                                                src="<?= base_url(); ?>/assets/images/product/<?= $loop['image']; ?>"
                                                loading="lazy" class="icon-diamondx">
                                            <a style="font-size: 14px; color: #fff;font-weight:600;text-align: center;"
                                                for="product-<?= $loop['id']; ?>"><?= $loop['product']; ?></a><br>

                                            <?php
                                                        $price = null;
                                                        $discountPrice = null;

                                                        if ($loop['discount_price'] != 0) {
                                                            $price = $loop['price'];
                                                            $discountPrice = $loop['discount_price'];
                                                        } else {
                                                            if ($users !== false) {
                                                                switch ($users['level']) {
                                                                    case 'Silver':
                                                                        $price = $loop['price_silver'] ?? $loop['price'];
                                                                        break;
                                                                    case 'Gold':
                                                                        $price = $loop['price_gold'] ?? $loop['price'];
                                                                        break;
                                                                    case 'Member':
                                                                        $price = $loop['price_bronze'] ?? $loop['price'];
                                                                        break;
                                                                    default:
                                                                        $price = $loop['price'];
                                                                        break;
                                                                }
                                                            } else if ($price == 0 or empty($price)) {
                                                                $price = $loop['price'];
                                                            } else {
                                                                $price = $loop['price'];
                                                            }
                                                        }

                                                        ?>

                                            <a style="font-size: 12px; font-weight:500;" class="currency-idr">
                                                <?= $price; ?>
                                            </a>

                                            <?php if ($discountPrice != null): ?>
                                            <br>
                                            <p class="currency-idr-2 discount-price"><?= $discountPrice; ?></p>
                                            <?php endif; ?>
                                            <a style=" margin-bottom:10px;"></a>



                                        </div>



                                    </label>
                                </div>


                                <?php endforeach ?>
                            </div>
                            <?php $no++; endforeach ?>

                            <?php $no++; endforeach ?>

                            <div class="<?= count($category) >= 1 ? 'd-none' : ''; ?>">
                                <div class="row pt-3 pl-2 pr-2 mb-2">
                                    <?php if (count($product) == 0): ?>
                                    <div class="col-12">
                                        <div class="alert alert-warning alert-dismissible mt-2 mb-0" role="alert">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <div class="alert-icon">
                                                <i class="fa fa-exclamation-triangle"></i>
                                            </div>
                                            <div class="alert-message">
                                                <strong>Information!</strong> Produk sedang tidak tersedia.
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif ?>

                                    <?php foreach ($product as $loop): ?>
                                    <div class="col-6 col-lg-4"
                                        style="padding-right: 5px;padding-left: 5px;display:grid;">
                                        <input type="radio" for="product-<?= $loop['id']; ?>"
                                            id="product-<?= $loop['id']; ?>" class="radio-nominale" name="product"
                                            value="<?= $loop['id']; ?>" onchange="get_price(this.value);">
                                        <label for="product-<?= $loop['id']; ?>">
                                            <div style="text-align: center;margin-bottom:10px;margin-top:10px;">
                                                <img onerror="this.style.display='none'"
                                                    src="<?= base_url(); ?>/assets/images/product/<?= $loop['image']; ?>"
                                                    loading="lazy" class="icon-diamondx">
                                                <a style="font-size: 14px; color: #fff;font-weight:600; text-align: center;"
                                                    for="product-<?= $loop['id']; ?>"><?= $loop['product']; ?></a><br>
                                                <?php
                                                    $price = null;
                                                    $discountPrice = null;

                                                    if ($loop['discount_price'] != 0) {
                                                        $price = $loop['price'];
                                                        $discountPrice = $loop['discount_price'];
                                                    } else {
                                                        if ($users !== false) {
                                                            switch ($users['level']) {
                                                                case 'Silver':
                                                                    $price = $loop['price_silver'] ?? $loop['price'];
                                                                    break;
                                                                case 'Gold':
                                                                    $price = $loop['price_gold'] ?? $loop['price'];
                                                                    break;
                                                                default:
                                                                    $price = $loop['price'];
                                                                    break;
                                                            }
                                                        } else if ($price == 0) {
                                                            $price = $loop['price'];
                                                        } else {
                                                            $price = $loop['price'];
                                                        }
                                                    }

                                                    ?>

                                                <a style="font-size: 12px; font-weight:500;" class="currency-idr">
                                                    <?= $price; ?>
                                                </a>

                                                <?php if ($discountPrice != null): ?>
                                                <p class="currency-idr-2 discount-price"><?= $discountPrice; ?></p>
                                                <?php endif; ?>

                                            </div>


                                            </input>

                                        </label>
                                    </div>
                                    <?php endforeach ?>
                                </div>
                            </div>
                            <?php if ($games['slug'] == 'joki-paket-rank'): ?>
                            <style>
                            .kuantitibox {
                                visibility: hidden;
                            }
                            </style>
                            <?php endif ?>


                            <?php if ($games['target'] == 'joki'): ?>
                            <div id="kuantitibox" class="kuantitibox mt-4">
                                <h5 class="mb-2">Masukkan Jumlah (Star/Win)</h5>
                                <input type="number" class="form-control name-joki" value="1" id="jumlah_star_poin"
                                    name="joki[jumlah_star_poin]" onchange="update_total();">
                                <p style="font-size: 12px;">Minimal Order adalah 5, Jika Kurang Dari
                                    Minimal order maka
                                    uang akan hangus</p>
                            </div>


                            <?php if ($games['slug'] == 'paket-hemat-joki'): ?>
                            <style>
                            #kuantitibox {
                                visibility: hidden;
                            }
                            </style>


                            <?php endif ?>
                            <?php endif ?>

                            <?php if ($games['target'] == 'jokigendong'): ?>
                            <div id="kuantitibox2" class="kuantitibox2 mt-4 text-dark">
                                <h5 class="mb-2">Masukkan Jumlah (Star/Win)</h5>
                                <input type="number" class="form-control name-jokigendong" value="1"
                                    id="jumlah_star_poin" name="jokigendong[jumlah_star_poin]"
                                    onchange="update_total();">
                                <p style="font-size: 12px;">Minimal Order adalah 5, Jika Kurang Dari Minimal order maka
                                    uang akan hangus</p>
                            </div>

                            <?php if ($games['slug'] == 'paket-joki-gendong-rank'): ?>
                            <style>
                            #kuantitibox2 {
                                visibility: hidden !important;
                            }
                            </style>


                            <?php endif ?>
                            <?php endif ?>

                            <?php if ($games['target'] == 'videomontage'): ?>
                            <div class="kuantitibox mt-4">
                                <h5 class="mb-2">Masukkan Jumlah Menit</h5>
                                <input type="number" class="form-control name-videomontage" value="1" id="jumlah_menit"
                                    name="videomontage[jumlah_menit]" onchange="update_total();">
                            </div>
                            <?php endif ?>

                        </div>
                    </div>
                </div>





                <div class="pb-3">
                    <div class="section section-game"
                        style="border: 0px;box-shadow: none!important;background:var(--warna_2);">
                        <div class="body-games shadow-form">
                            <h5>Pilih Pembayaran</h5>
                            <?php if ($pay_balance === 'Y'): ?>
                            <div class="mt-3 mb-3" id="bsaldo">
                                <div class="accordion-button single-payment">
                                    <input class="radio-nominal" type="radio" name="method" value="balance"
                                        id="method-balance">
                                    <label for="method-balance" class="mb-0">
                                        <div class="row">
                                            <div class="col-3 d-flex justify-content-center align-items-center">
                                                <div class="pb-0">
                                                    <img src="<?= base_url(); ?>/assets/images/new-assets/GoCard.jpeg" width="50%" class="mx-auto d-block bhahah"></img>
                                                </div>
                                            </div>
                                            <div class="col-4 d-flex align-items-center">
                                                <div>
                                                    <div> GoCard</div>
                                                    <div style="color: var(--warna_4);">Saldo: Rp
                                                        <?= number_format($users['balance'], 0, ',', '.'); ?></div>
                                                </div>
                                            </div>
                                            <div class="col-5">
                                                <div class="mt-2 text-right">
                                                    <p class="mb-2 harga-price-method" id="price-method-balance"></p>
                                                </div>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                            <?php endif ?>
                            <div class="mb-3" id="bbank">
                                <?php
                                $count = 0;
                                foreach ($accordion_data as $category => $methods):
                                    $count++;
                                    ?>
                                <?php if ($category === 'QRIS'): ?>
                                <?php foreach ($methods as $method): ?>
                                <div class="mt-3 mb-3" id="bbank">
                                    <div class="accordion-button single-payment">
                                        <input class="radio-nominal" type="radio" name="method"
                                            value="<?= $method['id']; ?>" id="method-<?= $method['id']; ?>">
                                        <label for="method-<?= $method['id']; ?>"
                                            id="method-<?= $method['id']; ?>-label" class="mb-0">
                                            <div class="row">
                                                <div class="col-3 d-flex justify-content-center align-items-center">
                                                    <div class="pb-0">
                                                        <img src="<?= base_url(); ?>/assets/images/new-assets/qris-white.svg" width="100%">
                                                    </div>
                                                </div>

                                                <div class="col-4 d-flex align-items-center">
                                                    <div> <?= $category; ?></div>
                                                </div>
                                                <div class="col-5">
                                                    <div class="mt-2 text-right">
                                                        <p class="mb-2 harga-price-method"
                                                            id="price-method-<?= $method['id']; ?>"></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                                <?php else:?>
                                <div class="accordion-item mb-3 boks">
                                    <h2 class="accordion-header mb-0" id="heading-bank">
                                        <button class="accordion-button collapsed text-white " type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapse<?= $count; ?>"
                                            aria-expanded="false" aria-controls="collapse<?= $count; ?>"
                                            aria-labelledby="<?= $count; ?>" data-bs-parent="#bbank">
                                            <div class="left">
                                                <?php if ($category == 'Bank Transfer'): ?>
                                                <img src="<?= base_url(); ?>/assets/images/new-assets/mdi_bank.svg"
                                                    class="mr-3"></img>&nbsp<?= $category; ?>
                                                <?php elseif ($category == 'Virtual Account'): ?>
                                                <img src="<?= base_url(); ?>/assets/images/new-assets/vabank-white.svg"
                                                    class="mr-3"></img>&nbsp<?= $category; ?>
                                                <?php elseif ($category == 'E-Wallet'): ?>
                                                <img src="<?= base_url(); ?>/assets/images/new-assets/e-wallet.svg"
                                                    class="mr-3"></img>&nbsp<?= $category; ?>
                                                <?php elseif ($category == 'Convenience Store'): ?>
                                                <img src="<?= base_url(); ?>/assets/images/new-assets/store.svg"
                                                    class="mr-3"></img>&nbsp<?= $category; ?>
                                                <?php elseif ($category == 'Pulsa'): ?>
                                                <img src="<?= base_url(); ?>/assets/images/new-assets/pulsa.svg"
                                                    class="mr-3"></img>&nbsp<?= $category; ?>
                                                <?php endif ?>
                                            </div>
                                            <iconify-icon class="pl-1" inline icon="subway:down-2"
                                                style="margin-left: auto;"></iconify-icon>
                                        </button>
                                    </h2>
                                    <div id="collapse<?= $count; ?>" class="accordion-collapse collapse"
                                        aria-labelledby="heading<?= $count; ?>" data-bs-parent="#bbank">
                                        <div class="accordion-body">

                                            <?php foreach ($methods as $method): ?>
                                            <div class="method-accordion mb-0" id="bbank">
                                                <button class="accordion-button">
                                                    <input class="radio-nominal" type="radio" name="method"
                                                        value="<?= $method['id']; ?>" id="method-<?= $method['id']; ?>">
                                                    <label for="method-<?= $method['id']; ?>"
                                                        id="method-<?= $method['id']; ?>-label" class="mb-0">
                                                        <div class="row">
                                                            <div class="col-1 d-flex align-items-center pr-4">
                                                                <div class="rounded-radio mr-2 pb-0">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                        height="12" viewBox="0 0 12 12" fill="none">
                                                                        <circle cx="6" cy="6" r="5.77941" stroke="white"
                                                                            stroke-width="0.441176" />
                                                                    </svg>
                                                                </div>
                                                            </div>
                                                            <div class="col-3 pl-0 d-flex align-items-center">
                                                                <div class="mr-2 pb-0">
                                                                    <img src="<?= base_url(); ?>/assets/images/method/<?= $method['image']; ?>"
                                                                        class="mr-3" width=" 60px"></img>
                                                                </div>
                                                            </div>

                                                            <div class="col-3 d-flex align-items-center px-0">
                                                                <div class="text-method"> <?= $method['method']; ?>
                                                                </div>
                                                            </div>
                                                            <div
                                                                class="col-4 p-0 d-flex align-items-center justify-content-end">
                                                                <div class="mr-2 mt-2">
                                                                    <p class="mb-2 harga-price-method"
                                                                        id="price-method-<?= $method['id']; ?>"></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </label>
                                                </button>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            <div class="d-flex gap-2 pt-5">
                                <h5>Kode Voucher</h5><i style="opacity:0.5"> (Opsional)</i>
                            </div>
                            <div class="form-group pt-3">
                                <input type="text" name="voucher" placeholder="Masukkan kode voucher"
                                    class="form-control w-80">
                                <div class="d-flex justify-content-end">
                                    <button class="btn btn-primary mt-3 d-flex align-items-center gap-2" type=" button"
                                        onclick="cek_voucher();"><svg xmlns="http://www.w3.org/2000/svg" width="16"
                                            height="12" viewBox="0 0 16 12" fill="none">
                                            <path
                                                d="M2 0C1.60218 0 1.22064 0.158035 0.93934 0.43934C0.658035 0.720644 0.5 1.10218 0.5 1.5V4.5C0.897825 4.5 1.27936 4.65804 1.56066 4.93934C1.84196 5.22064 2 5.60218 2 6C2 6.39782 1.84196 6.77936 1.56066 7.06066C1.27936 7.34196 0.897825 7.5 0.5 7.5V10.5C0.5 10.8978 0.658035 11.2794 0.93934 11.5607C1.22064 11.842 1.60218 12 2 12H14C14.3978 12 14.7794 11.842 15.0607 11.5607C15.342 11.2794 15.5 10.8978 15.5 10.5V7.5C15.1022 7.5 14.7206 7.34196 14.4393 7.06066C14.158 6.77936 14 6.39782 14 6C14 5.60218 14.158 5.22064 14.4393 4.93934C14.7206 4.65804 15.1022 4.5 15.5 4.5V1.5C15.5 1.10218 15.342 0.720644 15.0607 0.43934C14.7794 0.158035 14.3978 0 14 0H2ZM10.625 2.25L11.75 3.375L5.375 9.75L4.25 8.625L10.625 2.25ZM5.6075 2.28C6.3425 2.28 6.935 2.8725 6.935 3.6075C6.935 3.95958 6.79514 4.29723 6.54618 4.54618C6.29723 4.79514 5.95958 4.935 5.6075 4.935C4.8725 4.935 4.28 4.3425 4.28 3.6075C4.28 3.25543 4.41986 2.91777 4.66882 2.66882C4.91777 2.41986 5.25543 2.28 5.6075 2.28ZM10.3925 7.065C11.1275 7.065 11.72 7.6575 11.72 8.3925C11.72 8.74457 11.5801 9.08223 11.3312 9.33118C11.0822 9.58014 10.7446 9.72 10.3925 9.72C9.6575 9.72 9.065 9.1275 9.065 8.3925C9.065 8.04042 9.20486 7.70277 9.45382 7.45382C9.70277 7.20486 10.0404 7.065 10.3925 7.065Z"
                                                fill="#333333" />
                                        </svg> Gunakan Voucher</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <div class="pb-3">
                    <div class="section">
                        <div class="body-games shadow-form">
                            <div class="d-flex gap-2">
                                <h5>Bukti Transaksi</h5><i style="opacity:0.5"> (Opsional)</i>
                            </div>
                            <div class="form-group pt-3">
                                <p style="font-size: 12px;">Opsional : Masukkan email kalian jika ingin mendapatkan bukti transaksi & promo menarik lainnya</p>

                                <input type="email" name="email_order" placeholder="Alamat E-Mail" class="form-control"
                                    value="">

                                <small class="mt-2 d-block mb-3 white">
                                    Dengan membeli otomatis saya menyutujui <a
                                        href="<?= base_url(); ?>/syarat-ketentuan/" target="_blank" style="color: var(--warna_5);">Ketentuan
                                        Layanan
                                        <?= $web['name']; ?>
                                    </a>.
                                </small>
                                <div class="g-recaptcha mt-3 mb-3" data-sitekey="<?= $sitekey ?>" id="recaptcha" hidden></div>

                            </div>
                        </div>
                    </div>
                </div>


                <div class="modal fade" id="modal-detail">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content text-white animated bounceIn" style="background: var(--warna_2);">
                            <div class="card-header border-bottom-0">
                                <h5 class="text-white">Detail Pembelian</h5>
                            </div>
                            <div class="modal-body pt-0">

                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade hanz-modal" id="modal-loading" style="">
                    <div class="modal-dialog modal-dialog-centered text-center hanzmodal-dialog"
                        style="max-width: 155px;">
                        <img src="https://usagif.com/wp-content/uploads/loading-11.gif.webp" alt="" width="155"
                            style="border-radius: 40px;">
                    </div>
                </div>

                <input type="hidden" id="product_id" value="0">
            </div>
        </div>
    </div>
</div>
<?php $this->endSection(); ?>

<?php $this->section('js'); ?>

                        <script>
                // Menambahkan event listener untuk menyimpan nilai input pada setiap perubahan
                document.querySelectorAll('input[name="user_id"], input[name="zone_id"], input[name="email_order"]').forEach(function(input) {
                  input.addEventListener('input', function() {
                    var gameName = '<?= $games['games']; ?>'; // Ambil nama game dari halaman yang sedang dimuat
                    localStorage.setItem(gameName + '-' + this.name, this.value);
                  });
                });
                
                // Memuat nilai terakhir yang disimpan pada saat halaman dimuat
                window.addEventListener('load', function() {
                  var gameName = '<?= $games['games']; ?>'; // Ambil nama game dari halaman yang sedang dimuat
                  document.querySelectorAll('input[name="user_id"], input[name="zone_id"], input[name="email_order"]').forEach(function(input) {
                    var savedValue = localStorage.getItem(gameName + '-' + input.name);
                    if (savedValue) {
                      input.value = savedValue;
                    }
                  });
                });
            </script>
<script type="text/javascript">
$(document).ready(function() {
    // Set the initial price
    var initialPrice = $('input[name="product"]:checked').siblings('label').find('.currency-idr').text();
    $('#nominal-text').text(initialPrice);

    // Handle product radio button change event
    $('input[name="product"]').on('change', function() {
        // Check if the radio button is checked
        if ($(this).is(':checked')) {
            // Get the price from the selected product
            var price = $(this).siblings('label').find('.currency-idr').text();
            // Set the price to the nominal-text element if method radio button is not checked
            if (!$('input[name="method"]').is(':checked')) {
                $('#nominal-text').text(price);
            }
        }
    });

    // Handle method radio button change event
    $('input[name="method"]').on('change', function() {
        // Check if the radio button is checked
        if ($(this).is(':checked')) {
            // Get the price from the selected method
            var price = $(this).siblings('label').find('.harga-price-method').text();
            // Set the price to the nominal-text element
            $('#nominal-text').text(price);
        }
    });

    // Observe changes to harga-price-method elements using MutationObserver
    var hargaPriceMethodObserver = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            // Get the changed price element
            var changedPriceElement = $(mutation.target);
            // Check if the changed price element is part of the selected method radio button
            if (changedPriceElement.parents('label').siblings('input[name="method"]').is(
                    ':checked')) {
                // Get the new price from the changed price element
                var newPrice = changedPriceElement.text();
                // Set the price to the nominal-text element
                $('#nominal-text').text(newPrice);
            }
        });
    });

    // Observe all harga-price-method elements for changes
    $('.harga-price-method').each(function() {
        hargaPriceMethodObserver.observe(this, {
            subtree: true,
            characterData: true,
            childList: true
        });
    });
});

// Helper function to parse number from string
function parseNumber(str) {
    return parseInt(str.replace(/[^\d]/g, ''));
}
</script>

<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  
  fbq('init', '{938473200580408}');
  fbq('init', '{9532506813488688}');
  fbq('init', '{584979920420062}');
  fbq('track', 'ViewContent');
</script>
<noscript>
  <img height="1" width="1" style="display:none" 
       src="https://www.facebook.com/tr?id={938473200580408}&ev=ViewContent&noscript=1"/>
  <img height="1" width="1" style="display:none" 
       src="https://www.facebook.com/tr?id={9532506813488688}&ev=ViewContent&noscript=1"/>
       <img height="1" width="1" style="display:none" 
       src="https://www.facebook.com/tr?id={584979920420062}&ev=ViewContent&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->


<script>
// Get the value of the diamonds parameter from the URL
const urlParams = new URLSearchParams(window.location.search);
const diamonds = urlParams.get('diamonds');

// If the diamonds parameter is present, find the corresponding radio button and check it
if (diamonds) {
    const radio = document.querySelector(`input[type=radio][value="${diamonds}"]`);
    if (radio) {
        radio.checked = true;
        // Scroll to the selected product
        const productDiv = radio.closest('.col-sm-4');
        if (productDiv) {
            const rect = productDiv.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            if (rect.bottom > windowHeight) {
                // The bottom of the product div is below the bottom of the viewport,
                // so adjust the scroll position to align the bottom of the div with
                // the bottom of the viewport
                window.scrollTo(0, window.scrollY + rect.bottom - windowHeight);
            } else if (rect.top < 0) {
                // The top of the product div is above the top of the viewport,
                // so adjust the scroll position to align the top of the div with
                // the top of the viewport
                window.scrollTo(0, window.scrollY + rect.top);
            }
        }
    }
}
</script>

<script>
<!-- 
var enableDisable = function() {
    var UTC_hours = new Date().getUTCHours(); //Don't add 1 here       
    var day = new Date().getUTCDay(); //Use UTC here also

    if (day != 1 && UTC_hours >= 15 && UTC_hours < 20) {
        $('#price-method-3').replaceWith("Bank sedang offline, kembali online pukul 03.00 WIB");

        $('#method-3-label').addClass('cutoffbank');



    } else {
        $('#method-3-label').removeClass('cutoffbank');
    }
};

setInterval(enableDisable, 1000 * 60);
enableDisable();
// 
-->
</script>
<script>
$('.currency-idr').each(function() {
    var monetary_value = $(this).text();
    var i = new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
    }).format(monetary_value);
    $(this).text(i);
});

$('.currency-idr-2').each(function() {
    var monetary_value = $(this).text();
    var i = new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
    }).format(monetary_value);
    $(this).text(i);
});

function parseNumber(strg) {
    var strg = strg || "";
    var decimal = '.';
    strg = strg.replace(/[^0-9$.,]/g, '');
    if (strg.indexOf(',') > strg.indexOf('.')) decimal = ',';
    if ((strg.match(new RegExp("\\" + decimal, "g")) || []).length > 1) decimal = "";
    if (decimal !== "" && (strg.length - strg.indexOf(decimal) - 1 == 3) && strg.indexOf("0" + decimal) !== 0) decimal =
        "";
    strg = strg.replace(new RegExp("[^0-9$" + decimal + "]", "g"), "");
    strg = strg.replace(',', '.');
    return parseFloat(strg);
}



function get_price(id = null) {

    <?php if ($games['target'] == 'joki'): ?>
    var jumlah = $("#jumlah_star_poin").val();
    <?php elseif ($games['target'] == 'videomontage'): ?>
    var jumlah = $("#jumlah_menit").val();
    <?php else: ?>
    var jumlah = 1;
    <?php endif; ?>


    $("#product_id").val(id);

    $.ajax({
        url: '<?= base_url(); ?>/games/order/get-price/' + id,
        type: 'POST',
        data: 'jumlah=' + jumlah,
        dataType: 'JSON',
        success: function(result) {
            for (let price in result) {
                $("#price-method-" + result[price].method).text('Rp ' + result[price].price);



            }

        }
    });
}

function update_total() {
    get_price($("#product_id").val());
}

function process_order() {

    <?php if ($games['target'] == 'joki'): ?>
    var user_id = $('.name-joki').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'skinml'): ?>
    var user_id = $('.name-skinml').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'videomontage'): ?>
    var user_id = $('.name-videomontage').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'topuplogin'): ?>
    var user_id = $('.name-topuplogin').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-ragnarox'): ?>
    var user_id = $('.name-lg-ragnarox').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-dragonhunter'): ?>
    var user_id = $('.name-lg-dragonhunter').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-fourgods'): ?>
    var user_id = $('.name-lg-fourgods').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-genshinimpact'): ?>
    var user_id = $('.name-lg-genshinimpact').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-ninokuni'): ?>
    var user_id = $('.name-lg-ninokuni').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-neverafter'): ?>
    var user_id = $('.name-lg-neverafter').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-clashofclans'): ?>
    var user_id = $('.name-lg-clashofclans').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginapex'): ?>
    var user_id = $('.name-loginapex').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginefootball'): ?>
    var user_id = $('.name-loginefootball').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginff'): ?>
    var user_id = $('.name-loginff').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'logingenshin'): ?>
    var user_id = $('.name-logingenshin').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginml'): ?>
    var user_id = $('.name-loginml').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginninokuni'): ?>
    var user_id = $('.name-loginninokuni').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginpokemon'): ?>
    var user_id = $('.name-loginpokemon').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginraven'): ?>
    var user_id = $('.name-loginraven').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'logintiktok'): ?>
    var user_id = $('.name-logintiktok').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'logintower'): ?>
    var user_id = $('.name-logintower').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginwildrift'): ?>
    var user_id = $('.name-loginwildrift').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'tournament'): ?>
    var user_id = $('.name-tournament').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php else: ?>
    var user_id = $("input[name=user_id]").val();
    var zone_id = $("input[name=zone_id]").val();
    <?php endif; ?>

    if (zone_id == undefined) {
        zone_id = $("select[name=zone_id]").val();
    }

    if (user_id == undefined) {
        user_id = $("select[name=user_id]").val();
    }

    var product = $("input[name=product]:checked").val();
    var method = $("input[name=method]:checked").val();
    var voucher = $("input[name=voucher]").val();
    var email_order = $("input[name=email_order]").val();
    var recaptchaResponse = grecaptcha.getResponse();
    var wa = $("input[name=wa]").val();
    
    if (wa == undefined) {
        wa = '';
    }

    <?php if ($games['target'] == 'joki'): ?>
    var jumlah = $("#jumlah_star_poin").val();
    <?php elseif ($games['target'] == 'videomontage'): ?>
    var jumlah = $("#jumlah_menit").val();
    <?php else: ?>
    var jumlah = 1;
    <?php endif; ?>

    if (user_id == '' || user_id == ' ') {
        Swal.fire({
            title: 'Gagal',
            text: 'ID Player harus diisi',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "rgba(189, 252, 80, 1)",
            
            
        });
    } else if (zone_id == '' || zone_id == ' ') {
        Swal.fire({
            title: 'Gagal',
            text: 'ID Player harus diisi',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "rgba(189, 252, 80, 1)",
            
            
        });
    } else if (product == '' || product == ' ') {
        Swal.fire({
            title: 'Gagal',
            text: 'Nominal produk harus dipilih',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "rgba(189, 252, 80, 1)",
            
            
        });
    } else if (method == '' || method == ' ') {
        Swal.fire({
            title: 'Gagal',
            text: 'Pilih metode pembayaran',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "rgba(189, 252, 80, 1)",
            
            
        });
    } else {
        $.ajax({
            url: '<?= base_url(); ?>/games/order/get-detail/' + product,
            data: 'user_id=' + user_id + '&zone_id=' + zone_id + '&method=' + method + '&email_order=' + email_order + '&wa=' + wa + 
                '&voucher=' + voucher + '&target=<?= $games['target'] ?>&captcha=' + recaptchaResponse + '&jumlah=' + jumlah ,
            type: 'POST',
            dataType: 'JSON',
            beforeSend: function() {
                $('#modal-loading').modal('show');
            },
            success: function(result) {

                $('#modal-loading').modal('hide');

                if (result.status == true) {
                    $("#modal-detail div div .modal-body").html(result.msg);

                    $("#modal-detail").modal('show');
                } else {
                    Swal.fire({
                        title: 'Gagal',
                        text: result.msg,
                        icon: 'error',
                        confirmButtonText: 'OKE',
                        confirmButtonColor: "rgba(189, 252, 80, 1)",
                        
                        
                    });
                }
            }
        });

        $('#modal-detail').on('shown.bs.modal', function() {
            $("#modal-loading").modal('hide');
        });
    }
}

function nonaktif_button() {
    document.getElementById('1xorder').innerHTML = 'Menunggu...';
    document.getElementById('1xorder').style.pointerEvents = 'none';
}

function cek_voucher() {

    var product = $("input[name=product]:checked").val();
    var voucher = $("input[name=voucher]").val();

    <?php if ($games['target'] == 'joki'): ?>
    var jumlah = $("#jumlah_star_poin").val();
    <?php elseif ($games['target'] == 'videomontage'): ?>
    var jumlah = $("#jumlah_menit").val();
    <?php else: ?>
    var jumlah = 1;
    <?php endif; ?>


    if (voucher == '' || voucher == ' ') {
        Swal.fire({
            title: 'Gagal',
            text: 'Kode voucher harus diisi',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "rgba(189, 252, 80, 1)",
            
            
        });
    } else if (product == '' || product == ' ') {
        Swal.fire({
            title: 'Gagal',
            text: 'Nominal produk harus dipilih',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "rgba(189, 252, 80, 1)",
            
            
        });
    } else if (product == undefined) {
        Swal.fire({
            title: 'Gagal',
            text: 'Nominal produk harus dipilih',
            icon: 'error',
            confirmButtonText: 'OKE',
            confirmButtonColor: "rgba(189, 252, 80, 1)",
            
            
        });
    } else {
        $.ajax({
            url: '<?= base_url(); ?>/games/voucher/' + product,
            data: 'voucher=' + voucher + '&jumlah=' + jumlah,
            type: 'POST',
            dataType: 'JSON',
            success: function(result) {
                if (result.success) {
                    Swal.fire({
                        title: 'Berhasil',
                        text: result.msg,
                        icon: 'success',
                        confirmButtonText: 'OKE',
                        confirmButtonColor: "rgba(189, 252, 80, 1)",
                        
                        
                    });
                } else {
                    Swal.fire({
                        title: 'Gagal',
                        text: result.msg,
                        icon: 'error',
                        confirmButtonText: 'OKE',
                        confirmButtonColor: "rgba(189, 252, 80, 1)",
                        
                        
                    });
                }
            }
        });
    }
}
</script>

<script type="text/javascript" defer="defer">
<!-- 
var enableDisable = function() {
    var UTC_hours = new Date().getUTCHours(); //Don't add 1 here       
    var day = new Date().getUTCDay(); //Use UTC here also

    if (day != 1 && UTC_hours >= 14 && UTC_hours < 20) {
        document.getElementById('bankbca-on').style.display = 'none';
        document.getElementById('bankbca-off').style.display = 'block';
    } else {
        document.getElementById('bankbca-on').style.display = 'block';
        document.getElementById('bankbca-off').style.display = 'none';
    }
};

setInterval(enableDisable, 1000 * 60);
enableDisable();
// 
-->
</script>
<?php $this->endSection(); ?>