			<?php $this->extend('template'); ?>
			
			<?php $this->section('css'); ?>

			<style>
				.section {
					position: relative;
					max-width: 550px;
					height: auto;
					margin: auto;
				}

				.pointgo {
					position: absolute;
					top: -10px;
					left: -10px;
					width: 45px;
					height: 45px;
					background: var(--warna_3);
					border-radius: 13px 0px 13px 0px;
				}

				.normal {
                    text-transform: none;
                }



			</style>

			<?php $this->endSection(); ?>
			
			<?php $this->section('content'); ?>
			<div class="clearfix pt-5"></div>
			<div class="pt-5 pb-5">
				<div class="container-fluid">
					<div class="row justify-content-center">
						<div class="col-lg-9">
							<div class="pt-3 pb-4">
								<span class="strip-primary" hidden></span>
							</div>
							<div class="section" >
								<div class="card-body">
									<form role="form" class="mb-3 mt-2" action="" method="POST">
									<img class="pointgo" src="<?= base_url(); ?>/assets/images/pointgo.svg">
										<h5 class="text-center pb-3">Cek Status Pesanan</h5>
										<p class="text-white" style="font-weight: 700;">No. Transaksi</p>
										<?= alert(); ?>
										<div class="form-group mb-3">
											<input type="text" name="order_id" placeholder="Masukkan No.Transaksi" class="form-control" required autocomplete="off">
										</div>
										<div class="text-right">
											<button type="submit" name="submit" value="submit" class="btn btn-primary normal">Cek Pesanan</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<?php $this->endSection(); ?>
			
			<?php $this->section('js'); ?>
			<?php $this->endSection(); ?>