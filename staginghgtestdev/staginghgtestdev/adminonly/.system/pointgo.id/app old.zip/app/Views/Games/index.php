<?php $this->extend('template'); ?>

<?php $this->section('css'); ?>

<style>
.container {
    max-width: 1400px !important;
}

.contentgame {
    color: #000;
    font-size: 12px;
    background: #d9d9d99c;
    padding: 1.5rem;
    border-radius: 9px;
}

.contentgame p {
    color: #000 !important;
}

h5.pb-2,
h5.mb-2 {
    color: #fff
}

p {
    color: #fff
}

.h3,
h3 {
    font-size: 25px;
}

.h5,
h5 {
    color: #000;
}

.cutoffbank {
    filter: grayscale(1);
    pointer-events: none;

}

@media (max-width: 900px) {
    .hanz-modal {
        margin-left: 30% !important;
    }
}

.cutoffbank p {
    font-size: 10px !important;
    line-height: 13px;
    margin-bottom: 0.5rem !important;
    margin-right: 1rem !important;
    margin-left: 1rem !important;
    font-weight: 600;
}

button.accordion-button {
    outline: none !important;
    border: none !important;
    box-shadow: none !important;
    background-color: #161616 !important;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
}

.text-end {
    text-align: right !important;
}

.accordion {
    --bs-accordion-color: #000;
    --bs-accordion-bg: #fff;
    --bs-accordion-transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, border-radius 0.15s ease;
    --bs-accordion-border-color: var(--bs-border-color);
    --bs-accordion-border-width: 1px;
    --bs-accordion-border-radius: 0.375rem;
    --bs-accordion-inner-border-radius: calc(0.375rem - 1px);
    --bs-accordion-btn-padding-x: 1.25rem;
    --bs-accordion-btn-padding-y: 1rem;
    --bs-accordion-btn-color: var(--bs-body-color);
    --bs-accordion-btn-bg: var(--bs-accordion-bg);
    --bs-accordion-btn-icon: url(data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='var%28--bs-body-color%29'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e);
    --bs-accordion-btn-icon-width: 1.25rem;
    --bs-accordion-btn-icon-transform: rotate(-180deg);
    --bs-accordion-btn-icon-transition: transform 0.2s ease-in-out;
    --bs-accordion-btn-active-icon: url(data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%230c63e4'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e);
    --bs-accordion-btn-focus-border-color: #86b7fe;
    --bs-accordion-btn-focus-box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
    --bs-accordion-body-padding-x: 1.25rem;
    --bs-accordion-body-padding-y: 1rem;
    --bs-accordion-active-color: #0c63e4;
    --bs-accordion-active-bg: #e7f1ff;
}

.accordion-button::after {
    flex-shrink: 0;
    width: var(--bs-accordion-btn-icon-width);
    height: var(--bs-accordion-btn-icon-width);
    margin-left: auto;
    content: "";
    background-image: var(--bs-accordion-btn-icon);
    background-repeat: no-repeat;
    background-size: var(--bs-accordion-btn-icon-width);
    transition: var(--bs-accordion-btn-icon-transition);
}

.accordion-body {
    padding: var(--bs-accordion-body-padding-y) var(--bs-accordion-body-padding-x);
    background: #ffffff;
}

.accordion-button {
    box-shadow: none !important;
    position: relative;
    display: flex;
    align-items: center;
    width: 100%;
    padding: var(--bs-accordion-btn-padding-y) var(--bs-accordion-btn-padding-x);
    font-size: 1rem;
    color: var(--bs-accordion-btn-color);
    text-align: left;
    background-color: var(--bs-accordion-btn-bg);
    border: 0;
    border-radius: 0;
    overflow-anchor: none;
    transition: var(--bs-accordion-transition);
}

.accordion-button.collapsed::after {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23fff'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
}

.accordion-button:not(.collapsed)::after {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23fff'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
}

.boks {
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    border-radius: 6px;
}

.col-sm-4,
.col-6 {
    padding-right: 8px;
    padding-left: 8px;
}

.circle-primary {
    border: 4px solid #fff;
    background-color: #141414;
    height: 41px;
    width: 40px;
}

.form-section__number[data-v-58e483f4] {
    border: 4px solid #fff;
    color: #fff;
    background-color: #141414;
    border-radius: 50%;
    margin: 0;
    position: absolute;
    font-family: NotoSans-Bold, sans-serif;
    font-size: 1.25rem;
    line-height: 36px;
    width: 46px;
    height: 46px;
    text-align: center;
    -webkit-font-smoothing: subpixel-antialiased !important;
    -moz-osx-font-smoothing: grayscale !important;
    margin: -30px 0 0;
}

.mb-1,
.my-1 {
    margin-bottom: 0.75rem !important;
}

.border-top {
    border-top: 1px solid #ffffff00 !important;
}

.border-top:checked+label {
    border-top: 1px solid #141414 !important;
}

@media (min-width: 577px) {
    .col-sm-3 {
        flex: 0 0 37%;
        max-width: 37%;
    }

    .col-sm-9 {
        flex: 0 0 63%;
        max-width: 63%;
    }

    .col-lg-12 {
        max-width: 20%;
    }
}

@media (max-width: 576px) {
    .col-sm-12 {
        width: 50% !important;
    }
}

.discount-price {
    font-size: 10px;
    color: red;
    font-weight: 500;
    font-style: italic;
    text-decoration: line-through
}

.icon-diamondx {
    height: 4.6rem;
}
</style>

<?php $this->endSection(); ?>

<?php $this->section('content'); ?>
<div class="clearfix pt-5"></div>
<div class="pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="section shadow-form" style="margin-bottom:20px;">
                    <div class="body-games shadow-form">
                        <div class="text-center pt-3 pb-2">
                            <img src="<?= base_url(); ?>/assets/images/games/<?= $games['image']; ?>" class="mb-3" style="display: block; margin: 0 auto; border-radius: 10px !important;" width="120px" height="120px">
                            <h5 style="color: #000;"><?= $games['games']; ?></h5>
                        </div>
                        <div class="pb-3 contentgame">
                            <?= $games['content']; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-9">

                <?= alert(); ?>

                <div class="pb-3 " id="">
                    <div class="section">
                        <div class="body-games shadow-form">
                            <div>
                                <span data-v-58e483f4="" class="form-section__number">1</span>
                            </div>
                            <h5 id="judulgame" style="margin-left: 55px; margin-top: 5px;color:#000;">Input Data Game</h5>

                            <p style="color:#000 !important;"><?= $this->include('Target/' . $games['target']); ?> </p>
                        </div>
                    </div>
                </div>


                <div class="pb-3">
                    <div class="section">
                        <div class="body-games shadow-form">
                            <div>
                                <span data-v-58e483f4="" class="form-section__number">2</span>
                            </div>
                            <h5 style="margin-left: 55px; margin-top: 5px;color:#000;">Pilih Nominal Layanan</h5>
                            <?php $no = 1;
                            foreach ($category as $cat): ?>
                            <div class="row px-2 mt-4 <?= count($category) == 0 ? 'd-none' : ''; ?>">
                                <div class="col-12">
                                </div>
                                <div class="col-md-12 col-12">
                                    <div>
                                        <h5><?= $cat['category']; ?></h5><br>
                                    </div>
                                </div>

                            </div>

                            <?php $no = 1;
                                foreach ($products as $key => $value): ?>
                            <div class="row pl-2 pr-2 row-category" id="product-category-<?= $key; ?>">
                                <?php foreach ($value as $loop): ?>
                                <?php if ($loop['category_id'] != $cat['id']) {
                                                continue;
                                            } ?>
                                <div class="col-sm-12 col-lg-12" style="padding-right: 5px;padding-left: 5px;display:grid;">
                                    <input type="radio" for="product-<?= $loop['id']; ?>" id="product-<?= $loop['id']; ?>" class="radio-nominale" name="product" value="<?= $loop['id']; ?>" onchange="get_price(this.value);">
                                    <label for="product-<?= $loop['id']; ?>" style="display: flex;justify-content: center;flex-direction: column;">
                                        <div style="text-align: center;margin-bottom:10px;margin-top:10px;">
                                            <img onerror="this.style.display='none'" src="<?= base_url(); ?>/assets/images/product/<?= $loop['image']; ?>" loading="lazy" class="icon-diamondx">
                                            <label style="font-size: 14px; color: #513f55;font-weight:600;text-align: center;" for="product-<?= $loop['id']; ?>"><?= $loop['product']; ?></label>

                                            <?php
                                                        $price = null;
                                                        $discountPrice = null;

                                                        if ($loop['discount_price'] != 0) {
                                                            $price = $loop['price'];
                                                            $discountPrice = $loop['discount_price'];
                                                        } else {
                                                            if ($users !== false) {
                                                                switch ($users['level']) {
                                                                    case 'Silver':
                                                                        $price = $loop['price_silver'] ?? $loop['price'];
                                                                        break;
                                                                    case 'Gold':
                                                                        $price = $loop['price_gold'] ?? $loop['price'];
                                                                        break;
                                                                    case 'Member':
                                                                        $price = $loop['price_bronze'] ?? $loop['price'];
                                                                        break;
                                                                    default:
                                                                        $price = $loop['price'];
                                                                        break;
                                                                }
                                                            } else if ($price == 0 or empty($price)) {
                                                                $price = $loop['price'];
                                                            } else {
                                                                $price = $loop['price'];
                                                            }
                                                        }

                                                        ?>

                                            <a style="font-size: 10px; font-weight:500;" class="currency-idr">
                                                <?= $price; ?>
                                            </a>

                                            <?php if ($discountPrice != null): ?>
                                            <br>
                                            <p class="currency-idr discount-price"><?= $discountPrice; ?></p>
                                            <?php endif; ?>
                                            <a style=" margin-bottom:10px;"></a>



                                        </div>



                                    </label>
                                </div>


                                <?php endforeach ?>
                            </div>
                            <?php $no++; endforeach ?>

                            <?php $no++; endforeach ?>

                            <div class="<?= count($category) >= 1 ? 'd-none' : ''; ?>">
                                <div class="row pt-3 pl-2 pr-2 mb-2">
                                    <?php if (count($product) == 0): ?>
                                    <div class="col-12">
                                        <div class="alert alert-warning alert-dismissible mt-2 mb-0" role="alert">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <div class="alert-icon">
                                                <i class="fa fa-exclamation-triangle"></i>
                                            </div>
                                            <div class="alert-message">
                                                <strong>Information!</strong> Produk sedang tidak tersedia.
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif ?>

                                    <?php foreach ($product as $loop): ?>
                                    <div class="col-sm-12 col-lg-12" style="padding-right: 5px;padding-left: 5px;display:grid;">
                                        <input type="radio" for="product-<?= $loop['id']; ?>" id="product-<?= $loop['id']; ?>" class="radio-nominale" name="product" value="<?= $loop['id']; ?>" onchange="get_price(this.value);">
                                        <label for="product-<?= $loop['id']; ?>" style="display: flex;justify-content: center;flex-direction: column;">
                                            <div style="text-align: center;margin-bottom:10px;margin-top:10px;">
                                                <img onerror="this.style.display='none'" src="<?= base_url(); ?>/assets/images/product/<?= $loop['image']; ?>" loading="lazy" class="icon-diamondx">
                                                <label style="font-size: 14px; color: #513f55;font-weight:600; text-align: center;" for="product-<?= $loop['id']; ?>"><?= $loop['product']; ?></label>
                                                <?php
                                                    $price = null;
                                                    $discountPrice = null;

                                                    if ($loop['discount_price'] != 0) {
                                                        $price = $loop['price'];
                                                        $discountPrice = $loop['discount_price'];
                                                    } else {
                                                        if ($users !== false) {
                                                            switch ($users['level']) {
                                                                case 'Silver':
                                                                    $price = $loop['price_silver'] ?? $loop['price'];
                                                                    break;
                                                                case 'Gold':
                                                                    $price = $loop['price_gold'] ?? $loop['price'];
                                                                    break;
                                                                default:
                                                                    $price = $loop['price'];
                                                                    break;
                                                            }
                                                        } else if ($price == 0) {
                                                            $price = $loop['price'];
                                                        } else {
                                                            $price = $loop['price'];
                                                        }
                                                    }

                                                    ?>

                                                <a style="font-size: 10px; font-weight:500;" class="currency-idr">
                                                    <?= $price; ?>
                                                </a>

                                                <?php if ($discountPrice != null): ?>
                                                <p class="currency-idr discount-price"><?= $discountPrice; ?></p>
                                                <?php endif; ?>

                                            </div>


                                            </input>

                                        </label>
                                    </div>
                                    <?php endforeach ?>
                                </div>
                            </div>
                            <?php if ($games['slug'] == 'joki-paket-rank'): ?>
                            <style>
                            .kuantitibox {
                                visibility: hidden;
                            }
                            </style>
                            <?php endif ?>


                            <?php if ($games['target'] == 'joki'): ?>
                            <div id="kuantitibox" class="kuantitibox mt-4 text-dark">
                                <h5 class="mb-2 text-dark">Masukkan Jumlah (Star/Win)</h5>
                                <input type="number" class="form-control name-joki" value="1" id="jumlah_star_poin" name="joki[jumlah_star_poin]" onchange="update_total();">
                                <p class="text-dark" style="font-size: 12px;">Minimal Order adalah 5, Jika Kurang Dari Minimal order maka
                                    uang akan hangus</p>
                            </div>


                            <?php if ($games['slug'] == 'paket-hemat-joki'): ?>
                            <style>
                            #kuantitibox {
                                visibility: hidden;
                            }
                            </style>


                            <?php endif ?>
                            <?php endif ?>

                            <?php if ($games['target'] == 'jokigendong'): ?>
                            <div id="kuantitibox2" class="kuantitibox2 mt-4 text-dark">
                                <h5 class="mb-2">Masukkan Jumlah (Star/Win)</h5>
                                <input type="number" class="form-control name-jokigendong" value="1" id="jumlah_star_poin" name="jokigendong[jumlah_star_poin]" onchange="update_total();">
                                <p style="font-size: 12px;">Minimal Order adalah 5, Jika Kurang Dari Minimal order maka
                                    uang akan hangus</p>
                            </div>

                            <?php if ($games['slug'] == 'paket-joki-gendong-rank'): ?>
                            <style>
                            #kuantitibox2 {
                                visibility: hidden !important;
                            }
                            </style>


                            <?php endif ?>
                            <?php endif ?>

                            <?php if ($games['target'] == 'videomontage'): ?>
                            <div class="kuantitibox mt-4">
                                <h5 class="mb-2">Masukkan Jumlah Menit</h5>
                                <input type="number" class="form-control name-videomontage" value="1" id="jumlah_menit" name="videomontage[jumlah_menit]" onchange="update_total();">
                            </div>
                            <?php endif ?>

                        </div>
                    </div>
                </div>





                <div class="pb-3">
                    <div class="section section-game" style="border: 0px;box-shadow: none!important;background:var(--warna_2);">
                        <div class="body-games shadow-form">
                            <div>
                                <span data-v-58e483f4="" class="form-section__number">3</span>
                            </div>
                            <h5 style="margin-left: 45px; margin-top: 5px;">Pilih Pembayaran</h5>
                            <?php if ($pay_balance === 'Y'): ?>
                            <div class="accordion mb-3 mt-3 boks" id="bsaldo">
                                <div class="accordion-item">
                                    <h2 class="accordion-header mb-0" id="heading-saldo" style="padding-top:10px">
                                        <button class="accordion-button collapsed text-white " style="background-color: var(--warna);height: 0;padding: 25px;" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-saldo" aria-expanded="false" aria-controls="collapse-saldo">
                                            GoCash
                                        </button>
                                    </h2>
                                    <div id="collapse-saldo" class="accordion-collapse collapse" aria-labelledby="heading-saldo" data-bs-parent="bsaldo">
                                        <div class="accordion-body border border-bottom-0">
                                            <div class="row ">
                                                <div class="col-6 ceklis">
                                                    <input class="radio-nominal" type="radio" name="method" value="balance" id="method-balance">
                                                    <label for="method-balance">
                                                        <div class="row d-block">
                                                            <div class="col-12">
                                                                <div class="ml-2 mr-2 pb-0">
                                                                    <img src="<?= base_url(); ?>/assets/images/method/newwallet.webp" class="rounded img-fluid mb-1" style="height: 50px;width:auto">
                                                                </div>
                                                            </div>
                                                            <div class="col-12 border-bottom">
                                                                <div class="ml-2 mt-2 text-left">
                                                                    <p class="mb-2" style="font-weight: 600; font-size: 14px;color:#000" id="price-method-balance"></p>
                                                                </div>
                                                            </div>
                                                            <div style="font-weight: normal;font-size: 12px;color: #000;">
                                                                <b class="d-block mb-2 pt-2 mx-4 pt-2">GoCash</b>
                                                                <b class="d-block"></b>
                                                            </div>
                                                        </div>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="bg-white p-2 border text-end border-top-0" style="border-radius: 0 0 6px 6px;">
                                        <img src="<?= base_url(); ?>/assets/images/method/newwallet.webp" alt="" height="50">
                                    </div>
                                </div>
                            </div>
                            <?php endif ?>
                            <div class="accordion mb-3 mt-3" id="bbank">
                                <?php
                                $count = 0;
                                foreach ($accordion_data as $category => $methods):
                                    $count++;
                                    ?>
                                <div class="accordion-item mb-3 mt-3 boks">
                                    <h2 class="accordion-header mb-0" id="heading-bank">
                                        <button class="accordion-button collapsed text-white " style="background-color: var(--warna);height: 0;padding: 25px;" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $count; ?>" aria-expanded="false" aria-controls="collapse<?= $count; ?>">
                                            <div class="left">
                                                <?php if ($category == 'Bank Transfer'): ?>
                                                <i class="fa fa-university"></i>&nbsp<?= $category; ?>
                                                <?php elseif ($category == 'QRIS'): ?>
                                                <i class="fa fa-barcode"></i> &nbsp<?= $category; ?>
                                                <?php elseif ($category == 'Virtual Account'): ?>
                                                <i class="fa fa-credit-card-alt"></i>&nbsp<?= $category; ?>
                                                <?php elseif ($category == 'E-Wallet'): ?>
                                                <i class="fa fa-money"></i>&nbsp<?= $category; ?>
                                                <?php elseif ($category == 'Convenience Store'): ?>
                                                <i class="fa fa-shopping-basket"></i>&nbsp<?= $category; ?>
                                                <?php elseif ($category == 'Pulsa'): ?>
                                                <i class="fa fa-phone"></i>&nbsp<?= $category; ?>
                                                <?php endif ?>
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="collapse<?= $count; ?>" class="accordion-collapse collapse" aria-labelledby="heading<?= $count; ?>" data-bs-parent="blok<?= $count; ?>">
                                        <div class="accordion-body border border-bottom-0">
                                            <div class="row">

                                                <?php foreach ($methods as $method): ?>
                                                <div class="col-6 ceklis" id="metode-<?= $method['id']; ?>">
                                                    <input class="radio-nominal" type="radio" name="method" value="<?= $method['id']; ?>" id="method-<?= $method['id']; ?>">
                                                    <label for="method-<?= $method['id']; ?>" id="method-<?= $method['id']; ?>-label">
                                                        <div class="row">
                                                            <div class="col-12">
                                                                <div class="ml-2 mr-2 pb-0">
                                                                    <img src="<?= base_url(); ?>/assets/images/method/<?= $method['image']; ?>" class="rounded img-fluid mb-1" style="height: 30px;width:auto">
                                                                </div>
                                                            </div>
                                                            <div class="col-12 border-bottom">
                                                                <div class="ml-2 mt-2 text-left">
                                                                    <p class="mb-2" style="font-weight: 600; font-size: 14px;color:#000" id="price-method-<?= $method['id']; ?>"></p>
                                                                </div>
                                                            </div>
                                                            <div style="font-weight: normal;font-size: 12px;">
                                                                <b class="d-block mb-2 pt-2 mx-4 pt-2"><?= $method['method']; ?></b>
                                                                <b class="d-block"></b>
                                                            </div>
                                                        </div>
                                                    </label>
                                                </div>
                                                <?php endforeach; ?>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="bg-white p-2 border text-end border-top-0" style="border-radius: 0 0 6px 6px;">
                                        <?php foreach ($methods as $method): ?>
                                        <img src="<?= base_url(); ?>/assets/images/method/<?= $method['image']; ?>" alt="" height="20">
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="pb-3">
                    <div class="section">
                        <div class="body-games shadow-form">
                            <div>
                                <span data-v-58e483f4="" class="form-section__number">4</span>
                            </div>
                            <h5 style="margin-left: 45px; margin-top: 5px;">Kode Voucher</h5>
                            <div class="form-group pt-3">
                                <input type="text" name="voucher" placeholder="Optional" class="form-control w-80">
                                <button class="btn btn-primary mt-3" type="button" onclick="cek_voucher();">Gunakan</button>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="pb-3">
                    <div class="section">
                        <div class="body-games shadow-form">
                            <div>
                                <span data-v-58e483f4="" class="form-section__number">5</span>
                            </div>
                            <h5 style="margin-left: 45px; margin-top: 5px;">Konfirmasi Pesanan</h5>
                            <div class="form-group pt-3">

                                <input type="text" name="wa" placeholder="Masukan No. Whatsapp" class="form-control" value="" required>

                                <small class="mt-2 d-block mb-3 white" style="color:#000">
                                    Dengan membeli otomatis saya menyutujui <a href="<?= base_url(); ?>/syarat-ketentuan/" target="_blank" class="text-warning">Ketentuan Layanan</a>.
                                </small>
                                <button type="button" class="btn btn-primary text-white" onclick="process_order();">Beli Sekarang</button>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="modal fade" id="modal-detail">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content text-white animated bounceIn" style="background: var(--warna_2);">
                            <div class="card-header border-bottom-0">
                                <h5 class="text-white">Detail Pembelian</h5>
                            </div>
                            <div class="modal-body pt-0">

                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade hanz-modal" id="modal-loading" style="">
                    <div class="modal-dialog modal-dialog-centered text-center hanzmodal-dialog" style="max-width: 155px;">
                        <img src="https://usagif.com/wp-content/uploads/loading-11.gif.webp" alt="" width="155" style="border-radius: 40px;">
                    </div>
                </div>

                <input type="hidden" id="product_id" value="0">
            </div>
        </div>
    </div>
</div>
<?php $this->endSection(); ?>

<?php $this->section('js'); ?>

   <!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  
  fbq('init', '{938473200580408}');
  fbq('init', '{9532506813488688}');
  fbq('init', '{584979920420062}');
  fbq('track', 'ViewContent');
</script>
<noscript>
  <img height="1" width="1" style="display:none" 
       src="https://www.facebook.com/tr?id={938473200580408}&ev=ViewContent&noscript=1"/>
  <img height="1" width="1" style="display:none" 
       src="https://www.facebook.com/tr?id={9532506813488688}&ev=ViewContent&noscript=1"/>
       <img height="1" width="1" style="display:none" 
       src="https://www.facebook.com/tr?id={584979920420062}&ev=ViewContent&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->


<script>
// Get the value of the diamonds parameter from the URL
const urlParams = new URLSearchParams(window.location.search);
const diamonds = urlParams.get('diamonds');

// If the diamonds parameter is present, find the corresponding radio button and check it
if (diamonds) {
    const radio = document.querySelector(`input[type=radio][value="${diamonds}"]`);
    if (radio) {
        radio.checked = true;
        // Scroll to the selected product
        const productDiv = radio.closest('.col-sm-4');
        if (productDiv) {
            const rect = productDiv.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            if (rect.bottom > windowHeight) {
                // The bottom of the product div is below the bottom of the viewport,
                // so adjust the scroll position to align the bottom of the div with
                // the bottom of the viewport
                window.scrollTo(0, window.scrollY + rect.bottom - windowHeight);
            } else if (rect.top < 0) {
                // The top of the product div is above the top of the viewport,
                // so adjust the scroll position to align the top of the div with
                // the top of the viewport
                window.scrollTo(0, window.scrollY + rect.top);
            }
        }
    }
}
</script>

<script>
<!-- 
var enableDisable = function() {
    var UTC_hours = new Date().getUTCHours(); //Don't add 1 here       
    var day = new Date().getUTCDay(); //Use UTC here also

    if (day != 1 && UTC_hours >= 15 && UTC_hours < 20) {
        $('#price-method-3').replaceWith("Bank sedang offline, kembali online pukul 03.00 WIB");

        $('#method-3-label').addClass('cutoffbank');



    } else {
        $('#method-3-label').removeClass('cutoffbank');
    }
};

setInterval(enableDisable, 1000 * 60);
enableDisable();
// 
-->
</script>
<script>
$('.currency-idr').each(function() {
    var monetary_value = $(this).text();
    var i = new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
    }).format(monetary_value);
    $(this).text(i);
});

function parseNumber(strg) {
    var strg = strg || "";
    var decimal = '.';
    strg = strg.replace(/[^0-9$.,]/g, '');
    if (strg.indexOf(',') > strg.indexOf('.')) decimal = ',';
    if ((strg.match(new RegExp("\\" + decimal, "g")) || []).length > 1) decimal = "";
    if (decimal !== "" && (strg.length - strg.indexOf(decimal) - 1 == 3) && strg.indexOf("0" + decimal) !== 0) decimal = "";
    strg = strg.replace(new RegExp("[^0-9$" + decimal + "]", "g"), "");
    strg = strg.replace(',', '.');
    return parseFloat(strg);
}



function get_price(id = null) {

    <?php if ($games['target'] == 'joki'): ?>
    var jumlah = $("#jumlah_star_poin").val();
    <?php elseif ($games['target'] == 'videomontage'): ?>
    var jumlah = $("#jumlah_menit").val();
    <?php else: ?>
    var jumlah = 1;
    <?php endif; ?>


    $("#product_id").val(id);

    $.ajax({
        url: '<?= base_url(); ?>/games/order/get-price/' + id,
        type: 'POST',
        data: 'jumlah=' + jumlah,
        dataType: 'JSON',
        success: function(result) {
            for (let price in result) {
                $("#price-method-" + result[price].method).text('Rp ' + result[price].price);



            }

        }
    });
}

function update_total() {
    get_price($("#product_id").val());
}

function process_order() {

    <?php if ($games['target'] == 'joki'): ?>
    var user_id = $('.name-joki').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'skinml'): ?>
    var user_id = $('.name-skinml').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'videomontage'): ?>
    var user_id = $('.name-videomontage').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'topuplogin'): ?>
    var user_id = $('.name-topuplogin').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-ragnarox'): ?>
    var user_id = $('.name-lg-ragnarox').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-dragonhunter'): ?>
    var user_id = $('.name-lg-dragonhunter').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-fourgods'): ?>
    var user_id = $('.name-lg-fourgods').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-genshinimpact'): ?>
    var user_id = $('.name-lg-genshinimpact').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-ninokuni'): ?>
    var user_id = $('.name-lg-ninokuni').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-neverafter'): ?>
    var user_id = $('.name-lg-neverafter').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'lg-clashofclans'): ?>
    var user_id = $('.name-lg-clashofclans').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginapex'): ?>
    var user_id = $('.name-loginapex').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginefootball'): ?>
    var user_id = $('.name-loginefootball').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginff'): ?>
    var user_id = $('.name-loginff').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'logingenshin'): ?>
    var user_id = $('.name-logingenshin').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginml'): ?>
    var user_id = $('.name-loginml').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginninokuni'): ?>
    var user_id = $('.name-loginninokuni').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginpokemon'): ?>
    var user_id = $('.name-loginpokemon').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginraven'): ?>
    var user_id = $('.name-loginraven').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'logintiktok'): ?>
    var user_id = $('.name-logintiktok').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'logintower'): ?>
    var user_id = $('.name-logintower').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'loginwildrift'): ?>
    var user_id = $('.name-loginwildrift').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php elseif ($games['target'] == 'tournament'): ?>
    var user_id = $('.name-tournament').map(function() {
        return this.value;
    }).get();
    user_id = JSON.stringify(user_id);

    var zone_id = '1';

    <?php else: ?>
    var user_id = $("input[name=user_id]").val();
    var zone_id = $("input[name=zone_id]").val();
    <?php endif; ?>

    if (zone_id == undefined) {
        zone_id = $("select[name=zone_id]").val();
    }

    if (user_id == undefined) {
        user_id = $("select[name=user_id]").val();
    }

    var product = $("input[name=product]:checked").val();
    var method = $("input[name=method]:checked").val();
    var wa = $("input[name=wa]").val();
    var voucher = $("input[name=voucher]").val();

    <?php if ($games['target'] == 'joki'): ?>
    var jumlah = $("#jumlah_star_poin").val();
    <?php elseif ($games['target'] == 'videomontage'): ?>
    var jumlah = $("#jumlah_menit").val();
    <?php else: ?>
    var jumlah = 1;
    <?php endif; ?>

    if (user_id == '' || user_id == ' ') {
        Swal.fire('Gagal', 'ID Player harus diisi', 'error');
    } else if (zone_id == '' || zone_id == ' ') {
        Swal.fire('Gagal', 'ID Player harus diisi', 'error');
    } else if (product == '' || product == ' ') {
        Swal.fire('Gagal', 'Nominal produk harus dipilih', 'error');
    } else if (method == '' || method == ' ') {
        Swal.fire('Gagal', 'Pilih metode pembayaran', 'error');
    } else if (wa.length < 10 || wa.length > 14) {
        Swal.fire('Gagal', 'Nomor Whatsapp tidak sesuai', 'error');
    } else {
        $.ajax({
            url: '<?= base_url(); ?>/games/order/get-detail/' + product,
            data: 'user_id=' + user_id + '&zone_id=' + zone_id + '&method=' + method + '&wa=' + wa + '&voucher=' + voucher + '&target=<?= $games['target']; ?>' + '&jumlah=' + jumlah,
            type: 'POST',
            dataType: 'JSON',
            beforeSend: function() {
                $('#modal-loading').modal('show');
            },
            success: function(result) {

                $('#modal-loading').modal('hide');

                if (result.status == true) {
                    $("#modal-detail div div .modal-body").html(result.msg);

                    $("#modal-detail").modal('show');
                } else {
                    Swal.fire('Gagal', result.msg, 'error');
                }
            }
        });

        $('#modal-detail').on('shown.bs.modal', function() {
            $("#modal-loading").modal('hide');
        });
    }
}

function nonaktif_button() {
    document.getElementById('1xorder').innerHTML = 'Menunggu...';
    document.getElementById('1xorder').style.pointerEvents = 'none';
}

function cek_voucher() {

    var product = $("input[name=product]:checked").val();
    var voucher = $("input[name=voucher]").val();

    <?php if ($games['target'] == 'joki'): ?>
    var jumlah = $("#jumlah_star_poin").val();
    <?php elseif ($games['target'] == 'videomontage'): ?>
    var jumlah = $("#jumlah_menit").val();
    <?php else: ?>
    var jumlah = 1;
    <?php endif; ?>


    if (voucher == '' || voucher == ' ') {
        Swal.fire('Gagal', 'Kode voucher harus diisi', 'error');
    } else if (product == '' || product == ' ') {
        Swal.fire('Gagal', 'Nominal produk harus dipilih', 'error');
    } else if (product == undefined) {
        Swal.fire('Gagal', 'Nominal produk harus dipilih', 'error');
    } else {
        $.ajax({
            url: '<?= base_url(); ?>/games/voucher/' + product,
            data: 'voucher=' + voucher + '&jumlah=' + jumlah,
            type: 'POST',
            dataType: 'JSON',
            success: function(result) {
                if (result.success) {
                    Swal.fire('Berhasil', result.msg, 'success');
                } else {
                    Swal.fire('Gagal', result.msg, 'error');
                }
            }
        });
    }
}
</script>

<script type="text/javascript" defer="defer">
<!-- 
var enableDisable = function() {
    var UTC_hours = new Date().getUTCHours(); //Don't add 1 here       
    var day = new Date().getUTCDay(); //Use UTC here also

    if (day != 1 && UTC_hours >= 14 && UTC_hours < 20) {
        document.getElementById('bankbca-on').style.display = 'none';
        document.getElementById('bankbca-off').style.display = 'block';
    } else {
        document.getElementById('bankbca-on').style.display = 'block';
        document.getElementById('bankbca-off').style.display = 'none';
    }
};

setInterval(enableDisable, 1000 * 60);
enableDisable();
// 
-->
</script>
<?php $this->endSection(); ?>