			<?php $this->extend('template'); ?>

			<?php $this->section('css'); ?>
			<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '{1348541312730113}');
  fbq('track', 'AddToCart');
</script>
<noscript>
  <img height="1" width="1" style="display:none" 
       src="https://www.facebook.com/tr?id={1348541312730113}&ev= AddToCart&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

			<style>
p {
    color: #000 !important;
}

.card {
    background-color: transparent !important;
}
			</style>
			<?php $this->endSection(); ?>

			<?php $this->section('content'); ?>
			<div class="content" style="min-height: 580px;">
			    <div class="container">
			        <div class="row">

			            <?= $this->include('header-user'); ?>
			            <?= alert(); ?>
			            <div class="col-lg-12">
			                <div class="pb-4">
			                    <div class="float-right mt-2">
			                        <a href="<?= base_url(); ?>/user/topup/riwayat">
			                            <h6><i class="fa fa-history mr-2"></i> Riwayat</h6>
			                        </a>
			                    </div>
			                    <h5>Top Up</h5>
			                    <span class="strip-primary"></span>
			                </div>
			                <div class="pb-3">
			                    <div class="section">
			                        <div class="card-body">
			                            <form action="" method="POST">
			                                <div class="form-group">
			                                    <label class="text-white">Nominal Topup</label>
			                                    <input type="number" class="form-control" autocomplete="off" name="nominal">
			                                </div>
			                                <div class="row" id="topuprow">
			                                    <?php foreach ($method as $loop): ?>
			                                    <div class="col-sm-6 col-12">
			                                        <input class="radio-nominal" type="radio" name="method" value="<?= $loop['id']; ?>" id="method-<?= $loop['id']; ?>">
			                                        <label for="method-<?= $loop['id']; ?>">
			                                            <div class="ml-2 mr-2 pb-0">
			                                                <img src="<?= base_url(); ?>/assets/images/method/<?= $loop['image']; ?>" class="card img-fluid mb-1" style="height: 40px;">
			                                            </div>
			                                            <div class="ml-2 mt-2">
			                                                <p class="m-0" style="font-weight: normal;"><?= $loop['method']; ?></p>
			                                            </div>
			                                        </label>
			                                    </div>
			                                    <?php endforeach ?>
			                                </div>
			                                <div class="text-right">
			                                    <button class="btn text-white" type="reset">Batal</button>
			                                    <button class="btn btn-primary" type="submit" name="tombol" value="submit">Topup Sekarang</button>
			                                </div>
			                            </form>
			                        </div>
			                    </div>
			                </div>
			            </div>
			        </div>
			    </div>
			</div>
			<style>
#topuprow .col-sm-6 {
    -ms-flex: 0 0 50%;
    flex: 0 0 100%;
    max-width: 100%;
}
			</style>
			<?php $this->endSection(); ?>

			<?php $this->section('js'); ?>
			<?php $this->endSection(); ?>