			<?php $this->extend('template'); ?>
			
			<?php $this->section('css'); ?>

			<?php $this->endSection(); ?>
			
			<?php $this->section('content'); ?>
			<div class="content" style="min-height: 580px;">
			    <div class="container">
			    	<div class="row justify-content-center">
					    <div class="col-lg-9">
					    	<div class="pt-3 pb-4">
					            <h5>Register Member</h5>
					            <span class="strip-primary"></span>
					        </div>
					        <div class="pb-3">
					            <div class="section">
					                <div class="card-body">

					                	<?= alert(); ?>

					                   <form role="form" action="" method="POST">
                                            <div class="form-group mb-2">
                                                <p class="text-white">Saat ini status akun anda masih Off</p>
                                                <p class="text-white"><b>Masukkan kode OTP yang telah dikirim ke nomor Whatsapp Anda</b> untuk mengaktifkan Akun</p>
                                                <input type="number" name="otp" class="form-control" required autocomplete="off">
                                            </div>
                                                              
                                            <button type="submit" name="submit_otp" value="submit" class="btn btn-primary">Verifikasi</button>
                                        </form>


					                    <p class="mt-3">Sudah memiliki akun? <a href="<?= base_url(); ?>/login">Login</a></p>
					                </div>
					            </div>
					        </div>
					    </div>
					</div>
			    </div>
			</div>
			<?php $this->endSection(); ?>
			
			<?php $this->section('js'); ?>
   <!-- Facebook Pixel Code -->
   <script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  
  fbq('init', '{1348541312730113}');
  fbq('init', '{9532506813488688}');
  fbq('init', '{584979920420062}');
  fbq('track', 'CompleteRegistration');
</script>
<noscript>
  <img height="1" width="1" style="display:none" 
       src="https://www.facebook.com/tr?id={1348541312730113}&ev=CompleteRegistration&noscript=1"/>
  <img height="1" width="1" style="display:none" 
       src="https://www.facebook.com/tr?id={9532506813488688}&ev=CompleteRegistration&noscript=1"/>
	   <img height="1" width="1" style="display:none" 
       src="https://www.facebook.com/tr?id={584979920420062}&ev=CompleteRegistration&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->


			<?php $this->endSection(); ?>