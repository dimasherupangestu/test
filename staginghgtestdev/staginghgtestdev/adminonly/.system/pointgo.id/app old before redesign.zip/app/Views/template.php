<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?= $title; ?> - <?= $web['title']; ?></title>

        <meta name="description" content="<?= strip_tags($web['description']); ?>">
        <meta name="keywords" content="<?= strip_tags($web['keywords']); ?>">
        <meta name="theme-color" content="#32323E">

        <link rel="shortcut icon" href="<?= base_url(); ?>/assets/images/faviconp.png">


        <link rel="stylesheet" href="<?= base_url(); ?>/assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?= base_url(); ?>/assets/css/animate.css">
        <link rel="stylesheet" href="<?= base_url(); ?>/assets/css/icons.css">
        <link rel="stylesheet" href="<?= base_url(); ?>/assets/css/app-style.css">
        <link rel="stylesheet" href="<?= base_url(); ?>/assets/css/style-main.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css">

            <!-- Facebook Pixel Code -->
			<script>
			!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
			n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
			n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
			t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
			document,'script','https://connect.facebook.net/en_US/fbevents.js' );
			fbq( 'init', '938473200580408' );fbq( 'init', '9532506813488688' )	;fbq( 'init', '584979920420062' )		
			</script>
			<!-- DO NOT MODIFY -->
			<!-- End Facebook Pixel Code -->


        <style>

            
        :root {
            --warna: #282828;
            --warna_2: #141414;
            --warna_3: #7294a5;
        }

        #promoContent {
            height: 1000px;

        }

        a {
            color: #fff;
        }

        .opacity-100 {
            opacity: 1;
        }

        .from-gray-800 {
            --tw-gradient-from: #1f2937;
            --tw-gradient-to: rgba(31, 41, 55, 0);
            --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
        }

        .bg-gradient-to-t {
            background-image: linear-gradient(to top, var(--tw-gradient-stops));
        }

        .shadow-navbar {
            box-shadow: 0 100px 80px hsl(0deg 0% 89% / 7%), 0 41.7776px 33.4221px hsl(0deg 0% 89% / 5%), 0 22.3363px 17.869px hsl(0deg 0% 89% / 4%), 0 12.5216px 10.0172px hsl(0deg 0% 89% / 4%), 0 6.6501px 5.32008px hsl(0deg 0% 89% / 3%), 0 2.76726px 2.21381px hsl(0deg 0% 89% / 2%);
        }

        .content {
            min-height: 446px;
            padding-top: 50px;
        }

        .table-white tr th,
        .table-white tr td {
            color: #ffe7d0;
            border-color: #242f3a;
        }

        .rotateback {
            transform: rotate(-45deg) !important;
            font-size: 16px;
        }

        .kotakmiring {
            transform: rotate(45deg);
            border-radius: 0px !important;
            display: flex;
            justify-content: center;
            height: 25px;
            width: 25px;
        }

        label {
            font-weight: 500;
            text-transform: none;
        }

        .col-form-label {
            padding-top: calc(.375rem + 3px);
        }

        .card-tools {
            float: right;
            margin-top: -25px;
        }

        .cursor-pointer {
            cursor: pointer;
        }

        .menu-user a {
            padding: 10px 16px;
            border-radius: 5px;
            color: #32323e;
        }

        .menu-user a:hover {
            background: #32323e;
        }

        .menu-user a i {
            font-size: 19px;
            width: 20px;
        }

        .menu-user {
            margin-bottom: 26px;
        }

        .daterangepicker td,
        .daterangepicker th {
            color: #626262;
        }

        .circle-primary {
            background: #000000;
            color: #212529;
        }

        .bg-footer {
            background-color: #000;
        }

        .bg-custom {
            background: var(--warna_2) !important;
            padding: 20px 20px 20px 20px;
        }

        .navbar-collapse {
            background: var(--warna_2);
        }

        .btn-topup,
        .back-to-top {
            background: var(--warna_3);
        }

        .section {
            background: var(--warna_2);
        }

        .radio-nominal+label,
        .radio-nominale+label {
            background: #fff;
            border: 2px solid;
            border-color: #d5d5d5;
            font-size: 14px;
            color: #000;
            font-weight: 600;
            overflow: hidden;
            border-radius: 16px;
        }

        .radio-nominale:checked+label,
        .radio-nominal:checked+label {
            background: #ededed;
            color: #000;
            font-size: 14px;
            border: 2px solid #707feb;
            border-radius: 16px;

        }

        .owl-dot {
            display: none;
        }

        .strip-primary {
            background: #707feb;
        }

        .btn-primary {
            background: #707feb !important;
            border-color: #707feb !important;
        }

        .sidenav {
            background: var(--warna_2);
        }

        .radio-nominal:checked+label,
        .table-white tr th,
        .table-white tr td {
            border-color: #707feb;
        }

        .menu-utama div a {
            margin: 0 4px;
        }

        .menu-utama div a:hover,
        .menu-utama div a.active {
            background: transparent;
            border-radius: 14px 4px;
        }

        .menu-list {
            list-style: none;
            padding-left: 0;
        }

        .menu-list li a {
            display: block;
            padding: 10px 0;
            border-bottom: 1px dashed var(--warna_3);
            transition: .4s;
        }

        .menu-list li a:hover {
            padding-left: 6px;
        }

        .row-search {
            margin-right: -12.5px;
            margin-left: -12.5px;
            padding-bottom: 20px;
        }

        .tes-card {
            padding: 1rem;
            box-shadow: 0 4px 6px -1px rgb(0 0 0 / 10%), 0 2px 4px -1px rgb(0 0 0 / 6%);
            border-radius: 0.5rem;
            text-align: center;
            background: #fff;
            display: block;
            text-decoration: none;
            color: #fff;
            margin-bottom: 3.5rem !important;
        }

        .tes-img {
            border-radius: 10px;
            display: block;
            transform: translate(-50%, -70%) !important;
            left: 50% !important;
            position: absolute !important;
            width: 70%;
        }

        .tes-card-title {
            margin-top: 15px;
            padding: 3px;
            padding-bottom: 10px;
            color: #000;
            font-size: 0.75rem;
            letter-spacing: .5px;
            font-weight: 300;
        }

        .card-topup {
            display: none;
        }

        .title-hot {
            padding-bottom: 3.5rem !important;
        }

        .header img {
            max-width: 300px;
        }

        .header {
            width: 100%;
            height: 200px;
            background: #3D3D3D;
            border-radius: 0 0 1.5rem 1.5rem;
            text-align: center;
            padding-top: 10px;
        }

        .footer {
            background-color: #ffe7d0;
        }

        .content-body {
            padding: 0 16px;
        }

        .form-control {
            display: block;
            width: 100%;
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
            color: #212529;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #ced4da;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            border-radius: 0.375rem;
            transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        }

        .carousel {
            position: relative;
            margin-top: 30px;
        }

        .owl-carousel.owl-hidden {
            opacity: 0;
        }

        .owl-carousel.owl-rtl {
            direction: rtl;
        }

        .owl-carousel .owl-stage-outer {
            position: relative;
            overflow: hidden;
            -webkit-transform: translate3d(0, 0, 0);
        }

        .owl-carousel .owl-nav.disabled {
            display: none;
        }

        .owl-carousel .owl-item img {
            display: block;
            width: 100%;
        }

        .item .metode {
            margin: 5px 0;
            background: #fff;
            border-radius: 8px;
            padding: 0.75rem;
            box-shadow: 0 4px 6px -1px rgb(0 0 0 / 10%), 0 2px 4px -1px rgb(0 0 0 / 6%) !important;
        }

        .owl-carousel .owl-item {
            min-height: 1px;
            float: left;
            -webkit-backface-visibility: hidden;
            -webkit-touch-callout: none;
        }

        .sosmed {
            margin-bottom: 20px;
            font-size: 25px;
        }

        .sosmed a img {
            width: 24px;
        }

        .menu-bottom {
            position: fixed;
            bottom: 0;
            background: #E2E8F0;
            width: 100%;
            max-width: 480px;
            border-top: 1px solid #E2E8F0;
            padding: 0.25rem 0;
            text-align: center;
            z-index: 2;
            text-decoration: none;
            font-size: 24px;
            font-size: 0.875rem;
            margin-top: -5px;
            font-weight: 400;
            padding-top: 18px;
        }

        .px-2 {
            padding-right: 0.5rem !important;
            padding-left: 0.5rem !important;
        }

        .row {
            --bs-gutter-x: 1.5rem;
            --bs-gutter-y: 0;
            display: flex;
            flex-wrap: wrap;
            margin-top: calc(-1 * var(--bs-gutter-y));
            margin-right: calc(-.5 * var(--bs-gutter-x));
            margin-left: calc(-.5 * var(--bs-gutter-x));
        }

        .col-4 {
            flex: 0 0 auto;
            width: 33.33333333%;
        }

        a:hover {
            color: #a5a5a5;
            text-decoration: none;
        }

        .menu-bottom i {
            font-size: 24px;
        }

        .mdi-home:before {
            content: "\F2DC";
        }

        .mdi-history:before {
            content: "\F2DC";
        }

        .mdi-account-circle:before {
            content: "\F2DC";
        }

        .mdi:before,
        .mdi-set {
            display: inline-block;
            font: normal normal normal 24px/1 "Material Design Icons";
            font-size: inherit;
            text-rendering: auto;
            line-height: inherit;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .lb {
            border-top: 7px solid #f18b2b;
        }

        .pb-5 {
            padding-bottom: 4rem !important;
        }

        .section-game {
            background: var(--warna_2);
        }

        .game-desc-1 {
            padding-bottom: 1rem !important;
            padding-left: 15px;
            padding-right: 15px;
        }

        .h1,
        .h2,
        .h3,
        .h4,
        .h5,
        .h6,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            color: #212529;
        }

        .body-games {
            background: #fff;
            flex: 1 1 auto;
            padding: 1.25rem;
            border-radius: 6px;
        }

        .button-beli {
            position: fixed;
            bottom: 0;
            background: #fff;
            width: 100%;
            max-width: 480px;
            border-top: 1px solid #E2E8F0;
            padding: 0.25rem 0;
            text-align: center;
            z-index: 2;
            text-decoration: none;
            font-size: 24px;
            font-size: 0.875rem;
            margin-top: -5px;
            font-weight: 400;
            padding: 24px;
            padding-top: 24px;
        }

        small {
            font-size: 100%;

        }

        .sec-rnt {
            background: #ffe7d0;
        }

        .pb-5-rnt {
            padding: 10px;
        }

        .product-list {
            border-radius: 0.5rem;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }

        .product-list b {
            font-size: 0.85rem;
            font-weight: 600;
        }

        .product-list span {
            font-size: 11px;
            color: #718096;
        }

        .product-list.active {
            border: 1px solid var(--warna_2) !important;
        }

        .product-list.active b {
            margin-top: -53px;
        }

        .radio-nominale:checked+label:after {
            position: absolute;
            top: 0;
            left: 0.782rem;
            width: 28px;
            height: 28px;
            content: "";

            text-align: center;
            border-radius: 0 5px 0 0;
        }

        .radio-nominal:checked+label:after {
            position: absolute;
            top: 0;
            left: 0.782rem;
            width: 28px;
            height: 28px;
            content: "";

            text-align: center;
            border-radius: 0 5px 0 0;
        }

        }

        .after-payment {
            padding-bottom: 1.5rem !important;
            text-align: center;
        }

        .trims-1 {
            text-align: center;
        }

        .box-back {
            width: 38px;
            height: 38px;
            background: #33333354;
            text-align: center;
            border-radius: 30px;
            display: inline-block;
            transition: 0.5s;
            margin-left: 20px;
            margin-top: 16px;
            position: absolute;
        }

        .box-back i {
            font-size: 22px;
            margin-top: 7px;
            color: #fff;
            z-index: 999;
        }

        .fa-angle-left {
            z-index: 999
        }

        .pb-3-details {
            padding-bottom: 0px !important;
            padding: 0px 10px 0px 10px !important;
            border-radius: 15px;
        }

        .p-3-detail {
            border-radius: 15px;
        }

        .body-games-details {
            border-radius: 0px 0px 10px 10px;
            margin-bottom: 8px;
        }

        body {
            background-color: #000;
            color: #ffffff;
        }

        .fab-container {
            position: fixed;
            bottom: 90px;
            right: 10px;
            z-index: 999;
            cursor: pointer;
        }

        .img-fluid2 {
            max-width: 100%;
            height: auto;
            padding-bottom: 15px;

        }

        .fab-icon-holder {
            width: 45px;
            height: 45px;
            bottom: 140px;
            left: 10px;
            color: #FFF;
            background: #5865f2;
            border-radius: 10px;
            text-align: center;
            font-size: 30px;
            z-index: 99999;
        }

        .fab-icon-holder:hover {
            opacity: 0.8;
        }

        .fab-icon-holder i {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            font-size: 25px;
            color: #ffffff;
        }

        .fab-options {
            list-style-type: none;
            margin: 0;
            position: absolute;
            bottom: 48px;
            left: -45px;
            opacity: 0;
            transition: all 0.3s ease;
            transform: scale(0);
            transform-origin: 85% bottom;
        }

        .fab:hover+.fab-options,
        .fab-options:hover {
            opacity: 1;
            transform: scale(1);
        }

        .fab-options li {
            display: flex;
            justify-content: flex-start;
            padding: 5px;
        }

        .fab-label {
            padding: 2px 5px;
            align-self: center;
            user-select: none;
            white-space: nowrap;
            border-radius: 3px;
            font-size: 16px;
            background: #666666;
            color: #ffffff;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
            margin-left: 10px;
        }

        .text-decoration-none {
            text-decoration: none !important;
        }
        }

        .card-title2 {
            min-height: 30px !important;
            margin-top: -25px !important;
            font-weight: 600 !important;
            font-size: 10px !important;
            color: #fff !important;
            background: #000000 !important;
            padding-top: 8px !important;
            margin-bottom: 0px !important;

        }

        @media (min-width: 900px) {
            .backdrop {
                margin: -51px 3px 0px 3px;
                font-weight: 600 !important;
                font-size: 0.7rem !important;
                color: #fff !important;
                background-color: rgb(40 40 40 / 36%);
                border-radius: 0.75rem;
                padding: 5px 0px 5px 0px;
                --tw-backdrop-saturate: saturate(2);
                backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-saturate);
                --tw-backdrop-blur: blur(12px);
                display: flex;
                flex-direction: column;
                justify-content: center;
                height: 45px;

            }
        }

        @media (max-width: 900px) {
            .backdrop {
                margin: -39px 3px 0px 3px;
                font-weight: 600 !important;
                font-size: 0.6rem !important;
                color: #fff !important;
                background-color: rgb(40 40 40 / 36%);
                border-radius: 0.75rem;
                padding: 2px 2px 2px 2px;
                --tw-backdrop-saturate: saturate(2);
                backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-saturate);
                --tw-backdrop-blur: blur(12px);
                display: flex;
                flex-direction: column;
                justify-content: center;
                height: 36px;

            }

        }

        .container {
            max-width: 1200px !important;
        }

        .h1,
        .h2,
        .h3,
        .h4,
        .h5,
        .h6,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            font-weight: 600;
            color: #fff;
        }

        .section-game {
            border: 1px solid #e3e7ea;
            box-shadow: 0px 2px 1px #c9c9c9;
        }

        .card {
            background-color: var(--warna_2) !important;
        }

        .bg-theme2 {
            background: #000 !important;
            padding: 20px 20px 20px 20px;
            color: #fff;
        }

        .product-tile__clip-path[data-v-16b318a8] {
            -webkit-clip-path: polygon(0 48%, 9% 48%, 18% 65%, 27% 49%, 36% 72%, 45% 58%, 55% 70%, 64% 58%, 73% 86%, 82% 48%, 91% 63%, 100% 70%, 100% calc(100% + 1px), 0 calc(100% + 1px));
            background-color: var(--warna_2);
            width: 100%;
            height: 25px;
            margin-top: -23px;
        }

        .card-title2 {
            min-height: 35px !important;
            margin: 5px 5px 15px 5px !important;
            font-weight: 600 !important;
            font-size: .875rem;
            color: #fff;
            padding: 8px 8px 16px;
        }

        .footer__clip-path[data-v-1da71fac] {
            display: flex;
            padding: 0;
            margin-top: -39px;
            width: 100%;
            height: 40px;
            background-color: var(--warna_2);
        }

        @media screen and (min-width: 768px) {
            .footer__clip-path[data-v-1da71fac] {
                clip-path: polygon(0 23%, 2% 55%, 4% 32%, 6% 50%, 8% 30%, 10% 75%, 13% 40%, 15% 62%, 17% 96%, 19% 50%, 21% 93%, 23% 46%, 25% 89%,
                        27% 64%, 29% 87%, 31% 76%, 33% 59%, 35% 96%, 38% 48%, 40% 82%, 42% 65%, 44% 48%, 46% 82%, 48% 66%, 50% 44%, 52% 56%, 54% 100%, 56% 65%,
                        58% 93%, 60% 49%, 63% 99%, 65% 44%, 67% 97%, 69% 87%, 71% 43%, 73% 68%, 75% 48%, 77% 67%, 79% 95%, 81% 64%, 83% 38%, 85% 85%,
                        88% 51%, 90% 81%, 92% 38%, 94% 80%, 96% 61%, 98% 40%, 100% 72%, 100% calc(100% + 1px), 0 calc(100% + 1px));
            }
        }

        .form-control:focus {
            border: 1px solid #cfd5db;
            background-color: #ffffff;
            color: #495057 !important;
        }

        .countdown-void {
            border-radius: 4px;
            min-width: 85px;
            text-align: center;
            min-height: 20px;
            background: #ed3a3a;
            margin-left: 10px;
            padding: 5px;
        }

        .flash-sale-head {
            background-color: transparent;
            border-radius: 10px;
            padding: 10px;
            overflow: hidden;
            margin-bottom: 50px;
            padding: 30px 20px 10px 20px;
        }
        </style>

        <?php $this->renderSection('css'); ?>
    </head>

    <body>
        <div class="content" style="padding-top: 0px;">
            <header>
                <nav class="navbar navbar-expand-lg navbar-dark  bg-custom shadow-navbar ">
                    <div class="container">
                        <a class="navbar-brand" href="<?= base_url(); ?>">
                            <img src="<?= base_url(); ?>/assets/images/<?= $web['logo']; ?>" height="50" alt="logo icon" class="rounded">
                        </a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse menu-utama" id="navbarNavAltMarkup">
                            <div class="navbar-nav ml-auto">
                                <a class="nav-item nav-link <?= $menu_active == 'Home' ? 'active' : ''; ?>" href="<?= base_url(); ?>">Home</a>
                                <a class="nav-item nav-link <?= $menu_active == 'Cek' ? 'active' : ''; ?>" href="<?= base_url(); ?>/payment">Cek Pesanan</a>
                                <a class="nav-item nav-link <?= $menu_active == 'Harga' ? 'active' : ''; ?>" href="<?= base_url(); ?>/tabelharga">Daftar Harga</a>
                                <a class="nav-item nav-link <?= $menu_active == 'Price' ? 'active' : ''; ?>" href="<?= base_url(); ?>/price" hidden>Daftar Harga</a>
                                <a class="nav-item nav-link <?= $menu_active == 'Method' ? 'active' : ''; ?>" href="<?= base_url(); ?>/method" hidden>Metode Pembayaran</a>
                                <a class="nav-item nav-link <?= $menu_active == 'postingan' ? 'active' : ''; ?>" href="<?= base_url(); ?>/postingan" hidden>Artikel</a>
                               
                                <a class="nav-item nav-link <?= $menu_active == 'Register' ? 'active' : ''; ?>" href="<?= base_url(); ?>/register">Daftar Member</a>
                                <a class="nav-item nav-link <?= $menu_active == 'Login' ? 'active' : ''; ?>" href="<?= base_url(); ?>/login">Login Member</a>
                                <?php if ($admin !== false): ?>
                                <a class="nav-item nav-link" href="<?= base_url(); ?>/admin">Administrator</a>
                                <?php endif ?>
                                <?php if ($users !== false): ?>
                                <a class="nav-item nav-link" href="<?= base_url(); ?>/user">Beranda</a>
                                <?php endif ?>
                            </div>
                        </div>
                    </div>
                </nav>
            </header>





            <?php $this->renderSection('content'); ?>


        </div>

        <footer id="aboutus" >
            <div data-v-1da71fac="" class="footer__clip-path"></div>
            <div style="background: var(--warna_2);margin-top: -4px;">
                <div class="pt-5 pb-5">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-sm-6">
                                <img src="<?= base_url(); ?>/assets/images/<?= $web['logo']; ?>" height="40" alt="logo icon" class="mb-3">
                                <h5 class="mb-2"><?= $web['name']; ?></h5>
                                <?= $web['description']; ?>
                            </div>

                            <div class="col-lg-3 col-sm-6">
                                <h5 class="pb-2">Halaman</h5>
                                <ul class="menu-list">
                                    <li><a href="<?= base_url(); ?>/">Halaman Utama</a></li>
                                    <li><a href="<?= base_url(); ?>/payment">Cek Pesanan</a></li>
                                    <li><a href="<?= base_url(); ?>/price" hidden>Daftar Harga</a></li>
                                    <li><a href="<?= base_url(); ?>/syarat-ketentuan">Syarat & Ketentuan</a></li>
                                </ul>
                            </div>
                            <div class="col-lg-3 col-sm-3" hidden>
                                <h5 class="pb-2">Sosial Media Kami</h5>
                                <a href="<?= $sm['ig']; ?>" style="font-size: 35px;">
                                    <i class="fa fa-instagram pr-4"></i>
                                </a>
                                <a href="<?= $sm['yt']; ?>" style="font-size: 35px;">
                                    <i class="fa fa-youtube pr-4"></i>
                                </a>
                                <a href="<?= $sm['fb']; ?>" style="font-size: 35px;">
                                    <i class="fa fa-facebook pr-4"></i>
                                </a>
                                <a href="<?= $sm['tw']; ?>" style="font-size: 35px;">
                                    <i class="fa fa-twitter"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="fab-container">
                <div class="fab fab-icon-holder" style="background-color:#FFF; padding:5px">
                    <img src="<?= base_url(); ?>/assets/images/callcenter.webp" class="img-fluid2" alt="">
                </div>

                <ul class="fab-options">
                    <li>
                        <a href="<?= $sm['ig']; ?>" class="text-decoration-none" target="_blank">
                            <div class="fab-icon-holder" style="background: radial-gradient(circle farthest-corner at 35% 90%, #fec564, transparent 50%), radial-gradient(circle farthest-corner at 0 140%, #fec564, transparent 50%), radial-gradient(ellipse farthest-corner at 0 -25%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 20% -50%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 0, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 60% -20%, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 100%, #d9317a, transparent), linear-gradient(#6559ca, #bc318f 30%, #e33f5f 50%, #f77638 70%, #fec66d 100%);">
                                <i class="fa fa-instagram"></i>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $sm['wa']; ?>" class="text-decoration-none" target="_blank">
                            <div class="fab-icon-holder" style="background-color: #25D366;">
                                <i class="fa fa-whatsapp"></i>
                            </div>
                        </a>
                    </li>
                </ul>

            </div>
            <div class="bg-theme2 text-center pb-4"> Copyright © 2022 <?= $web['name']; ?>. All Rights Reserved </div>
        </footer>


        <a href="javaScript:void();" class="back-to-top">
            <i class="fa fa-angle-double-up"></i>
        </a>

        <!--End wrapper-->
        <!-- Bootstrap core JavaScript-->
        <script src="<?= base_url(); ?>/assets/js/jquery.min.js"></script>
        <script src="<?= base_url(); ?>/assets/js/popper.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.1/js/bootstrap.bundle.min.js"></script>
        <!-- simplebar js -->
        <!-- Custom scripts -->
        <script src="<?= base_url(); ?>/assets/js/app-script.js"></script>
        <!--Select Plugins Js-->
        <script src="<?= base_url(); ?>/assets/plugins/select2/js/select2.min.js"></script>
        <!--Data Tables js-->

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


        <script src="https://code.iconify.design/iconify-icon/1.0.0/iconify-icon.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>


        <script>
        // $(document).ready(function() {
        //     $('#default-datatable').DataTable();
        // });

        function openNav() {
            document.getElementById("mySidenav").style.width = "300px";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }
        </script>

        <script>
        var mySwiper = new Swiper('.swiper-container', {
            slidesPerView: 3,
            spaceBetween: 300,
            loop: true,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            grabCursor: true,
        });
        </script>

        <script>
        <?php if ($admin !== false): ?>

        function hapus(link) {
            Swal.fire({
                title: 'Anda yakin?',
                text: "Data akan dihapus permanen",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: 'Batal',
                confirmButtonText: 'Tetap hapus'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = link;
                }
            });
        }
        <?php endif; ?>
        </script>

        <script>
        function goBack() {
            window.history.back();
        }
        </script>
        <?php $this->renderSection('js'); ?>
    </body>

</html>